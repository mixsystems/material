import * as i0 from "@angular/core";
import { AfterContentInit, AfterViewInit, ChangeDetectorRef, ElementRef, EventEmitter, NgZone, OnChanges, OnDestroy, OnInit, QueryList, Renderer2, SimpleChanges } from "@angular/core";
import { ControlValueAccessor, NgControl } from "@angular/forms";
import { MDCChipFoundation } from "@material/chips";
import { MDCMenu } from "@material/menu";
import { Router, RouterLink, RouterLinkWithHref } from "@angular/router";
import * as i30 from "@angular/common";
import { Observable, Subject } from "rxjs";
export declare class MdcEventRegistry {
  constructor();
  listen(renderer: Renderer2, type: string, listener: EventListener, ref: ElementRef, options?: any): void;
  listenElm(renderer: Renderer2, type: string, listener: EventListener, el: Element | Window | Document, options?: any): void;
  registerUnlisten(type: string, listener: EventListener, unlistener: Function): void;
  unlisten(type: string, listener: EventListener): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcEventRegistry, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/** @docs-private */
export declare abstract class AbstractMdcRipple {
  protected _rippleElm: ElementRef;
  protected _renderer: Renderer2;
  protected _registry: MdcEventRegistry;
  private mdcRippleAdapter;
  protected _rippleFoundation: {
    init(): any;
    destroy(): any;
    activate(event?: Event): any;
    deactivate(event?: Event): any;
    layout(): any;
  };
  constructor(_rippleElm: ElementRef, _renderer: Renderer2, _registry: MdcEventRegistry);
  protected initRipple(): void;
  protected destroyRipple(): void;
  protected isRippleInitialized(): boolean;
  activateRipple(): void;
  deactivateRipple(): void;
  protected getRippleInteractionElement(): ElementRef<any>;
  protected isRippleUnbounded(): boolean;
  protected isRippleSurfaceActive(): any;
  protected isActiveElement(element: HTMLElement): any;
  protected isRippleSurfaceDisabled(): boolean;
  protected addClassToRipple(name: string): void;
  protected removeClassFromRipple(name: string): void;
  protected computeRippleBoundingRect(): any;
}
/** @docs-private */
interface MdcTabAdapter {
  addClass: (className: string) => void;
  removeClass: (className: string) => void;
  registerInteractionHandler: (evt: string, handler: EventListener) => void;
  deregisterInteractionHandler: (evt: string, handler: EventListener) => void;
  getOffsetWidth: () => number;
  getOffsetLeft: () => number;
  notifySelected: () => void;
}
/**
 * The interface for events send by the <code>activate</code> output of an
 * <code>mdcTab</code> or <code>mdcTabRouter</code> directive, or by
 * the <code>tabChange</code> event of an <code>mdcTabBar</code>.
 */
export interface MdcTabChange {
  /**
   * A reference to the tab that sends the event.
   */
  tab: AbstractMdcTabDirective;
  /**
   * The index of the tab that sends the event.
   */
  tabIndex: number;
}
/**
 * Directive for an icon when having a tab bar with icons.
 * This directive must be used as a child of an <code>mdcTab</code>,
 * or <code>mdcTabRouter</code>.
 */
export declare class MdcTabIconDirective {
  _hostClass: boolean;
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcTabIconDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcTabIconDirective, "[mdcTabIcon]", never, {}, {}, never, never, false, never>;
}
/**
 * Directive for the text of tabs, when having a tab bar with icons and text labels.
 * This directive must be used as a child of an <code>mdcTab</code>, and as a sibbling
 * to a preceding <code>mdcTabIcon</code>.
 */
export declare class MdcTabIconTextDirective {
  _hostClass: boolean;
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcTabIconTextDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcTabIconTextDirective, "[mdcTabIconText]", never, {}, {}, never, never, false, never>;
}
export declare class AbstractMdcTabDirective extends AbstractMdcRipple implements OnDestroy, AfterContentInit {
  protected _rndr: Renderer2;
  protected _root: ElementRef;
  protected _registry: MdcEventRegistry;
  _hostClass: boolean;
  _mdcTabIcon: MdcTabIconDirective;
  _mdcTabIconText: MdcTabIconTextDirective;
  /**
   * Event called when the tab is activated.
   */
  activate: EventEmitter<MdcTabChange>;
  protected _adapter: MdcTabAdapter;
  _foundation: any;
  constructor(_rndr: Renderer2, _root: ElementRef, _registry: MdcEventRegistry);
  ngAfterContentInit(): void;
  ngOnDestroy(): void;
  get _tabWithIconAndText(): boolean;
  get _active(): boolean;
  set _active(value: boolean);
  static ɵfac: i0.ɵɵFactoryDeclaration<AbstractMdcTabDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AbstractMdcTabDirective, never, never, {}, {
    "activate": "activate";
  }, ["_mdcTabIcon", "_mdcTabIconText"], never, true, never>;
}
/**
 * Directive for a tab. This directive must be used as a child of <code>mdcTabBar</code>.
 */
export declare class MdcTabDirective extends AbstractMdcTabDirective {
  constructor(rndr: Renderer2, root: ElementRef, registry: MdcEventRegistry);
  /**
   * Input for activating the tab. Assign a value other than <code>false</code> to activate
   * the tab. Any other value will have no effect: in order to deatcivate the tab, you must
   * activate another tab.
   */
  get active(): boolean;
  set active(value: boolean);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcTabDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcTabDirective, "[mdcTab]", never, {
    "active": {
      "alias": "active";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
/**
 * Directive for a tab bar. This directive must have <code>mdcTab</code>,
 * or <code>mdcTabRouter</code> children. The tab bar can optionally be
 * embedded inside an <code>mdcTabBarScroller</code>.
 */
export declare class MdcTabBarDirective {
  private _rndr;
  _el: ElementRef;
  private registry;
  _hostClass: boolean;
  _insideScrollFrame: boolean;
  _tabs: QueryList<AbstractMdcTabDirective>;
  /**
   * Event emitted when the actived tab changes.
   */
  tabChange: EventEmitter<MdcTabChange>;
  private _indicator;
  private _adapter;
  private _subscriptions;
  private _foundation;
  constructor(_rndr: Renderer2, _el: ElementRef, registry: MdcEventRegistry);
  ngAfterContentInit(): void;
  ngOnDestroy(): void;
  private addIndicator;
  private _listenTabSelected;
  private _unlistenTabSelected;
  private _setActive;
  get _tabBarWithIcon(): boolean;
  get _tabBarWithIconAndText(): boolean;
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcTabBarDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcTabBarDirective, "[mdcTabBar]", never, {}, {
    "tabChange": "tabChange";
  }, ["_tabs"], never, false, never>;
}
/**
 * Directive for the icon of the back or forward button of a tab bar scroller.
 * Use this directive on a child element of <code>mdcTabBarScrollerBack</code>,
 * and <code>mdcTabBarScrollerForward</code>.
 */
export declare class MdcTabBarScrollerInnerDirective {
  _hostClass: boolean;
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcTabBarScrollerInnerDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcTabBarScrollerInnerDirective, "[mdcTabBarScrollerInner]", never, {}, {}, never, never, false, never>;
}
/**
 * Directive for the 'back' button of a tab bar scroller. Must be the
 * first child of an <code>mdcTabBarScroller</code>.
 * Embed an <code>mdcTabBarScrollerInner</code> inside this directive for the
 * actual icon.
 */
export declare class MdcTabBarScrollerBackDirective {
  _el: ElementRef;
  _hostClass: boolean;
  _back: boolean;
  constructor(_el: ElementRef);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcTabBarScrollerBackDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcTabBarScrollerBackDirective, "[mdcTabBarScrollerBack]", never, {}, {}, never, never, false, never>;
}
/**
 * Directive for the 'forward' button of a tab bar scroller. Must be the
 * last child of an <code>mdcTabBarScroller</code>.
 * Embed an <code>mdcTabBarScrollerInner</code> inside this directive for the
 * actual icon.
 */
export declare class MdcTabBarScrollerForwardDirective {
  _el: ElementRef;
  _hostClass: boolean;
  _forward: boolean;
  constructor(_el: ElementRef);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcTabBarScrollerForwardDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcTabBarScrollerForwardDirective, "[mdcTabBarScrollerForward]", never, {}, {}, never, never, false, never>;
}
/**
 * Directive for the 'frame' part (containing the tab bar) of a tab bar scroller.
 * Must be the child of an <code>mdcTabBarScroller</code>, and have an
 * <code>mdcTabBar</code> as child.
 */
export declare class MdcTabBarScrollerFrameDirective implements AfterContentInit {
  _el: ElementRef;
  _hostClass: boolean;
  _tabBar: MdcTabBarDirective;
  constructor(_el: ElementRef);
  ngAfterContentInit(): void;
  _tabAt(index: number): AbstractMdcTabDirective;
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcTabBarScrollerFrameDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcTabBarScrollerFrameDirective, "[mdcTabBarScrollerFrame]", never, {}, {}, ["_tabBar"], never, false, never>;
}
/**
 * Directive for a scrollable tab bar. Add <code>mdcTabBarScrollerBack</code>,
 * <code>mdcTabBarScrollerFrame</code>, and <code>mdcTabBarScrollerForward</code>
 * as children for respectively the back button, scrollable tab bar, and forward button.
 */
export declare class MdcTabBarScrollerDirective implements AfterContentInit, OnDestroy {
  private _rndr;
  private _el;
  private registry;
  _hostClass: boolean;
  _back: MdcTabBarScrollerBackDirective;
  _forward: MdcTabBarScrollerForwardDirective;
  _scrollFrame: MdcTabBarScrollerFrameDirective;
  private _adapter;
  private _foundation;
  constructor(_rndr: Renderer2, _el: ElementRef, registry: MdcEventRegistry);
  ngAfterContentInit(): void;
  ngOnDestroy(): void;
  private _tabAt;
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcTabBarScrollerDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcTabBarScrollerDirective, "[mdcTabBarScroller]", never, {}, {}, ["_back", "_forward", "_scrollFrame"], never, false, never>;
}
/**
 * Use this directive for adding an icon to an <code>mdcButton</code>. This directive can be
 * added to font-style icons (such as <a href="https://material.io/icons/" target="_blank">material icons</a>
 * from Google fonts), or with <code>svg</code> elements for svg based icons.
 */
export declare class MdcButtonIconDirective {
  _cls: boolean;
  _ariaHidden: boolean;
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcButtonIconDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcButtonIconDirective, "mdcButtonIcon", never, {}, {}, never, never, false, never>;
}
/**
 * Material design button. Anchors can also be styled as buttons with this directive.
 * Defaults to a button that is flushed with the surface.
 * Use the input modifiers to alter the styling, or create your own style
 * based on the provided sass-mixins.
 */
export declare class MdcButtonDirective extends AbstractMdcRipple implements AfterContentInit, OnDestroy {
  _elm: ElementRef;
  _cls: boolean;
  private _dense;
  private _raised;
  private _unelevated;
  private _outlined;
  constructor(_elm: ElementRef, renderer: Renderer2, registry: MdcEventRegistry);
  ngAfterContentInit(): void;
  ngOnDestroy(): void;
  /**
   * When this input is defined and does not have value false, the button will be elevated
   * upon the surface.
   */
  get raised(): any;
  set raised(val: any);
  /**
   * When this input is defined and does not have value false, the button will be styled
   * flush with the surface and have a visible border.
   */
  get outlined(): any;
  set outlined(val: any);
  /**
   * Set this property to a non false value for a contained button
   * flush with the surface.
   */
  get unelevated(): any;
  set unelevated(val: any);
  /**
   * When this input is defined and does not have value false, the button text is compressed
   * to make it slightly smaller.
   */
  get dense(): any;
  set dense(val: any);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcButtonDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcButtonDirective, "button[mdcButton],a[mdcButton]", never, {
    "raised": {
      "alias": "raised";
      "required": false;
    };
    "outlined": {
      "alias": "outlined";
      "required": false;
    };
    "unelevated": {
      "alias": "unelevated";
      "required": false;
    };
    "dense": {
      "alias": "dense";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
/** @docs-private */
declare abstract class AbstractMdcIcon extends AbstractMdcRipple {
  _elm: ElementRef;
  constructor(_elm: ElementRef, renderer: Renderer2, registry: MdcEventRegistry);
}
/**
 * Directive for an area that displays a custom background-image. See the <code>size</code>
 * property for the sizing of the image.
 * If used, this directive should be put inside the card itself (<code>MdcCardDirective</code>).
 * Add an <code>mdcCardMediaContent</code> as sub-element for displaying a title, text,
 * or icon on top of the background image.
 */
export declare class MdcCardMediaDirective {
  _cls: boolean;
  private _size;
  constructor();
  get _square(): boolean;
  get _size2(): boolean;
  /**
   * Directive to select size to which this element's background-image should
   * be scaled. Can be one of 'cover', '16:9', or 'square'. The default value
   * is 'cover'.
   */
  get size(): 'cover' | '16:9' | 'square';
  set size(val: 'cover' | '16:9' | 'square');
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcCardMediaDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcCardMediaDirective, "[mdcCardMedia]", never, {
    "size": {
      "alias": "size";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
/**
 * Directive for displaying text on top of a <code>mdcCardMedia</code> element.
 * This directive should be used as child element of the <code>mdcCardMedia</code>, and
 * creates an absolutely positioned box the same size as the media area.
 */
export declare class MdcCardMediaContentDirective {
  _cls: boolean;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcCardMediaContentDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcCardMediaContentDirective, "[mdcCardMediaContent]", never, {}, {}, never, never, false, never>;
}
/**
 * Directive for displaying the button card actions. Composed of one or more
 * card actions, which must be buttons that have the <code>MdcButtonDirective</code>.
 * This directive should be placed inside an <code>MdcCardActionsDirective</code>.
 */
export declare class MdcCardActionButtonsDirective {
  _cls: boolean;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcCardActionButtonsDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcCardActionButtonsDirective, "[mdcCardActionButtons]", never, {}, {}, never, never, false, never>;
}
/**
 * Directive for displaying the icon card actions. Composed of one or more
 * card actions, which must be icons (for instance <code>mdcIconButton</code>.
 * This directive should be placed inside an <code>MdcCardActionsDirective</code>.
 */
export declare class MdcCardActionIconsDirective {
  _cls: boolean;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcCardActionIconsDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcCardActionIconsDirective, "[mdcCardActionIcons]", never, {}, {}, never, never, false, never>;
}
/**
 * Directive for showing the different actions a user can take. Use
 * <code>mdcButton</code>, or <code>mdcIconButton</code> as child elements.
 * If you want to use both buttons and icons in the same row, wrap them in
 * <code>mdcCardActionButtons</code>, and <code>mdcCardActionIcons</code> directives.
 */
export declare class MdcCardActionsDirective implements AfterContentInit {
  private renderer;
  _cls: boolean;
  _buttons: QueryList<MdcButtonDirective>;
  _icons: QueryList<AbstractMdcIcon>;
  private _initialized;
  private _fullBleed;
  constructor(renderer: Renderer2);
  ngAfterContentInit(): void;
  private _initButtons;
  private _initIcons;
  /**
   * When this input is defined and does not have value false, the contained
   * button takes up the entire width of the action row. This should be used only when
   * there is a single button contained in the directive.
   */
  get fullBleed(): any;
  set fullBleed(val: any);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcCardActionsDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcCardActionsDirective, "[mdcCardActions]", never, {
    "fullBleed": {
      "alias": "fullBleed";
      "required": false;
    };
  }, {}, ["_buttons", "_icons"], never, false, never>;
}
/**
 * Directive for the main tappable area of the card (so should be a child of <code>mdcCard</code>).
 * Typically contains most (or all) card content except <code>mdcCardActions</code>.
 * Only applicable to cards that have a primary action that the main surface should trigger.
 */
export declare class MdcCardPrimaryActionDirective extends AbstractMdcRipple implements AfterContentInit, OnDestroy {
  _cls: boolean;
  constructor(elm: ElementRef, renderer: Renderer2, registry: MdcEventRegistry);
  ngAfterContentInit(): void;
  ngOnDestroy(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcCardPrimaryActionDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcCardPrimaryActionDirective, "[mdcCardPrimaryAction]", never, {}, {}, never, never, false, never>;
}
/**
 * Directive for a material designed card. The card can be composed with the following directives:
 * <code>MdcCardMediaDirective</code>, <code>MdcCardActionsDirective</code>
 */
export declare class MdcCardDirective {
  _cls: boolean;
  private _outlined;
  constructor();
  /**
   * When this input is set to a value other than false, the card will have a
   * hairline stroke instead of a shadow.
   */
  get outlined(): any;
  set outlined(val: any);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcCardDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcCardDirective, "[mdcCard]", never, {
    "outlined": {
      "alias": "outlined";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
/** @docs-private */
declare abstract class AbstractMdcInput {
  abstract id: string;
  abstract _elm: ElementRef;
}
/**
 * Directive for the input element of an <code>MdcCheckboxDirective</code>.
 */
export declare class MdcCheckboxInputDirective extends AbstractMdcInput {
  _elm: ElementRef;
  _cntr: NgControl;
  _cls: boolean;
  private _id;
  private _disabled;
  constructor(_elm: ElementRef, _cntr: NgControl);
  /** @docs-private */
  get id(): string;
  set id(value: string);
  /** @docs-private */
  get disabled(): any;
  set disabled(value: any);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcCheckboxInputDirective, [null, {
    optional: true;
    self: true;
  }]>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcCheckboxInputDirective, "input[mdcCheckboxInput][type=checkbox]", never, {
    "id": {
      "alias": "id";
      "required": false;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
/**
 * Directive for creating a Material Design checkbox. The checkbox is driven by an
 * underlying native checkbox input, which must use the <code>MdcCheckboxInputDirective</code>
 * directive.
 * The current implementation will add all other required DOM elements (such as the
 * background).
 * Future implementations will also support supplying (customized) background
 * elements.
 * </p><p>
 * This directive can be used together with an <code>mdcFormField</code> to
 * easily position checkboxes and their labels, see
 * <a href="/material/components/form-field">mdcFormField</a>.
 */
export declare class MdcCheckboxDirective extends AbstractMdcRipple implements AfterContentInit, OnDestroy {
  private renderer;
  private root;
  private registry;
  _cls: boolean;
  _input: MdcCheckboxInputDirective;
  private mdcAdapter;
  private foundation;
  constructor(renderer: Renderer2, root: ElementRef, registry: MdcEventRegistry);
  ngAfterContentInit(): void;
  ngOnDestroy(): void;
  private addBackground;
  /** @docs-private */
  protected getRippleInteractionElement(): ElementRef<any>;
  /** @docs-private */
  protected isRippleUnbounded(): boolean;
  get _disabled(): any;
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcCheckboxDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcCheckboxDirective, "[mdcCheckbox]", never, {}, {}, ["_input"], never, false, never>;
}
/** @docs-private */
interface MdcChipSetAdapter {
  hasClass: (className: string) => boolean;
  registerInteractionHandler: (evtType: string, handler: EventListener) => void;
  deregisterInteractionHandler: (evtType: string, handler: EventListener) => void;
  removeChip: (chip: any) => void;
}
/**
 * Directive for the (optional) leading or trailing icon of an <code>mdcChip</code>.
 * Depenending on the position within the <code>mdcChip</code> the icon will determine
 * whether it is a leading or trailing icon.
 * Trailing icons must implement the functionality to remove the chip from the set, and
 * must only be added to input chips (<code>mdcChipSet="input"</code>). Chips with a trailing
 * icon must implement the <code>remove</code> event.
 */
export declare class MdcChipIconDirective {
  _elm: ElementRef;
  private _rndr;
  _cdRef: ChangeDetectorRef;
  _cls: boolean;
  _leading: boolean;
  /**
   * Event emitted for trailing icon user interactions.
   */
  interact: EventEmitter<void>;
  private __trailing;
  private _oldTabIndex;
  private _oldRole;
  constructor(_elm: ElementRef, _rndr: Renderer2, _cdRef: ChangeDetectorRef);
  get _trailing(): boolean;
  set _trailing(val: boolean);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcChipIconDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcChipIconDirective, "[mdcChipIcon]", never, {}, {
    "interact": "interact";
  }, never, never, false, never>;
}
/**
 * Directive for the text of an <code>mdcChip</code>.
 */
export declare class MdcChipTextDirective {
  _elm: ElementRef;
  _cls: boolean;
  constructor(_elm: ElementRef);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcChipTextDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcChipTextDirective, "[mdcChipText]", never, {}, {}, never, never, false, never>;
}
/**
 * Directive for a chip. Chips must be child elements of an <code>mdcChipSet</code>.
 */
export declare class MdcChipDirective extends AbstractMdcRipple implements AfterContentInit, OnDestroy {
  private _elm;
  _cls: boolean;
  private initialized;
  private selectedMem;
  /**
   * Event emitted for user interaction with the chip.
   */
  interact: EventEmitter<void>;
  /**
   * Event emitted when the user has removed (by clicking the trailing icon) the chip.
   * This event must be implemented when the chip has a trailing icon, and the implementation
   * must remove the chip from the set. Without such implementation the directive will
   * animate the chip out of vision, but will not remove the chip from the DOM.
   */
  remove: EventEmitter<void>;
  /**
   * Event emitted when the chip changes from not-selected to selected state or vice versa
   * (for filter and choice chips).
   */
  selectedChange: EventEmitter<boolean>;
  _set: MdcChipSetDirective;
  private _checkmark;
  private _leadingIcon;
  private _trailingIcon;
  _icons: QueryList<MdcChipIconDirective>;
  _texts: QueryList<MdcChipTextDirective>;
  private _adapter;
  _foundation: {
    init: Function;
    destroy: Function;
    isSelected: () => boolean;
    setSelected: (selected: boolean) => void;
  };
  constructor(_elm: ElementRef, rndr: Renderer2, registry: MdcEventRegistry);
  ngAfterContentInit(): void;
  ngOnDestroy(): void;
  _reInit(): void;
  private initIcons;
  private computeLeadingIcon;
  private get _text();
  private computeTrailingIcon;
  private previousElement;
  private initCheckMark;
  private addCheckMark;
  private removeCheckMark;
  /**
   * The 'selected' state of the chip. Filter and choice chips are either selected or
   * not selected. Making a choice chip selected, will make all other chips in that set
   * not selected.
   */
  get selected(): any;
  set selected(val: any);
  /** @docs-private */
  protected computeRippleBoundingRect(): any;
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcChipDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcChipDirective, "[mdcChip]", never, {
    "selected": {
      "alias": "selected";
      "required": false;
    };
  }, {
    "interact": "interact";
    "remove": "remove";
    "selectedChange": "selectedChange";
  }, ["_icons", "_texts"], never, false, never>;
}
/**
 * Directive for a chip-set (a collection of <code>mdcChip</code>).
 */
export declare class MdcChipSetDirective implements AfterContentInit, OnDestroy {
  private _elm;
  private _rndr;
  private _registry;
  _cls: boolean;
  _chips: QueryList<MdcChipDirective>;
  private _interactSubscriptions;
  private _removeSubscriptions;
  private _initialized;
  private _interactionHandler;
  _type: 'choice' | 'filter' | 'input' | 'action';
  _adapter: MdcChipSetAdapter;
  _foundation: {
    init: Function;
    destroy: Function;
    select: (chip: MDCChipFoundation) => void;
    deselect: (chip: MDCChipFoundation) => void;
  };
  constructor(_elm: ElementRef, _rndr: Renderer2, _registry: MdcEventRegistry);
  ngAfterContentInit(): void;
  ngOnDestroy(): void;
  /**
   * Chip sets by default contain 'action' chips. Set this value to <code>choice</code>,
   * <code>filter</code>, <code>input</code>, or <code>action</code> to determine the kind
   * of chips that are contained in the chip set.
   */
  get mdcChipSet(): any;
  set mdcChipSet(value: any);
  private initChips;
  private destroySubscriptions;
  private initSubscriptions;
  get _choice(): boolean;
  get _filter(): boolean;
  get _input(): boolean;
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcChipSetDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcChipSetDirective, "[mdcChipSet]", never, {
    "mdcChipSet": {
      "alias": "mdcChipSet";
      "required": false;
    };
  }, {}, ["_chips"], never, false, never>;
}
export declare const CHIP_DIRECTIVES: (typeof MdcChipIconDirective | typeof MdcChipTextDirective | typeof MdcChipDirective | typeof MdcChipSetDirective)[];
/** @docs-private */
export interface FocusTrapHandle {
  readonly active: boolean;
  untrap(): any;
}
/** @docs-private */
export declare abstract class AbstractMdcFocusInitial {
  /** @docs-private */ readonly priority: number;
  readonly _elm: ElementRef;
}
/** @docs-private */
export declare abstract class AbstractMdcFocusTrap {
  constructor();
  abstract trapFocus(): FocusTrapHandle;
}
/**
 * Directive for the title of a dialog (<code>mdcDialog</code>).
 * This should be used for the child of an element with the <code>mdcDialogHeader</code>
 * directive.
 */
export declare class MdcDialogHeaderTitleDirective {
  _cls: boolean;
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcDialogHeaderTitleDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcDialogHeaderTitleDirective, "[mdcDialogHeaderTitle]", never, {}, {}, never, never, false, never>;
}
/**
 * Directive for the header of a dialog (<code>mdcDialog</code>).
 * This should be used on the first child element of an <code>mdcDialogSurface</code>
 * directive. Add the title of the dialog in a child element with the
 * <code>mdcDialogHeaderTitle</code> directive.
 */
export declare class MdcDialogHeaderDirective {
  _cls: boolean;
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcDialogHeaderDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcDialogHeaderDirective, "[mdcDialogHeader]", never, {}, {}, never, never, false, never>;
}
/**
 * Directive for the body part of a dialog (<code>mdcDialog</code>).
 * This should be added to a child element of an <code>mdcDialogSurface</code>
 * directive.
 */
export declare class MdcDialogBodyDirective {
  _elm: ElementRef;
  _cls: boolean;
  private _scrollable;
  constructor(_elm: ElementRef);
  /**
   * Set this property to true for dialog content that won't be able to fit the screen
   * without scrolling. It will give the body a max-height, and thus (when necessary) will
   * make the content scrollable.
   * The <code>max-height</code> value that is applied can be overridden via the
   * <code>.mdc-dialog__body--scrollable</code> selector in CSS.
   */
  get scrollable(): any;
  set scrollable(val: any);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcDialogBodyDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcDialogBodyDirective, "[mdcDialogBody]", never, {
    "scrollable": {
      "alias": "scrollable";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
/**
 * Directive for footer of a dialog (<code>mdcDialog</code>).
 * This should be added to a child element of an <code>mdcDialogSurface</code>
 * directive.
 * The footer typically contains buttons, for which the <code>mdcButton</code>
 * directive should be used. Cancel and accept buttons should also be marked
 * with an <code>mdcDialogCancel</code> or <code>mdcDialogAccept</code>
 * directive.
 */
export declare class MdcDialogFooterDirective implements AfterContentInit {
  private _rndr;
  _cls: boolean;
  _buttons: QueryList<MdcButtonDirective>;
  constructor(_rndr: Renderer2);
  ngAfterContentInit(): void;
  private initButtons;
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcDialogFooterDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcDialogFooterDirective, "[mdcDialogFooter]", never, {}, {}, ["_buttons"], never, false, never>;
}
/**
 * Directive to mark the accept button of a <code>mdcDialog</code>. This directive should
 * be used in combination with the <code>mdcButton</code> directive. Accept button presses
 * trigger the <code>accept</code> event on the dialog.
 * </p><p>
 * When the dialog is marked with the <code>mdcFocusTrap</code> directive, the focus trap will
 * focus this button when activated. If you want to focus another element in the dialog
 * instead, add the <code>mdcFocusInitial</code> directive to that element.
 */
export declare class MdcDialogAcceptDirective extends AbstractMdcFocusInitial {
  _elm: ElementRef;
  /** @docs-private */ readonly priority = 1;
  _cls: boolean;
  constructor(_elm: ElementRef);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcDialogAcceptDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcDialogAcceptDirective, "[mdcDialogAccept]", never, {}, {}, never, never, false, never>;
}
/**
 * Directive to mark the cancel button of a <code>mdcDialog</code>. This directive should
 * be used in combination with the <code>mdcButton</code> directive. Cancel button presses
 * trigger the <code>cancel</code> event on the dialog.
 */
export declare class MdcDialogCancelDirective {
  _elm: ElementRef;
  _cls: boolean;
  constructor(_elm: ElementRef);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcDialogCancelDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcDialogCancelDirective, "[mdcDialogCancel]", never, {}, {}, never, never, false, never>;
}
/**
 * Directive for the backdrop of a dialog. The backdrop provides the styles for overlaying the
 * page content when the dialog is opened. This guides user attention to the dialog.
 */
export declare class MdcDialogBackdropDirective {
  _cls: boolean;
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcDialogBackdropDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcDialogBackdropDirective, "[mdcDialogBackdrop]", never, {}, {}, never, never, false, never>;
}
/**
 * Directive for the surface of a dialog. The surface contains the actual comtent of a dialog,
 * wrapped in elements with the <code>mdcDialogHeader</code>, <code>mdcDialogBody</code>,
 * and <code>mdcDialogFooter</code> directives.
 */
export declare class MdcDialogSurfaceDirective {
  _elm: ElementRef;
  _cls: boolean;
  constructor(_elm: ElementRef);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcDialogSurfaceDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcDialogSurfaceDirective, "[mdcDialogSurface]", never, {}, {}, never, never, false, never>;
}
/**
 * Directive for creating a modal dialog with Material Design styling. The dialog should have two
 * child elements: a surface (marked with the <code>mdcDialogSurface</code> directive), and a
 * backdrop (marked with the <code>mdcDialogBackdrop</code> directive).
 * </p><p>
 * For an accessible user experience, the surface behind the dialog should not be accessible.
 * This can be achieved by adding the <code>mdcFocusTrap</code> directive to the dialog element
 * as well.
 */
export declare class MdcDialogDirective implements AfterContentInit, OnDestroy {
  private _elm;
  private _rndr;
  private _registry;
  private _focusTrap;
  _cls: boolean;
  _surface: MdcDialogSurfaceDirective;
  _accept: QueryList<MdcDialogAcceptDirective>;
  _cancel: QueryList<MdcDialogCancelDirective>;
  /**
   * Event emitted when the user accepts the dialog, e.g. by clicking the accept (<code>mdcDialogAccept</code>)
   * button.
   */
  accept: EventEmitter<void>;
  /**
   * Event emitted when the user cancels the dialog, e.g. by clicking the cancel (<code>mdcDialogCancel</code>)
   * button, or by pressing the Escape key (for dialogs with a focus-trap that is configured to close on Escape)
   */
  cancel: EventEmitter<void>;
  private _initialized;
  private focusTrapHandle;
  private mdcAdapter;
  private foundation;
  constructor(_elm: ElementRef, _rndr: Renderer2, _registry: MdcEventRegistry, _focusTrap: AbstractMdcFocusTrap);
  ngAfterContentInit(): void;
  ngOnDestroy(): void;
  /**
   * Call this method to open the dialog.
   */
  open(): void;
  private trapFocus;
  private untrapFocus;
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcDialogDirective, [null, null, null, {
    optional: true;
    self: true;
  }]>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcDialogDirective, "[mdcDialog]", ["mdcDialog"], {}, {
    "accept": "accept";
    "cancel": "cancel";
  }, ["_surface", "_accept", "_cancel"], never, false, never>;
}
export declare const DIALOG_DIRECTIVES: (typeof MdcDialogHeaderTitleDirective | typeof MdcDialogFooterDirective | typeof MdcDialogCancelDirective | typeof MdcDialogDirective)[];
/**
 * @docs-private
 * Represents the different types of drawers that are supported: permanent, persistent, and temporary.
 */
type MdcDrawerType = 'permanent' | 'persistent' | 'temporary';
/**
 * @docs-private
 * Base class for child elements of any type of drawer. The drawer will pass information to child
 * directives that provide themselve as <code>AbstractDrawerElement</code>.
 */
declare abstract class AbstractDrawerElement {
  _drawerType: MdcDrawerType;
}
/**
 * A toolbar spacer is an optional first child of an <code>mdcDrawer</code>.
 * A toolbar spacer adds space to the drawer in the same amount of the space that the toolbar takes up in your application.
 * This is useful for visual alignment and consistency. Note that you can place content inside the toolbar spacer.
 */
export declare class MdcDrawerToolbarSpacerDirective extends AbstractDrawerElement {
  _cls: boolean;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcDrawerToolbarSpacerDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcDrawerToolbarSpacerDirective, "[mdcDrawerToolbarSpacer]", never, {}, {}, never, never, false, never>;
}
/**
 * A toolbar header is an optional first child of an <code>mdcDrawer</code>.
 * A toolbar header adds space to create a 16:9 drawer header.
 * It's often used for user account selection or profile information.
 * </p><p>
 * To place content inside a toolbar header, add a child element with the
 * <code>mdcDrawerHeaderContent</code> directive.
 */
export declare class MdcDrawerHeaderDirective extends AbstractDrawerElement {
  _cls: boolean;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcDrawerHeaderDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcDrawerHeaderDirective, "[mdcDrawerHeader]", never, {}, {}, never, never, false, never>;
}
/**
 * Directive for the content of a drawer header. This should be the child of an
 * <code>mdcDrawerHeader</code> directive. The content of the header will be bottom
 * aligned.
 */
export declare class MdcDrawerHeaderContentDirective extends AbstractDrawerElement {
  _cls: boolean;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcDrawerHeaderContentDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcDrawerHeaderContentDirective, "[mdcDrawerHeaderContent]", never, {}, {}, never, never, false, never>;
}
/**
 * Directive for the drawer content. You would typically also apply the <code>mdcList</code>
 * or <code>mdcListGroup</code> directive to the drawer content (see the examples).
 */
export declare class MdcDrawerContentDirective extends AbstractDrawerElement {
  _cls: boolean;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcDrawerContentDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcDrawerContentDirective, "[mdcDrawerContent]", never, {}, {}, never, never, false, never>;
}
/**
 * A standalone <code>mdcDrawer</code> is a <i>permanent</i> drawer. A <i>permanent</i>
 * drawer is always open, sitting to the side of the content. It is appropriate for any
 * display size larger than mobile.
 * </p><p>
 * To make a drawer that can be opened/closed, wrap the <code>mdcDrawer</code> inside an
 * <code>mdcDrawerContainer</code>. That makes the drawer a <i>persistent</i> or
 * <i>temporary</i> drawer. See <code>MdcDrawerContainerDirective</code> for more information.
 */
export declare class MdcDrawerDirective implements AfterContentInit {
  _elm: ElementRef;
  private initialized;
  private type;
  _children: QueryList<AbstractDrawerElement>;
  constructor(_elm: ElementRef);
  ngAfterContentInit(): void;
  private updateTypeForChildren;
  _setType(drawerType: MdcDrawerType): void;
  get _isPermanent(): boolean;
  get _isContainedDrawer(): boolean;
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcDrawerDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcDrawerDirective, "[mdcDrawer]", never, {}, {}, ["_children"], never, false, never>;
}
/**
 * Wrap an <code>mdcDrawer</code> inside a <code>mdcDrawerContainer</code> to make it a
 * persistent or temporary drawer. Persistent and temporary drawers are slideable: they
 * can be opened or closed by the user, or by code.
 */
export declare class MdcDrawerContainerDirective implements AfterContentInit, OnDestroy {
  protected _elm: ElementRef;
  protected _rndr: Renderer2;
  protected _registry: MdcEventRegistry;
  private initialized;
  private openMem;
  private mdcAdapter;
  _drawers: QueryList<MdcDrawerDirective>;
  /**
   * Event emitted when the drawer is opened or closed. The event value will be
   * <code>true</code> when the drawer is opened, and <code>false</code> when the
   * drawer is closed.
   */
  openChange: EventEmitter<boolean>;
  private type;
  private foundation;
  constructor(_elm: ElementRef, _rndr: Renderer2, _registry: MdcEventRegistry);
  ngAfterContentInit(): void;
  ngOnDestroy(): void;
  private updateType;
  private destroyDrawer;
  private initDrawer;
  private createAdapter;
  private hasNecessaryDom;
  private get drawer();
  private forDrawer;
  /**
   * Set the type of drawer. Either <code>persistent</code> or <code>temporary</code>.
   * The default (when no value given) is <code>persistent</code>. Please note that
   * a third type of drawer exists: the <code>permanent</code> drawer. But a permanent
   * drawer is created by not wrapping your <code>mdcDrawer</code> in a
   * <code>mdcDrawerContainer</code>.
   */
  get mdcDrawerContainer(): 'persistent' | 'temporary' | null;
  set mdcDrawerContainer(value: string | null);
  get _isPersistent(): boolean;
  get _isTemporary(): boolean;
  get _isOpenCls(): any;
  /**
   * Input to open (assign value <code>true</code>) or close (assign value <code>false</code>)
   * the drawer.
   */
  get open(): any;
  set open(value: any);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcDrawerContainerDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcDrawerContainerDirective, "[mdcDrawerContainer]", never, {
    "mdcDrawerContainer": {
      "alias": "mdcDrawerContainer";
      "required": false;
    };
    "open": {
      "alias": "open";
      "required": false;
    };
  }, {
    "openChange": "openChange";
  }, ["_drawers"], never, false, never>;
}
/**
 * Directive for elevating an element above its surface.
 */
export declare class MdcElevationDirective {
  private rndr;
  private _elm;
  private _z;
  private _transition;
  constructor(rndr: Renderer2, _elm: ElementRef);
  /**
   * Input for setting the elevation (z-space). The value sould be in the range [0, 24].
   * When set to 0, the element will not be elevated! The default value is 1.
   */
  get mdcElevation(): string | number;
  set mdcElevation(value: string | number);
  /**
   * When this input is defined and does not have value false, changes of the elevation
   * will be animated.
   */
  get animateTransition(): any;
  set animateTransition(value: any);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcElevationDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcElevationDirective, "[mdcElevation]", never, {
    "mdcElevation": {
      "alias": "mdcElevation";
      "required": false;
    };
    "animateTransition": {
      "alias": "animateTransition";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
/**
 * Directive for the icon of a Floating Action Button
 * (<code>MdcFabDirective</code>).
 */
export declare class MdcFabIconDirective {
  _cls: boolean;
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcFabIconDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcFabIconDirective, "[mdcFabIcon]", never, {}, {}, never, never, false, never>;
}
/**
 * Material design Floating Action Button. The element should embed
 * an icon element with the <code>MdcFabIconDirective</code>.
 */
export declare class MdcFabDirective extends AbstractMdcRipple implements AfterContentInit, OnDestroy {
  private _elm;
  _cls: boolean;
  private _mini;
  private _exited;
  constructor(_elm: ElementRef, renderer: Renderer2, registry: MdcEventRegistry);
  ngAfterContentInit(): void;
  ngOnDestroy(): void;
  /**
   * When this input is defined and does not have value false, the FAB will
   * be modified to a smaller size.
   */
  get mini(): any;
  set mini(val: any);
  /**
   * Setting this property to true will animate the FAB out of view.
   * Setting it to false will animate the FAB back into view.
   */
  get exited(): any;
  set exited(val: any);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcFabDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcFabDirective, "[mdcFab]", never, {
    "mini": {
      "alias": "mini";
      "required": false;
    };
    "exited": {
      "alias": "exited";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
/** @docs-private */
interface MdcFloatingLabelAdapter {
  addClass: (className: string) => void;
  removeClass: (className: string) => void;
  getWidth: () => number;
  registerInteractionHandler: (evtType: string, handler: EventListener) => void;
  deregisterInteractionHandler: (evtType: string, handler: EventListener) => void;
}
/** @docs-private */
declare abstract class AbstractMdcLabel {
  abstract for: string;
  abstract _elm: ElementRef;
}
/**
 * Directive for the floating label of input fields. Flaoting labels are used by
 * <code>mdcTextField</code> and <code>mdcSelect</code> to display the type of input
 * the field requires. Floating labels are resting when the field is inactive, and
 * float when the field is active.
 * For an <code>mdcTextField</code> the label must be added just after the
 * <code>mdcTextFieldInput</code> as a direct child of an
 * <code>mdcTextField</code>. There is no need to assign the <code>for</code>
 * attribute, as the label will automatically get its <code>for</code> attribute assigned
 * to the id of the parent <code>mdcInput</code>.
 */
export declare class MdcFloatingLabelDirective extends AbstractMdcLabel implements AfterContentInit, OnDestroy {
  private _rndr;
  _elm: ElementRef;
  private registry;
  _initialized: boolean;
  /** @docs-private */
  for: string;
  _cls: boolean;
  _mdcAdapter: MdcFloatingLabelAdapter;
  _foundation: {
    init: Function;
    destroy: Function;
    float: (should: boolean) => void;
    shake: (should: boolean) => void;
    getWidth: () => number;
  };
  constructor(_rndr: Renderer2, _elm: ElementRef, registry: MdcEventRegistry);
  ngAfterContentInit(): void;
  ngOnDestroy(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcFloatingLabelDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcFloatingLabelDirective, "label[mdcFloatingLabel]", never, {}, {}, never, never, false, never>;
}
/**
 * When placed on a child element of an <code>mdcFocusTrap</code>, the focus trap
 * will try to move focus to this element when the focus trap is activated.
 */
export declare class MdcFocusInitialDirective extends AbstractMdcFocusInitial {
  _elm: ElementRef;
  /** @docs-private */ readonly priority = 100;
  constructor(_elm: ElementRef);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcFocusInitialDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcFocusInitialDirective, "[mdcFocusInitial]", never, {}, {}, never, never, false, never>;
}
/**
 * Directive for trapping focus (by key and/or mouse input) inside an element. To be used
 * for e.g. modal dialogs, where focus must be constrained for an accesssible experience.
 * Use <code>mdcFocusInitial</code> on a child element if a specific element needs to get
 * focus upon activation of the trap. In the absense of an <code>mdcFocusInitial</code>,
 * or when that element can't be focused, the focus trap will activate the first tabbable
 * child element of the focus trap.
 */
export declare class MdcFocusTrapDirective extends AbstractMdcFocusTrap implements OnDestroy {
  private _elm;
  private _untrapOnOutsideClick;
  private _ignoreEscape;
  _focusInitial: QueryList<AbstractMdcFocusInitial>;
  constructor(_elm: ElementRef);
  ngOnDestroy(): void;
  /** @docs-private */
  trapFocus(): FocusTrapHandle;
  /**
   * Set this property to have clicks outside the focus area untrap the focus.
   * The value is taken when the trap is activated. Thus changing the value
   * while a focus trap is active does not affect the behavior of that focus trap.
   */
  get untrapOnOutsideClick(): any;
  set untrapOnOutsideClick(value: any);
  /**
   * Set this property to ignore the escape key. The default is to deactivate the
   * trap when a user presses the escape key.
   * The value is taken when the trap is activated. Thus changing the value
   * while a focus trap is active does not affect the behavior of that focus trap.
   */
  get ignoreEscape(): any;
  set ignoreEscape(value: any);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcFocusTrapDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcFocusTrapDirective, "[mdcFocusTrap]", never, {
    "untrapOnOutsideClick": {
      "alias": "untrapOnOutsideClick";
      "required": false;
    };
    "ignoreEscape": {
      "alias": "ignoreEscape";
      "required": false;
    };
  }, {}, ["_focusInitial"], never, false, never>;
}
export declare const FOCUS_TRAP_DIRECTIVES: (typeof MdcFocusInitialDirective | typeof MdcFocusTrapDirective)[];
export declare class MdcFormFieldInputDirective extends AbstractMdcInput {
  _elm: ElementRef;
  _cntr: NgControl;
  private _id;
  private _disabled;
  constructor(_elm: ElementRef, _cntr: NgControl);
  get id(): string;
  set id(value: string);
  get disabled(): any;
  set disabled(value: any);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcFormFieldInputDirective, [null, {
    optional: true;
    self: true;
  }]>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcFormFieldInputDirective, "input[mdcFormFieldInput], textarea[mdcFormFieldInput]", never, {
    "id": {
      "alias": "id";
      "required": false;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
export declare class MdcFormFieldLabelDirective extends AbstractMdcLabel {
  _elm: ElementRef;
  for: string;
  constructor(_elm: ElementRef);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcFormFieldLabelDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcFormFieldLabelDirective, "label[mdcFormFieldLabel]", never, {
    "for": {
      "alias": "for";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
export declare class MdcFormFieldDirective implements AfterContentInit, OnDestroy {
  private renderer;
  private root;
  private registry;
  _cls: boolean;
  private _alignEnd;
  rippleChild: AbstractMdcRipple;
  mdcInput: AbstractMdcInput;
  mdcLabel: AbstractMdcLabel;
  private mdcAdapter;
  private foundation;
  constructor(renderer: Renderer2, root: ElementRef, registry: MdcEventRegistry);
  ngAfterContentInit(): void;
  ngOnDestroy(): void;
  get alignEnd(): any;
  set alignEnd(val: any);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcFormFieldDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcFormFieldDirective, "[mdcFormField]", never, {
    "alignEnd": {
      "alias": "alignEnd";
      "required": false;
    };
  }, {}, ["rippleChild", "mdcInput", "mdcLabel"], never, false, never>;
}
/**
 * Directive for an icon nested inside a <code>MdcIconButtonDirective</code>.
 * This directive is only required when the icon font for an <code>mdcIconButton</code>
 * uses CSS pseudo-elements in order to provide the icon. This is how Font Awesome, and many
 * other icon font libraries provide their icons. These pseudo elements would interfere
 * with the pseudo elements that <code>mdcIconButton</code> uses to provide a ripple
 * effect. This can be solved by having a child element in your <code>mdcIconButton</code>
 * and set this directive on it. The icon classes will then be applied to the child
 * element, and won't interfere with the icon button pseudo elements anymore.
 * </p><p>
 * For icon fonts that don't use pseudo elements (such as the Material
 * Design Icons from Google), this directive is not necessary.
 */
export declare class MdcIconButtonIconDirective {
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcIconButtonIconDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcIconButtonIconDirective, "[mdcIconButtonIcon]", never, {}, {}, never, never, false, never>;
}
/**
 * Directive for an icon button. Icon buttons can be used with a font icon library such as
 * <a href="https://material.io/tools/icons" target="_blank">Google Material Icons</a>, or
 * svg elements. They provide material styling and a ripple to the icon. Use it on anchor and
 * button tags. For toggling icon buttons, see <code>MdcIconButtonToggleDirective</code>.
 * When the applied icon font uses CSS pseudo elements, make the icon a child element of the
 * <code>mdcIconButton</code>, and give it the <code>mdcIconButtonIcon</code> directive.
 */
export declare class MdcIconButtonDirective extends AbstractMdcIcon implements AfterContentInit, OnDestroy {
  _hostClass: boolean;
  private _disabled;
  constructor(_elm: ElementRef, renderer: Renderer2, registry: MdcEventRegistry);
  ngAfterContentInit(): void;
  ngOnDestroy(): void;
  /**
   * To disable the icon, set this input to true.
   */
  get disabled(): any;
  set disabled(value: any);
  /** @docs-private */
  protected isRippleUnbounded(): boolean;
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcIconButtonDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcIconButtonDirective, "[mdcIconButton]:not([iconOn])", never, {
    "disabled": {
      "alias": "disabled";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
/**
 * Directive for creating a Material Design icon toggle button: a button that toggles state, and
 * switches the icon based on the value of the toggle.
 * </p><p>
 * When the applied icon font uses CSS pseudo elements, add a child element for the actual icon,
 * and give that element the <code>mdcIconButtonIcon</code> directive. The icon button will
 * then update the child element with the correct icon if it is toggled.
 */
export declare class MdcIconButtonToggleDirective extends AbstractMdcIcon implements AfterContentInit {
  _hostClass: boolean;
  _innerIcon: ElementRef;
  /**
   * Event emitted when the state of the icon toggle changes (for example when a user clicks
   * the icon).
   */
  onChange: EventEmitter<boolean>;
  private _onChange;
  private _onTouched;
  private _initialized;
  private _on;
  private _labelOn;
  private _labelOff;
  private _iconOn;
  private _iconOff;
  private _iconIsClass;
  private _disabled;
  private toggleAdapter;
  private toggleFoundation;
  constructor(_elm: ElementRef, rndr: Renderer2, registry: MdcEventRegistry);
  ngAfterContentInit(): void;
  ngOnDestroy(): void;
  private refreshToggleData;
  private get iconElm();
  private notifyChange;
  /** @docs-private */
  writeValue(obj: any): void;
  /** @docs-private */
  registerOnChange(onChange: (value: any) => void): void;
  /** @docs-private */
  registerOnTouched(onTouched: () => any): void;
  /** @docs-private */
  setDisabledState(disabled: boolean): void;
  /** @docs-private */
  protected isRippleUnbounded(): boolean;
  /**
   * The current state of the icon (true for on/pressed, false for off/unpressed).
   */
  get on(): any;
  set on(value: any);
  /**
   * The aria-label to use for the on/pressed state of the icon.
   */
  get labelOn(): string;
  set labelOn(value: string);
  /**
   * The aria-label to use for the off/unpressed state of the icon.
   */
  get labelOff(): string;
  set labelOff(value: string);
  /**
   * The icon to use for the on/pressed state of the icon.
   */
  get iconOn(): string;
  set iconOn(value: string);
  /**
   * The icon to use for the off/unpressed state of the icon.
   */
  get iconOff(): string;
  set iconOff(value: string);
  /**
   * Some icon fonts (such as Font Awesome) use CSS class names to select the icon to show.
   * Others, such as the Material Design Icons from Google use ligatures (allowing selection of
   * the icon by using their textual name). When <code>iconIsClass</code> is true, the directive
   * assumes <code>iconOn</code>, and <code>iconOff</code> represent class names. When
   * <code>iconIsClass</code> is false, the directive assumes the use of ligatures.
   * When iconIsClass is not set, the value depends on the availability of a nested
   * <code>mdcIconButtonIcon</code> directive: when that exists, <code>iconOn</code> and <code>iconOff</code>
   * are expected to be classnames, otherwise they are expected to be ligatures. This is usually
   * the intended behaviour, so in most cases you don't need to initialize the <code>iconIsClass</code>
   * property.
   */
  get iconIsClass(): any;
  set iconIsClass(value: any);
  _onBlur(): void;
  /**
   * To disable the icon, set this input to true.
   */
  get disabled(): any;
  set disabled(value: any);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcIconButtonToggleDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcIconButtonToggleDirective, "[mdcIconButton][iconOn]", never, {
    "on": {
      "alias": "on";
      "required": false;
    };
    "labelOn": {
      "alias": "labelOn";
      "required": false;
    };
    "labelOff": {
      "alias": "labelOff";
      "required": false;
    };
    "iconOn": {
      "alias": "iconOn";
      "required": false;
    };
    "iconOff": {
      "alias": "iconOff";
      "required": false;
    };
    "iconIsClass": {
      "alias": "iconIsClass";
      "required": false;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
    };
  }, {
    "onChange": "onChange";
  }, ["_innerIcon"], never, false, never>;
}
/**
 * Directive for adding Angular Forms (<code>ControlValueAccessor</code>) behavior to an
 * <code>MdcIconButtonDirective</code>. Allows the use of the Angular Forms API with
 * icon toggle buttons, e.g. binding to <code>[(ngModel)]</code>, form validation, etc.
 */
export declare class MdcFormsIconButtonDirective implements ControlValueAccessor {
  private mdcIconButton;
  constructor(mdcIconButton: MdcIconButtonToggleDirective);
  /** @docs-private */
  writeValue(obj: any): void;
  /** @docs-private */
  registerOnChange(onChange: (value: any) => void): void;
  /** @docs-private */
  registerOnTouched(onTouched: () => any): void;
  /** @docs-private */
  setDisabledState(disabled: boolean): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcFormsIconButtonDirective, [{
    self: true;
  }]>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcFormsIconButtonDirective, "[mdcIconButton][iconOn][formControlName],[mdcIconButton][iconOn][formControl],[mdcIconButton][iconOn][ngModel]", never, {}, {}, never, never, false, never>;
}
export declare const ICON_BUTTON_DIRECTIVES: (typeof MdcIconButtonIconDirective | typeof MdcIconButtonDirective | typeof MdcIconButtonToggleDirective | typeof MdcFormsIconButtonDirective)[];
/**
 * Directive for an icon nested inside a <code>MdcIconToggleDirective</code>.
 * This directive is only needed when the icon font uses CSS pseudo-elements in order
 * to provide the icon. This is how Font Awesome, and many other icon font libraries
 * provide the icons.
 * For icon fonts that don't use pseudo elements (such as the Material Design Icons from Google),
 * this directive is not necessary.
 */
export declare class MdcIconToggleIconDirective {
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcIconToggleIconDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcIconToggleIconDirective, "[mdcIconToggleIcon]", never, {}, {}, never, never, false, never>;
}
/**
 * Directive for creating a Material Design icon toggle button.
 * The icon toggle is fully accessible, and works with any icon font.
 * When the icon font uses CSS pseudo-elements in order to display the icon,
 * embed an <code>MdcIconToggleIconDirective</code> inside this directive for
 * the actual icon. (Otherwise the pseudo-elements used for showing the icon
 * will interfere with the pseudo-elements this directive uses for showing
 * ripple styles).
 */
export declare class MdcIconToggleDirective extends AbstractMdcIcon implements AfterContentInit {
  private renderer;
  private registry;
  _hostClass: boolean;
  _role: string;
  _innerIcon: ElementRef;
  /**
   * Event emitted when the state of the icon changes (for example when a user clicks
   * the icon).
   */
  onChange: EventEmitter<boolean>;
  private _onChange;
  private _onTouched;
  private _beforeInitQueu;
  private _initialized;
  private _labelOn;
  private _labelOff;
  private _iconOn;
  private _iconOff;
  private _iconIsClass;
  private mdcAdapter;
  private foundation;
  constructor(_elm: ElementRef, renderer: Renderer2, registry: MdcEventRegistry);
  ngAfterContentInit(): void;
  ngOnDestroy(): void;
  private execAfterInit;
  private refreshData;
  private initDefaultAttributes;
  private initializeData;
  private get renderIconAsClass();
  private createDataAttrForToggle;
  /** @docs-private */
  writeValue(obj: any): void;
  /** @docs-private */
  registerOnChange(onChange: (value: any) => void): void;
  /** @docs-private */
  registerOnTouched(onTouched: () => any): void;
  /** @docs-private */
  setDisabledState(disabled: boolean): void;
  /** @docs-private */
  protected isRippleUnbounded(): boolean;
  /** @docs-private */
  protected isRippleSurfaceActive(): boolean;
  /**
   * The current state of the icon (true for on/pressed, false for off/unpressed).
   */
  get on(): any;
  set on(value: any);
  /**
   * The aria-label to use for the on/pressed state of the icon.
   */
  get labelOn(): string;
  set labelOn(value: string);
  /**
   * The aria-label to use for the off/unpressed state of the icon.
   */
  get labelOff(): string;
  set labelOff(value: string);
  /**
   * The icon to use for the on/pressed state of the icon.
   */
  get iconOn(): string;
  set iconOn(value: string);
  /**
   * The icon to use for the off/unpressed state of the icon.
   */
  get iconOff(): string;
  set iconOff(value: string);
  /**
   * Some icon fonts (such as Font Awesome) use CSS class names to select the icon to show.
   * Others, such as the Material Design Icons from Google use ligatures (allowing selection of
   * the icon by using their textual name). When <code>iconIsClass</code> is true, the directive
   * assumes <code>iconOn</code>, and <code>iconOff</code> represent class names. When
   * <code>iconIsClass</code> is false, the directive assumes the use of ligatures.
   * <p>
   * When <code>iconIsClass</code> is not assigned, the directive bases its decision on whether
   * or not an embedded <code>MdcIconToggleIconDirective</code> is used.
   * In most cases you won't need to set this input, as the default based on an embedded
   * <code>MdcIconToggleIconDirective</code> is typically what you need.
   * </p>
   */
  get iconIsClass(): any;
  set iconIsClass(value: any);
  /**
   * To disable the icon toggle, set this input to true.
   */
  get disabled(): any;
  set disabled(value: any);
  _onBlur(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcIconToggleDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcIconToggleDirective, "[mdcIconToggle]", never, {
    "on": {
      "alias": "on";
      "required": false;
    };
    "labelOn": {
      "alias": "labelOn";
      "required": false;
    };
    "labelOff": {
      "alias": "labelOff";
      "required": false;
    };
    "iconOn": {
      "alias": "iconOn";
      "required": false;
    };
    "iconOff": {
      "alias": "iconOff";
      "required": false;
    };
    "iconIsClass": {
      "alias": "iconIsClass";
      "required": false;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
    };
  }, {
    "onChange": "onChange";
  }, ["_innerIcon"], never, false, never>;
}
/**
 * Directive for adding Angular Forms (<code>ControlValueAccessor</code>) behavior to an
 * <code>MdcIconToggleDirective</code>. Allows the use of the Angular Forms API with
 * icon toggles, e.g. binding to <code>[(ngModel)]</code>, form validation, etc.
 */
export declare class MdcFormsIconToggleDirective implements ControlValueAccessor {
  private mdcIconToggle;
  constructor(mdcIconToggle: MdcIconToggleDirective);
  /** @docs-private */
  writeValue(obj: any): void;
  /** @docs-private */
  registerOnChange(onChange: (value: any) => void): void;
  /** @docs-private */
  registerOnTouched(onTouched: () => any): void;
  /** @docs-private */
  setDisabledState(disabled: boolean): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcFormsIconToggleDirective, [{
    self: true;
  }]>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcFormsIconToggleDirective, "[mdcIconToggle][formControlName],[mdcIconToggle][formControl],[mdcIconToggle][ngModel]", never, {}, {}, never, never, false, never>;
}
/**
 * Directive for creating a Material Design linear progress indicator.
 * The current implementation will add and manage all DOM child elements that
 * are required for the wrapped <code>mdc-linear-progress</code> component.
 * Future implementations will also support supplying (customized)
 * DOM children.
 */
export declare class MdcLinearProgressDirective implements AfterContentInit, OnDestroy {
  private _rndr;
  private _root;
  private _registry;
  _cls: boolean;
  _role: string;
  private _initialized;
  _indeterminate: boolean;
  _reverse: boolean;
  private _progress;
  private _buffer;
  private _closed;
  private _elmBuffer;
  private _elmPrimaryBar;
  private mdcAdapter;
  private foundation;
  constructor(_rndr: Renderer2, _root: ElementRef, _registry: MdcEventRegistry);
  ngAfterContentInit(): void;
  ngOnDestroy(): void;
  private initElements;
  private addElement;
  /**
   * Puts the progress indicator in 'indeterminate' state, signaling
   * that the exact progress on a measured task is not known.
   */
  get indeterminate(): any;
  set indeterminate(value: any);
  /**
   * Reverses the direction of the linear progress indicator.
   */
  get reversed(): any;
  set reversed(value: any);
  /**
   * Set the progress, the value should be between [0, 1].
   */
  get progressValue(): number | string;
  set progressValue(value: number | string);
  /**
   * Set the buffer progress, the value should be between [0, 1].
   */
  get bufferValue(): number | string;
  set bufferValue(value: number | string);
  /**
   * When set to true this closes (animates away) the progress bar,
   * when set to false this opens (animates into view) the progress bar.
   */
  get closed(): any;
  set closed(value: any);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcLinearProgressDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcLinearProgressDirective, "[mdcLinearProgress]", never, {
    "indeterminate": {
      "alias": "indeterminate";
      "required": false;
    };
    "reversed": {
      "alias": "reversed";
      "required": false;
    };
    "progressValue": {
      "alias": "progressValue";
      "required": false;
    };
    "bufferValue": {
      "alias": "bufferValue";
      "required": false;
    };
    "closed": {
      "alias": "closed";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
/**
 * Directive for a separator in a list (between list items), or as a separator between lists.
 * This directive also adds a "role" attribute to its element (depending on the context
 * where the divider is used).
 */
export declare class MdcListDividerDirective {
  private _elm;
  _cls: boolean;
  _role: string;
  _disabled: boolean;
  private _inset;
  private _padded;
  constructor(_elm: ElementRef);
  /**
   * When this input is defined and does not have value false, the divider is styled with
   * an inset.
   */
  get inset(): any;
  set inset(val: any);
  /**
   * When this input is defined and does not have value false, the divider leaves
   * gaps on each site to match the padding of <code>mdcListItemMeta</code>.
   */
  get padded(): any;
  set padded(val: any);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcListDividerDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcListDividerDirective, "[mdcListDivider]", never, {
    "inset": {
      "alias": "inset";
      "required": false;
    };
    "padded": {
      "alias": "padded";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
/**
 * Directive for the items of a material list.
 * This directive should be used for the direct children of a <code>MdcListDirective</code>.
 */
export declare class MdcListItemDirective extends AbstractMdcRipple implements AfterContentInit, OnDestroy {
  _elm: ElementRef;
  _cls: boolean;
  _role: any;
  private _initialized;
  private _interactive;
  private _disabled;
  private _selected;
  private _activated;
  /**
   * When a list is used inside an <code>mdcMenu</code>, or <code>mdcSelect</code>,
   * this property can be used to assign a value to this choice/selection item.
   */
  value: any;
  constructor(_elm: ElementRef, rndr: Renderer2, registry: MdcEventRegistry);
  ngAfterContentInit(): void;
  ngOnDestroy(): void;
  _setInteractive(interactive: boolean): void;
  /**
   * When a list is used inside an <code>mdcMenu</code>, or <code>mdcSelect</code>,
   * this property can be used to disable the item. When disabled, the list-item will have
   * the <code>aria-disabled</code> attribute, and for  <code>mdcMenu</code>,
   * or <code>mdcSelect</code> will set the <code>tabindex</code> to <code>-1</code>.
   */
  get disabled(): any;
  set disabled(val: any);
  /**
   * When this value is set to a value other than false, the list item will be
   * styled in a selected state. Note: selection and activation are different things.
   * Multiple items in a list can be selected, only one can be activated.
   * Selection is likely to change soon, activation is more permanent than selection.
   */
  get selected(): any;
  set selected(val: any);
  /**
   * When this value is set to a value other than false, the list item will be
   * styled in an activated state. Note: selection and activation are different things.
   * Multiple items in a list can be selected, only one can be activated.
   * Selection is likely to change soon, activation is more permanent than selection.
   */
  get activated(): any;
  set activated(val: any);
  get _tabIndex(): 0 | -1;
  get _ariaDisabled(): string;
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcListItemDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcListItemDirective, "[mdcListItem]", never, {
    "value": {
      "alias": "value";
      "required": false;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
    };
    "selected": {
      "alias": "selected";
      "required": false;
    };
    "activated": {
      "alias": "activated";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
/**
 * Directive to mark the first line of an item with "two line list" styling
 * according to the Material Design spec.
 * This directive, if used, should be the child of an <code>MdcListItemDirective</code>.
 * Using this directive inside any <code>mdcListItem</code> will put the list
 * "two line" mode.
 */
export declare class MdcListItemTextDirective {
  _cls: boolean;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcListItemTextDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcListItemTextDirective, "[mdcListItemText]", never, {}, {}, never, never, false, never>;
}
/**
 * Directive for the secondary text of an item with "two line list" styling.
 */
export declare class MdcListItemSecondaryTextDirective {
  _cls: boolean;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcListItemSecondaryTextDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcListItemSecondaryTextDirective, "[mdcListItemSecondaryText]", never, {}, {}, never, never, false, never>;
}
/**
 * Directive for the start detail item of a list item.
 * This directive, if used, should be the child of an <code>MdcListItemDirective</code>.
 */
export declare class MdcListItemGraphicDirective {
  _cls: boolean;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcListItemGraphicDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcListItemGraphicDirective, "[mdcListItemGraphic]", never, {}, {}, never, never, false, never>;
}
/**
 * Directive for the end detail item of a list item.
 * This directive, if used, should be the child of an <code>MdcListItemDirective</code>.
 */
export declare class MdcListItemMetaDirective {
  _cls: boolean;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcListItemMetaDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcListItemMetaDirective, "[mdcListItemMeta]", never, {}, {}, never, never, false, never>;
}
declare enum MdcListFunction {
  plain = 0,
  menu = 1
}
/**
 * Directive for a material list.
 * The children of this directive should either be <code>MdcListItemDirective</code>,
 * or <code>MdcListDividerDirective</code> elements.
 * This directive can optionally be contained in a <code>MdcListGroupDirective</code>, in a
 * <code>MdcMenuDirective</code>, or in a <code>MdcSelectDirective</code>.
 */
export declare class MdcListDirective implements AfterContentInit {
  _elm: ElementRef;
  _cls: boolean;
  _items: QueryList<MdcListItemDirective>;
  _texts: QueryList<MdcListItemTextDirective>;
  _twoLine: boolean;
  private _function;
  _hidden: boolean;
  private _dense;
  private _avatar;
  private _nonInteractive;
  constructor(_elm: ElementRef);
  ngAfterContentInit(): void;
  private updateItems;
  get _role(): string;
  get _ariaHidden(): string;
  get _isMenu(): boolean;
  _setFunction(val: MdcListFunction): void;
  /**
   * When this input is defined and does not have value false, the list will be styled more
   * compact.
   */
  get dense(): any;
  set dense(val: any);
  /**
   * When this input is defined and does not have value false, interactivity affordances for
   * the list will be disabled.
   */
  get nonInteractive(): any;
  set nonInteractive(val: any);
  /**
   * When this input is defined and does not have value false, elements with directive <code>mdcListItemGraphic</code>
   * will be styled for avatars: large, circular elements that lend themselves well to contact images, profile pictures, etc.
   */
  get avatarList(): any;
  set avatarList(val: any);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcListDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcListDirective, "[mdcList]", never, {
    "dense": {
      "alias": "dense";
      "required": false;
    };
    "nonInteractive": {
      "alias": "nonInteractive";
      "required": false;
    };
    "avatarList": {
      "alias": "avatarList";
      "required": false;
    };
  }, {}, ["_items", "_texts"], never, false, never>;
}
/**
 * Directive for a header inside a list group (<code>mdcListGroup</code>) directive.
 */
export declare class MdcListGroupSubHeaderDirective {
  _cls: boolean;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcListGroupSubHeaderDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcListGroupSubHeaderDirective, "[mdcListGroupSubHeader]", never, {}, {}, never, never, false, never>;
}
/**
 * Directive for a material designed list group, grouping several
 * <code>mdcList</code> lists.
 * List groups should contain elements with <code>mdcListGroupSubHeader</code>,
 * and <code>mdcList</code> directives.
 */
export declare class MdcListGroupDirective {
  _cls: boolean;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcListGroupDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcListGroupDirective, "[mdcListGroup]", never, {}, {}, never, never, false, never>;
}
/**
 * Data send by the <code>pick</code> event of <code>MdcMenuDirective</code>.
 */
interface MdcMenuSelection {
  /**
   * The <code>value</code> of the selected menu item (<code>MdcListItemDirective</code>).
   */
  value: any;
  /**
   * The index of the selected menu item (<code>MdcListItemDirective</code>).
   */
  index: number;
}
/**
 * Directive for an optional anchor to which a menu can position itself.
 * Use the <code>menuAnchor</code> input of <code>MdcMenuDirective</code>
 * to bind the menu to the anchor. The anchor must be a direct parent of the menu.
 * It will get the following styles to make the positioning work:
 * <code>position: relative; overflow: visible;</code>.
 */
export declare class MdcMenuAnchorDirective {
  _elm: ElementRef;
  _cls: boolean;
  constructor(_elm: ElementRef);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcMenuAnchorDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcMenuAnchorDirective, "[mdcMenuAnchor]", ["mdcMenuAnchor"], {}, {}, never, never, false, never>;
}
/**
 * Directive for a spec aligned material design Menu.
 * This directive should wrap an <code>MdcListDirective</code>. The <code>mdcList</code>
 * contains the menu items (and possible separators).
 */
export declare class MdcMenuDirective implements AfterContentInit, OnDestroy {
  _elm: ElementRef;
  private _rndr;
  private _registry;
  _cls: boolean;
  private _function;
  private _openMemory;
  private _openFrom;
  /**
   * Assign an (optional) <code>MdcMenuAnchorDirective</code>. If set the menu
   * will position itself relative to this anchor element. The anchor should be
   * a direct parent of this menu.
   */
  menuAnchor: MdcMenuAnchorDirective;
  /**
   * Event emitted when the user selects a value. The passed object contains a value
   * (set to the <code>value</code> of the selected list item), and an index
   * (set to the index of the selected list item).
   */
  pick: EventEmitter<MdcMenuSelection>;
  /**
   * Event emitted when the menu is closed without any selection being made.
   */
  cancel: EventEmitter<void>;
  /**
   * Event emitted when the menu is opened or closed.
   */
  openChange: EventEmitter<boolean>;
  private _lastList;
  _listQuery: QueryList<MdcListDirective>;
  private _prevFocus;
  private mdcAdapter;
  private foundation;
  _component: MDCMenu;
  constructor(_elm: ElementRef, _rndr: Renderer2, _registry: MdcEventRegistry);
  ngAfterContentInit(): void;
  ngOnDestroy(): void;
  private _onOpenClose;
  set _listFunction(val: MdcListFunction);
  get _list(): MdcListDirective;
  /**
   * When this input is defined and does not have value false, the menu will be opened,
   * otherwise the menu will be closed.
   */
  get open(): any;
  set open(val: any);
  /**
   * Set this value if you want to customize the direction from which the menu will be opened.
   * Note that without this setting the menu will base the direction upon its position in the viewport,
   * which is normally the right behavior. Use <code>'tl'</code> for top-left, <code>'br'</code>
   * for bottom-right, etc.
   */
  get openFrom(): 'tl' | 'tr' | 'bl' | 'br' | null;
  set openFrom(val: string | null);
  get _tl(): boolean;
  get _tr(): boolean;
  get _bl(): boolean;
  get _br(): boolean;
  /**
   * Assign any <code>HTMLElement</code> to this property to use as the viewport instead of
   * the window object. The menu will choose to open the menu from the top or bottom, and
   * from the left or right, based on the space available inside the viewport.
   * It's normally not needed to set this, and mainly added for the demos and examples.
   */
  viewport: HTMLElement;
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcMenuDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcMenuDirective, "[mdcMenu]", never, {
    "menuAnchor": {
      "alias": "menuAnchor";
      "required": false;
    };
    "open": {
      "alias": "open";
      "required": false;
    };
    "openFrom": {
      "alias": "openFrom";
      "required": false;
    };
    "viewport": {
      "alias": "viewport";
      "required": false;
    };
  }, {
    "pick": "pick";
    "cancel": "cancel";
    "openChange": "openChange";
  }, ["_listQuery"], never, false, never>;
}
/**
 * Directive for the input element of an <code>MdcRadioDirective</code>.
 */
export declare class MdcRadioInputDirective extends AbstractMdcInput {
  _elm: ElementRef;
  _cntr: NgControl;
  _cls: boolean;
  private _id;
  private _disabled;
  constructor(_elm: ElementRef, _cntr: NgControl);
  /** @docs-private */
  get id(): string;
  set id(value: string);
  /** @docs-private */
  get disabled(): any;
  set disabled(value: any);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcRadioInputDirective, [null, {
    optional: true;
    self: true;
  }]>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcRadioInputDirective, "input[mdcRadioInput][type=radio]", never, {
    "id": {
      "alias": "id";
      "required": false;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
/**
 * Directive for creating a Material Design radio button. The radio button is driven by an
 * underlying native radio input, which must use the <code>MdcRadioInputDirective</code>
 * directive.
 * The current implementation will add all other required DOM elements (such as the
 * background).
 * Future implementations will also support supplying (customized) background
 * elements.
 * </p><p>
 * This directive can be used together with an <code>mdcFormField</code> to
 * easily position radio buttons and their labels, see
 * <a href="/material/components/form-field">mdcFormField</a>.
 */
export declare class MdcRadioDirective extends AbstractMdcRipple implements AfterContentInit, OnDestroy {
  private renderer;
  private root;
  private registry;
  _cls: boolean;
  _input: MdcRadioInputDirective;
  private mdcAdapter;
  private foundation;
  constructor(renderer: Renderer2, root: ElementRef, registry: MdcEventRegistry);
  ngAfterContentInit(): void;
  ngOnDestroy(): void;
  private addBackground;
  /** @docs-private */
  protected getRippleInteractionElement(): ElementRef<any>;
  /** @docs-private */
  isRippleUnbounded(): boolean;
  /** @docs-private */
  isRippleSurfaceActive(): boolean;
  get _disabled(): any;
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcRadioDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcRadioDirective, "[mdcRadio]", never, {}, {}, ["_input"], never, false, never>;
}
/**
 * Directive for making an element a ripple surface. The ripple can be customized
 * with the provided
 * <a href="https://github.com/material-components/material-components-web/tree/master/packages/mdc-ripple#sass-apis"
 *   target="_blank">Sass Mixins</a>.
 * Alternatively you can set the <code>surface</code> to get a default styled ripple.
 */
export declare class MdcRippleDirective extends AbstractMdcRipple implements AfterContentInit, OnDestroy {
  private elm;
  private renderer;
  private registry;
  private _initialized;
  private _on;
  private _disabled;
  private _unbounded;
  private _surface;
  private _dim;
  constructor(elm: ElementRef, renderer: Renderer2, registry: MdcEventRegistry);
  ngAfterContentInit(): void;
  ngOnDestroy(): void;
  /** @docs-private */
  protected isRippleUnbounded(): boolean;
  /** @docs-private */
  protected isRippleSurfaceDisabled(): boolean;
  /** @docs-private */
  protected computeRippleBoundingRect(): any;
  /**
   * Set this input to false to remove the ripple effect from the surface.
   */
  get mdcRipple(): any;
  set mdcRipple(value: any);
  /**
   * When this input has a value other than false, the ripple is unbounded.
   * Surfaces for bounded ripples should have <code>overflow</code> set to hidden,
   * while surfaces for unbounded ripples should have it set to <code>visible</code>.
   */
  get unbounded(): any;
  set unbounded(value: any);
  get _attrUnbounded(): string;
  /**
   * This input sets the dimension of the ripple.
   * This input can be set to null for returning to the defaults, which uses the surface
   * element to compute the bounds of the ripple.
   */
  get dimension(): string | number;
  set dimension(value: string | number);
  /**
   * This input can be used to programmatically enable/disable the ripple.
   * When true, the ripple effect will be disabled, when false the ripple
   * effect will be enabled. When not set, or <code>null</code> (default)
   * the ripple effect enabled/disabled state depend on whether or not the
   * surface element has the <code>disabled</code> attribute set.
   */
  get disabled(): any;
  set disabled(value: any);
  /**
   * When this input has a value other than false, the ripple element will get the
   * "mdc-ripple-surface" class. That class has styling for bounded and unbounded
   * ripples in accordance with your theme customizations. Without this property,
   * you have to supply your own ripple styles, using the provided
   * <a href="https://github.com/material-components/material-components-web/tree/master/packages/mdc-ripple#sass-apis"
   *   target="_blank">Sass Mixins</a>.
   */
  get surface(): any;
  set surface(value: any);
  private reInit;
  private layout;
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcRippleDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcRippleDirective, "[mdcRipple]", never, {
    "mdcRipple": {
      "alias": "mdcRipple";
      "required": false;
    };
    "unbounded": {
      "alias": "unbounded";
      "required": false;
    };
    "dimension": {
      "alias": "dimension";
      "required": false;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
    };
    "surface": {
      "alias": "surface";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
/**
 * Directive for the select control of an <code>mdcSelect</code> directive.
 * Should be used as the first child element of the <code>mdcSelect</code>.
 */
export declare class MdcSelectControlDirective extends AbstractMdcInput implements OnInit, OnDestroy {
  _elm: ElementRef;
  private renderer;
  _registry: MdcEventRegistry;
  _cntr: NgControl;
  _cls: boolean;
  _onChange: (value: any) => void;
  private _id;
  private _disabled;
  private cachedId;
  constructor(_elm: ElementRef, renderer: Renderer2, _registry: MdcEventRegistry, _cntr: NgControl);
  ngOnInit(): void;
  ngOnDestroy(): void;
  /**
   * Mirrors the <code>id</code> attribute. If no id is assigned, this directive will
   * assign a unique id by itself. If an <code>mdcFloatingLabel</code> for this select control
   * is available, the <code>mdcFloatingLabel</code> will automatically set its <code>for</code>
   * attribute to this <code>id</code> value.
   */
  get id(): string;
  set id(value: string);
  /**
   * If set to a value other than false, the mdcSelectControl will be in disabled state.
   */
  get disabled(): any;
  set disabled(value: any);
  _newId(): string;
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcSelectControlDirective, [null, null, null, {
    optional: true;
    self: true;
  }]>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcSelectControlDirective, "select[mdcSelectControl]", never, {
    "id": {
      "alias": "id";
      "required": false;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
/**
 * Directive for a spec aligned material design 'Select Control'.
 * This directive should wrap an <code>mdcSelectControl</code>, and an
 * <code>mdcFloatingLabel</code> directive.
 */
export declare class MdcSelectDirective extends AbstractMdcRipple implements AfterContentInit, OnDestroy {
  private _elm;
  private _rndr;
  _cls: boolean;
  _control: MdcSelectControlDirective;
  _label: MdcFloatingLabelDirective;
  private _outlineSupport;
  private _initialized;
  private _box;
  private _outlined;
  private _bottomLineElm;
  private _lineRippleAdapter;
  private _lineRippleFoundation;
  private adapter;
  private foundation;
  constructor(_elm: ElementRef, _rndr: Renderer2, _registry: MdcEventRegistry);
  ngAfterContentInit(): void;
  ngOnDestroy(): void;
  private initComponent;
  private destroyComponent;
  private reconstructComponent;
  private initLineRipple;
  private destroyLineRipple;
  private initBox;
  private destroyBox;
  private initOutline;
  private destroyOutline;
  private recomputeOutline;
  /**
   * When this input is defined and does not have value false, the select will be styled as a
   * box select.
   */
  get box(): any;
  set box(val: any);
  /**
   * When this input is set to a value other than false, the select control will be styled
   * with a notched outline.
   */
  get outlined(): any;
  set outlined(val: any);
  get _disabled(): any;
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcSelectDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcSelectDirective, "[mdcSelect]", never, {
    "box": {
      "alias": "box";
      "required": false;
    };
    "outlined": {
      "alias": "outlined";
      "required": false;
    };
  }, {}, ["_control", "_label"], never, false, never>;
}
/**
 * Directive for creating a Material Design slider input.
 * (Modelled after the <code>&lt;input type="range"/&gt;</code> element).
 * The slider is fully accessible. The current implementation
 * will add and manage all DOM child elements that are required for the wrapped
 * <code>mdc-slider</code> component.
 * Future implementations will also support supplying (customized)
 * DOM children.
 */
export declare class MdcSliderDirective implements AfterContentInit, AfterViewInit, OnChanges, OnDestroy {
  private _rndr;
  private _root;
  private _registry;
  _cls: boolean;
  _role: string;
  /**
   * Event emitted when the value changes. The value may change because of user input,
   * or as a side affect of setting new min, max, or step values.
   */
  valueChange: EventEmitter<number>;
  /**
   * Event emitted when the min range value changes. This may happen as a side effect
   * of setting a new max value (when the new max is smaller than the old min).
   */
  minValueChange: EventEmitter<number>;
  /**
   * Event emitted when the max range value changes. This may happen as a side effect
   * of setting a new min value (when the new min is larger than the old max).
   */
  maxValueChange: EventEmitter<number>;
  /**
   * Event emitted when the step value changes. This may happen as a side effect
   * of making the slider discrete.
   */
  stepValueChange: EventEmitter<number>;
  private _initialized;
  private _elmThumbCntr;
  private _elmSliderPin;
  private _elmValueMarker;
  private _elmTrack;
  private _elmTrackMarkerCntr;
  private _reinitTabIndex;
  private _onChange;
  private _onTouched;
  private _discrete;
  private _markers;
  private _disabled;
  private _value;
  private _min;
  private _max;
  private _step;
  private _lastWidth;
  private mdcAdapter;
  private foundation;
  constructor(_rndr: Renderer2, _root: ElementRef, _registry: MdcEventRegistry);
  ngAfterContentInit(): void;
  ngAfterViewInit(): void;
  ngOnDestroy(): void;
  ngOnChanges(changes: SimpleChanges): void;
  _onChanges(changes: SimpleChanges): void;
  private isChanged;
  private initElements;
  private addElement;
  private initDefaultAttributes;
  private updateValues;
  private updateLayout;
  private notifyValueChanged;
  /** @docs-private */
  registerOnChange(onChange: (value: any) => void): void;
  /** @docs-private */
  registerOnTouched(onTouched: () => any): void;
  /**
   * Make the slider discrete. Note from the wrapped <code>mdc-slider</code>
   * component:
   * <blockquote>If a slider contains a step value it does not mean that the slider is a "discrete" slider.
   * "Discrete slider" is a UX treatment, while having a step value is behavioral.</blockquote>
   */
  get discrete(): any;
  set discrete(value: any);
  /**
   * Property to enable/disable the display of track markers. Display markers
   * are only supported for discrete sliders. Thus they are only shown when the values
   * of both markers and discrete equal true.
   */
  get markers(): any;
  set markers(value: any);
  /**
   * The current value of the slider.
   */
  get value(): string | number;
  set value(value: string | number);
  /**
   * The minumum allowed value of the slider.
   */
  get minValue(): string | number;
  set minValue(value: string | number);
  /**
   * The maximum allowed value of the slider.
   */
  get maxValue(): string | number;
  set maxValue(value: string | number);
  /**
   * Set the step value (or set to 0 for no step value).
   * The step value can be a floating point value &gt;= 0.
   * The slider will quantize all values to match the step value, except for the minimum and
   * maximum, which can always be set.
   * Discrete sliders are required to have a step value other than 0.
   * Note from the wrapped <code>mdc-slider</code> component:
   * <blockquote>If a slider contains a step value it does not mean that the slider is a "discrete" slider.
   * "Discrete slider" is a UX treatment, while having a step value is behavioral.</blockquote>
   */
  get stepValue(): string | number;
  set stepValue(value: string | number);
  /**
   * A property to disable the slider.
   */
  get disabled(): any;
  set disabled(value: any);
  asNumber(value: number | string): number;
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcSliderDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcSliderDirective, "[mdcSlider]", never, {
    "discrete": {
      "alias": "discrete";
      "required": false;
    };
    "markers": {
      "alias": "markers";
      "required": false;
    };
    "value": {
      "alias": "value";
      "required": false;
    };
    "minValue": {
      "alias": "minValue";
      "required": false;
    };
    "maxValue": {
      "alias": "maxValue";
      "required": false;
    };
    "stepValue": {
      "alias": "stepValue";
      "required": false;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
    };
  }, {
    "valueChange": "valueChange";
    "minValueChange": "minValueChange";
    "maxValueChange": "maxValueChange";
    "stepValueChange": "stepValueChange";
  }, never, never, false, never>;
}
/**
 * Directive for adding Angular Forms (<code>ControlValueAccessor</code>) behavior to an
 * <code>MdcSliderDirective</code>. Allows the use of the Angular Forms API with
 * icon toggles, e.g. binding to <code>[(ngModel)]</code>, form validation, etc.
 */
export declare class MdcFormsSliderDirective implements ControlValueAccessor {
  private mdcSlider;
  constructor(mdcSlider: MdcSliderDirective);
  /** @docs-private */
  writeValue(obj: any): void;
  /** @docs-private */
  registerOnChange(onChange: (value: any) => void): void;
  /** @docs-private */
  registerOnTouched(onTouched: () => any): void;
  /** @docs-private */
  setDisabledState(disabled: boolean): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcFormsSliderDirective, [{
    self: true;
  }]>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcFormsSliderDirective, "[mdcSlider][formControlName],[mdcSlider][formControl],[mdcSlider][ngModel]", never, {}, {}, never, never, false, never>;
}
/**
 * Directive for the input element of an <code>MdcSwitchDirective</code>.
 */
export declare class MdcSwitchInputDirective extends AbstractMdcInput {
  _elm: ElementRef;
  _cntr: NgControl;
  _cls: boolean;
  private _id;
  private _disabled;
  constructor(_elm: ElementRef, _cntr: NgControl);
  /** @docs-private */
  get id(): string;
  set id(value: string);
  /** @docs-private */
  get disabled(): any;
  set disabled(value: any);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcSwitchInputDirective, [null, {
    optional: true;
    self: true;
  }]>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcSwitchInputDirective, "input[mdcSwitchInput][type=checkbox]", never, {
    "id": {
      "alias": "id";
      "required": false;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
/**
 * Directive for creating a Material Design switch component. The switch is driven by an
 * underlying native checkbox input, which must use the <code>MdcSwitchInputDirective</code>
 * directive.
 * The current implementation will add all other required DOM elements (such as the
 * background).
 * Future implementations will also support supplying (customized) background
 * elements.
 * </p><p>
 * This directive can be used together with an <code>mdcFormField</code> to
 * easily position switches and their labels, see
 * <a href="/material/components/form-field">mdcFormField</a>.
 */
export declare class MdcSwitchDirective implements AfterContentInit {
  private rndr;
  private root;
  _cls: boolean;
  _input: MdcSwitchInputDirective;
  constructor(rndr: Renderer2, root: ElementRef);
  ngAfterContentInit(): void;
  private addBackground;
  get _disabled(): any;
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcSwitchDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcSwitchDirective, "[mdcSwitch]", never, {}, {}, ["_input"], never, false, never>;
}
export declare class MdcTabRouterDirective extends AbstractMdcTabDirective {
  private router;
  private cdr;
  _links: QueryList<RouterLink>;
  _linksWithHrefs: QueryList<RouterLinkWithHref>;
  private routerActive;
  constructor(rndr: Renderer2, root: ElementRef, registry: MdcEventRegistry, router: Router, cdr: ChangeDetectorRef);
  ngOnDestroy(): void;
  ngAfterContentInit(): void;
  /** @docs-private */
  isRouterActive(): boolean;
  /** @docs-private */
  setRouterActive(active: boolean): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcTabRouterDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcTabRouterDirective, "[mdcTabRouter]", ["mdcTabRouter"], {}, {}, ["_links", "_linksWithHrefs"], never, false, never>;
}
/** @docs-private */
interface MdcTextFieldHelperTextAdapter {
  addClass: (className: string) => void;
  removeClass: (className: string) => void;
  hasClass: (className: string) => void;
  setAttr: (name: string, value: string) => void;
  removeAttr: (name: string) => void;
  setContent: (content: string) => void;
}
/** @docs-private */
interface MdcTextFieldIconAdapter {
  getAttr: (attr: string) => string;
  setAttr: (name: string, value: string) => void;
  removeAttr: (name: string) => void;
  setContent: (content: string) => void;
  registerInteractionHandler: (evtType: string, handler: EventListener) => void;
  deregisterInteractionHandler: (evtType: string, handler: EventListener) => void;
  notifyIconAction: () => void;
}
/**
 * Directive for the native input of a text-field (see <code>MdcTextFieldDirective</code>).
 * Add this as the first child to an <code>mdcTextField</code> (or as the second child
 * when you want to have a leading icon on the text-field).
 */
export declare class MdcTextFieldInputDirective extends AbstractMdcInput implements OnInit {
  _elm: ElementRef;
  private renderer;
  _cntr: NgControl;
  _onChange: (value: any) => void;
  private _id;
  private _type;
  private _disabled;
  private _required;
  private cachedId;
  _focused: boolean;
  _hostClass: boolean;
  constructor(_elm: ElementRef, renderer: Renderer2, _cntr: NgControl);
  ngOnInit(): void;
  /**
   * Mirrors the <code>id</code> attribute. If no id is assigned, this directive will
   * assign a unique id by itself. If an <code>mdcFloatingLabel</code> for this text-field
   * is available, the <code>mdcFloatingLabel</code> will automatically set its <code>for</code>
   * attribute to this <code>id</code> value.
   */
  get id(): string;
  set id(value: string);
  /**
   * If set to a value other than false, the text-field will be in disabled state.
   */
  get disabled(): any;
  set disabled(value: any);
  /** @docs-private */
  get type(): string;
  set type(value: string);
  /** @docs-private */
  get value(): string;
  /** @docs-private */
  set value(value: string);
  /** @docs-private */
  focus(): void;
  _onFocus(): void;
  _onBlur(): void;
  _onInput(): void;
  /** @docs-private */
  get valid(): boolean;
  _isBadInput(): boolean;
  _isTextarea(): boolean;
  _newId(): string;
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcTextFieldInputDirective, [null, null, {
    optional: true;
    self: true;
  }]>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcTextFieldInputDirective, "input[mdcTextFieldInput], textarea[mdcTextFieldInput]", never, {
    "id": {
      "alias": "id";
      "required": false;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
    };
    "type": {
      "alias": "type";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
/**
 * Directive for an optional leading or trailing icon on the text-field (see
 * <code>MdcTextFieldDirective</code>). Add this as the first child to an <code>mdcTextField</code>
 * for a leading icon, or as the last child for a trailing icon.
 */
export declare class MdcTextFieldIconDirective {
  private _rndr;
  _el: ElementRef;
  private _reg;
  _cls: boolean;
  _mdcAdapter: MdcTextFieldIconAdapter;
  _foundation: {
    init: Function;
    destroy: Function;
  };
  constructor(_rndr: Renderer2, _el: ElementRef, _reg: MdcEventRegistry);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcTextFieldIconDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcTextFieldIconDirective, "[mdcTextFieldIcon]", never, {}, {}, never, never, false, never>;
}
/**
 * Directive for an optional helper-text to show supplemental information or validation
 * messages for an <code>mdcTextField</code>.
 * Add this just after the <code>mdcTextField</code> as a sibbling element to the
 * <code>mdcTextField</code>. Then export it as a <code>mdcHelperText</code>, and
 * assign the exported object to the <code>helperText</code> property of the
 * <code>mdcHelperText</code>. See the examples for hints on how to do this.
 */
export declare class MdcTextFieldHelperTextDirective {
  private _rndr;
  _elm: ElementRef;
  _cls: boolean;
  _validation: boolean;
  _persistent: boolean;
  _mdcAdapter: MdcTextFieldHelperTextAdapter;
  _foundation: {
    init(): any;
    destroy(): any;
    showToScreenReader(): boolean;
    setValidity(isValid: boolean): any;
  };
  constructor(_rndr: Renderer2, _elm: ElementRef);
  /**
   * If set to a value other than false, the helper text is treated as a
   * validation message, and only shown when the input is invalid.
   */
  set validation(value: any);
  /**
   * If set to a value other than false, the helper text is always visible.
   * Otherwise the helper text will only be shown when the input has focus
   * (or when <code>validation</code> is set, when the input is invalid).
   */
  set persistent(value: any);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcTextFieldHelperTextDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcTextFieldHelperTextDirective, "[mdcTextFieldHelperText]", ["mdcHelperText"], {
    "validation": {
      "alias": "validation";
      "required": false;
    };
    "persistent": {
      "alias": "persistent";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
/**
 * Material design text-field. It is required to add at least an input
 * (<code>mdcTextFieldInput</code>), and a label (<code>mdcFloatingLabel</code>) as child
 * elements.
 */
export declare class MdcTextFieldDirective extends AbstractMdcRipple implements AfterContentInit, OnDestroy {
  private renderer;
  private root;
  private registry;
  _cls: boolean;
  _icon: MdcTextFieldIconDirective;
  _input: MdcTextFieldInputDirective;
  _label: MdcFloatingLabelDirective;
  _labels: QueryList<ElementRef>;
  private _outlineSupport;
  private _helperText;
  private _initialized;
  private _box;
  private _outlined;
  private _dense;
  private _bottomLineElm;
  private _valid;
  private mdcLineRippleAdapter;
  private mdcAdapter;
  private bottomLineFoundation;
  private foundation;
  constructor(renderer: Renderer2, root: ElementRef, registry: MdcEventRegistry);
  ngAfterContentInit(): void;
  ngOnDestroy(): void;
  private initComponent;
  private destroyComponent;
  private reconstructComponent;
  private initLineRipple;
  private destroyLineRipple;
  private initBox;
  private destroyBox;
  private initOutline;
  private destroyOutline;
  private recomputeOutline;
  /**
   * The <code>valid</code> property provides a way to override the validity checking of the
   * underlying angular form control or native input. A value of true or false will make the
   * text-field validity styling based on this value. A value of <code>null</code>, or
   * <code>undefined</code> will reset the validity styling to the state of the underlying
   * angular form control or native input.
   * </p><p>
   * For most use cases messing with this input is not be needed.
   * When the input/textarea is an ngControl, the mdcTextField is already aware of that,
   * and is already using the 'valid' property of that control.
   * However, in some specific cases, binding to <code>valid</code> can help. Example:
   * When you want the mdcTextField to go to 'invalid' state only when the underlying
   * control is invalid AND that control's value is changed, you can bind as follows:
   * <code>valid="myControl.valid || !myControl.dirty"</code>.
   */
  set valid(value: boolean);
  get _textArea(): boolean;
  /**
   * When this input is set to a value other than false, the text-field will be styled
   * as a box, and the box will get a ripple animation on click.
   */
  get box(): any;
  set box(val: any);
  /**
   * When this input is set to a value other than false, the text-field will be styled
   * with a notched outline.
   */
  get outlined(): any;
  set outlined(val: any);
  get _leadingIcon(): boolean;
  get _trailingIcon(): boolean;
  /**
   * When this property is defined and does not have value false, the text-field will be styled more
   * compact.
   */
  get dense(): any;
  set dense(val: any);
  /**
   * Assign an <code>mdcTextFieldHelperText</code> (exported as <code>mdcHelperText</code>) to this
   * input to add a helper-text or validation message to the textfield. See the examples for hints
   * on how to do this.
   */
  get helperText(): MdcTextFieldHelperTextDirective;
  set helperText(helperText: MdcTextFieldHelperTextDirective);
  get _disabled(): any;
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcTextFieldDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcTextFieldDirective, "[mdcTextField]", never, {
    "valid": {
      "alias": "valid";
      "required": false;
    };
    "box": {
      "alias": "box";
      "required": false;
    };
    "outlined": {
      "alias": "outlined";
      "required": false;
    };
    "dense": {
      "alias": "dense";
      "required": false;
    };
    "helperText": {
      "alias": "helperText";
      "required": false;
    };
  }, {}, ["_icon", "_input", "_label", "_labels"], never, false, never>;
}
/**
 * A directive for a toolbar row. The content of a toolbar should always be embedded
 * in toolbar rows. So this directive should always be used as a direct child of an
 * <code>MdcToolbarDirective</code>. Multiple rows are allowed, which rows are visible
 * depends on the style of the toolbar, and the scroll position of the content of
 * the page.
 */
export declare class MdcToolbarRowDirective {
  _elm: ElementRef;
  _hostClass: boolean;
  constructor(_elm: ElementRef);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcToolbarRowDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcToolbarRowDirective, "[mdcToolbarRow]", never, {}, {}, never, never, false, never>;
}
/**
 * A directive for a toolbar section. A toolbar row should always be composed of toolbar sections.
 * Thus, this directive should always be used as a direct child of an <code>MdcToolbarRowDirective</code>.
 * Multiple sections, with different alignment options, are allowed per row.
 */
export declare class MdcToolbarSectionDirective {
  _hostClass: boolean;
  private _alignEnd;
  private _alignStart;
  private _shrinkToFit;
  /**
   * Make the section align to the start of the toolbar row (default alignment is to the
   * center).
   */
  get alignStart(): any;
  set alignStart(val: any);
  /**
   * Make the section align to the end of the toolbar row (default alignment is to the
   * center).
   */
  get alignEnd(): any;
  set alignEnd(val: any);
  /**
   * Toolbar sections are laid out using flexbox. Each section will take up an equal amount
   * of space within the toolbar by default. To accomodate very long sections (e.g. a  long title),
   * set <code>shrinkToFit</code> to a value other than false on the other sections in the row.
   */
  get shrinkToFit(): any;
  set shrinkToFit(val: any);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcToolbarSectionDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcToolbarSectionDirective, "[mdcToolbarSection]", never, {
    "alignStart": {
      "alias": "alignStart";
      "required": false;
    };
    "alignEnd": {
      "alias": "alignEnd";
      "required": false;
    };
    "shrinkToFit": {
      "alias": "shrinkToFit";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
/**
 * This directive adds extra styling to toolbar text that represents the title of the toolbar.
 * The directive should be a child of an <code>MdcToolbarSectionDirective</code>.
 */
export declare class MdcToolbarTitleDirective {
  _elm: ElementRef;
  _hostClass: boolean;
  constructor(_elm: ElementRef);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcToolbarTitleDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcToolbarTitleDirective, "[mdcToolbarTitle]", never, {}, {}, never, never, false, never>;
}
/**
 * This directive is typically used to style icons placed in the toolbar placed
 * on the right hands side. Use <code>MdcToolbarMenuIcon</code> for the 'main'
 * icon, usually placed to the left of the menu.
 * The directive should be a child of an <code>MdcToolbarSectionDirective</code>.
 */
export declare class MdcToolbarIcon {
  _elm: ElementRef;
  _hostClass: boolean;
  constructor(_elm: ElementRef);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcToolbarIcon, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcToolbarIcon, "[mdcToolbarIcon]", never, {}, {}, never, never, false, never>;
}
/**
 * This directive is typically used to style the main toolbar icon, usually placed to
 * the left of the toolbar title. For other icons in the toolbar, use
 * <code>MdcToolbarIcon</code> instead.
 */
export declare class MdcToolbarMenuIcon {
  _elm: ElementRef;
  _hostClass: boolean;
  constructor(_elm: ElementRef);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcToolbarMenuIcon, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcToolbarMenuIcon, "[mdcToolbarMenuIcon]", never, {}, {}, never, never, false, never>;
}
/**
 * For <code>fixed</code> toolbars, this directive should be put on the page's
 * content wrapper element, and the exported directive should be assigned to the
 * <code>fixedAdjust</code> property of the <code>MdcToolbarDirective</code>.
 * This will make the toolbar aware of the content wrapper, so that the top marging
 * can be adjusted based on the style of the toolbar, and the scroll of the content.
 */
export declare class MdcToolbarFixedAdjustDirective {
  _elm: ElementRef;
  _hostClass: boolean;
  constructor(_elm: ElementRef);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcToolbarFixedAdjustDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcToolbarFixedAdjustDirective, "[mdcToolbarFixedAdjust]", ["mdcFixedAdjust"], {}, {}, never, never, false, never>;
}
/**
 * A directive for creating toolbars. All content inside a toolbar should be
 * embedded inside <code>MdcToolbarRowDirective</code> elements.
 */
export declare class MdcToolbarDirective implements AfterViewInit, OnDestroy {
  private renderer;
  private root;
  private registry;
  private zone;
  _hostClass: boolean;
  /**
   * Assign a <code>MdcToolbarFixedAdjustDirective</code> put on the main
   * content of the page. Required for <code>fixed</code> toolbars,
   * to properly layout the toolbar and the content when users scroll.
   */
  fixedAdjust: MdcToolbarFixedAdjustDirective;
  /**
   * A number between [0, 1] that represents the <em>ratio of flexible space
   * that has already been collapsed divided by the total amount of flexible space</em>
   * for flexible toolbars.
   */
  expansionRatio: EventEmitter<number>;
  _title: any;
  _firstRow: any;
  private _viewport;
  private _initialized;
  private _fixed;
  private _waterfall;
  private _fixedLastRowOnly;
  private _flexible;
  private _flexibleDefaultBehavior;
  private mdcAdapter;
  private foundation;
  constructor(renderer: Renderer2, root: ElementRef, registry: MdcEventRegistry, zone: NgZone);
  ngAfterViewInit(): void;
  ngOnDestroy(): void;
  initFixedScroll(): void;
  destroyFixedScroll(): void;
  _updateViewPort: () => void;
  /**
   * If set to a value other than false, the toolbar will be fixed to the top of the
   * screen (or viewport).
   */
  get fixed(): any;
  set fixed(val: any);
  /**
   * If set to a value other than false, and used in combination with <code>fixed</code>
   * the toolbar will become a waterfall toolbar.
   * A waterfall toolbar is initially static and has no elevation, but when content scrolls under it,
   * the toolbar becomes fixed and gains elevation.
   */
  get waterfall(): any;
  set waterfall(val: any);
  /**
   * If set to a value other than false, fixed toolbars will anchor only the last row to the top.
   */
  get fixedLastrowOnly(): any;
  set fixedLastrowOnly(val: any);
  /**
   * A flexible toolbar changes height when the user scrolls. Flexible behavior is highly customizable,
   * quoted from the upstream <code>mdc-toolbar</code> documentation:
   * <blockquote>
   * We only define the change of flexible space size without making further assumptions.
   * But we do recommend the height of flexible space should be an integral number of
   * toolbar row height and provide a easier way for user to customize height.
   * Users can adjust the height of flexible space through sass variable
   * <code>$mdc-toolbar-ratio-to-extend-flexible</code> or css variable
   * <code>--mdc-toolbar-ratio-to-extend-flexible</code>.
   * </blockquote>
   */
  get flexible(): any;
  set flexible(val: any);
  /**
   * A default behavior for flexible toolbars.
   * For more information see:
   * <a href="https://github.com/material-components/material-components-web/tree/v0.23.0/packages/mdc-toolbar#flexible-toolbar-requires-javascript" target="_blank">
   * Flexible Toolbar documention
   * </a>.
   */
  get flexibleDefaultBehavior(): any;
  set flexibleDefaultBehavior(val: any);
  /**
   * Assign any <code>HTMLElement</code> to this property to place a flexible toolbar fixed to that element
   * (usually the parent container), instead of to the browser window. This property is mainly added for creating nice
   * demos of toolbars embedded inside other pages (such as on this documentation page). It is not recommended to use
   * this for a real application toolbar. The position is kept fixed to the container element by listening
   * for scroll/resize events, and using javascript to recompute the position. This may influence the smoothness
   * of the scrolling experience, especially on mobile devices.
   * The viewport element must have css styling: <code>position: relative</code>, and should have a fixed
   * height.
   */
  get viewport(): HTMLElement;
  set viewport(elm: HTMLElement);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcToolbarDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcToolbarDirective, "[mdcToolbar]", never, {
    "fixedAdjust": {
      "alias": "fixedAdjust";
      "required": false;
    };
    "fixed": {
      "alias": "fixed";
      "required": false;
    };
    "waterfall": {
      "alias": "waterfall";
      "required": false;
    };
    "fixedLastrowOnly": {
      "alias": "fixedLastrowOnly";
      "required": false;
    };
    "flexible": {
      "alias": "flexible";
      "required": false;
    };
    "flexibleDefaultBehavior": {
      "alias": "flexibleDefaultBehavior";
      "required": false;
    };
    "viewport": {
      "alias": "viewport";
      "required": false;
    };
  }, {
    "expansionRatio": "expansionRatio";
  }, ["_title", "_firstRow"], never, false, never>;
}
/**
 * A directive for a top-app-bar row. The content of a top-app-bar should always be embedded
 * in <code>mdcTopAppBarRow</code> rows. Multiple rows are allowed, which rows are visible
 * depends on the style of the toolbar, and the scroll position of the content of
 * the page.
 */
export declare class MdcTopAppBarRowDirective {
  _elm: ElementRef;
  _hostClass: boolean;
  constructor(_elm: ElementRef);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcTopAppBarRowDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcTopAppBarRowDirective, "[mdcTopAppBarRow]", never, {}, {}, never, never, false, never>;
}
/**
 * A directive for a top-app-bar section. A top-app-bar row should always be composed of
 * <code>mdcTopAppBarSection</code> sections. Multiple sections, with different alignment options,
 * are allowed per row.
 */
export declare class MdcTopAppBarSectionDirective {
  _hostClass: boolean;
  private _alignEnd;
  private _alignStart;
  /**
   * Make the section align to the start of the toolbar row (default alignment is to the
   * center).
   */
  get alignStart(): any;
  set alignStart(val: any);
  /**
   * Make the section align to the end of the toolbar row (default alignment is to the
   * center).
   */
  get alignEnd(): any;
  set alignEnd(val: any);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcTopAppBarSectionDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcTopAppBarSectionDirective, "[mdcTopAppBarSection]", never, {
    "alignStart": {
      "alias": "alignStart";
      "required": false;
    };
    "alignEnd": {
      "alias": "alignEnd";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
/**
 * This directive adds extra styling to toolbar text that represents the title of the toolbar.
 * The directive should be a child of an element with the <code>mdcTopAppBarSection</code> directive.
 */
export declare class MdcTopAppBarTitleDirective {
  _elm: ElementRef;
  _hostClass: boolean;
  constructor(_elm: ElementRef);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcTopAppBarTitleDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcTopAppBarTitleDirective, "[mdcTopAppBarTitle]", never, {}, {}, never, never, false, never>;
}
/**
 * Directive for the navigation icon of a top-app-bar. Typically placed on the
 * far left (for left-to-right languages). The <code>mdcTopAppBarNavIcon</code>
 * directive should be used on a child of an element with the
 * <code>mdcTopAppBarSection</code> directive. It typically opens a navigation menu
 * or drawer.
 */
export declare class MdcTopAppBarNavIconDirective {
  _elm: ElementRef;
  _hostClass: boolean;
  constructor(_elm: ElementRef);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcTopAppBarNavIconDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcTopAppBarNavIconDirective, "[mdcTopAppBarNavIcon]", never, {}, {}, never, never, false, never>;
}
/**
 * Directive for action items of a top-app-bar. Typically placed on the side
 * opposite the navigation item. The <code>mdcTopAppBarAction</code> directive
 * should be used on a child of an element with the <code>mdcTopAppBarSection</code>
 * directive.
 */
export declare class MdcTopAppBarActionDirective {
  _elm: ElementRef;
  _hostClass: boolean;
  /**
   * A label for the action item. The value will be applied to both the
   * <code>aria-label</code>, and <code>alt</code> attribute of the item.
   */
  label: string;
  constructor(_elm: ElementRef);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcTopAppBarActionDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcTopAppBarActionDirective, "[mdcTopAppBarAction]", never, {
    "label": {
      "alias": "label";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
/**
 * A directive for a top-app-bar. All content inside a top-app-bar should be
 * embedded inside <code>mdcTopAppBarRow</code> rows.
 */
export declare class MdcTopAppBarDirective implements AfterContentInit, OnDestroy {
  private _rndr;
  private _elm;
  private _registry;
  private zone;
  _hostClass: boolean;
  _actionItems: QueryList<MdcTopAppBarActionDirective>;
  private _viewport;
  private _fixedAdjust;
  private _initialized;
  private _type;
  private _prominent;
  private _dense;
  private _collapsedOverride;
  private _collapsedState;
  private mdcAdapter;
  private foundation;
  constructor(_rndr: Renderer2, _elm: ElementRef, _registry: MdcEventRegistry, zone: NgZone);
  ngAfterContentInit(): void;
  ngOnDestroy(): void;
  private foundationReInit;
  private initFixedAdjust;
  private removeScrollListeners;
  /**
   * The top-app-bar can heva different styles. Set this property to <code>fixed</code>
   * for a top-app-bar fixed to the top of the screen or viewport.
   * Set to <code>short</code> for a top-app-bar that will collapse to the navigation
   * icon side when scrolled.
   * Otherwise, the default is a top-app-bar that scrolls with the content.
   */
  get mdcTopAppBar(): string;
  set mdcTopAppBar(val: string);
  /**
   * If set to a value other than false, the top-app-bar will be styled as a taller
   * bar.
   */
  get prominent(): any;
  set prominent(val: any);
  /**
   * If set to a value other than false, the top-app-bar will be styled a bit more
   * compact.
   */
  get dense(): any;
  set dense(val: any);
  /**
   * Set this property to true or false to force the collapsed/uncollapsed state of a short
   * top-app-bar. Set this property to null to return to the default handling, where
   * <code>collapsed</code> is based on the scroll position of the viewport.
   * This property has no effect if the <code>mdcTopAppBar</code> has a value other than
   * <code>short</code>.
   */
  get collapsed(): any;
  set collapsed(val: any);
  /**
   * Top-app-bars are positioned over the rest of their viewport. This means that
   * some of the content will be hidden under the bar, unless the position of that
   * content is changed relative to the bar. Assign the <code>HTMLElement</code>
   * of the content to this property, so that the <code>mdcTopAppBar</code>
   * can add spacing to the content making the top visible when the content is scrolled
   * up.
   */
  get fixedAdjust(): HTMLElement;
  set fixedAdjust(el: HTMLElement);
  /**
   * Assign any <code>HTMLElement</code> to this property to place a top-app-bar fixed to that element
   * (usually the parent container), instead of to the browser window. This property is mainly added for creating nice
   * demos of toolbars embedded inside other pages (such as on this documentation page). It is not recommended to use
   * this for a real application toolbar. The position is kept fixed to the container element by listening
   * for scroll/resize events, and using javascript to recompute the position. This may influence the smoothness
   * of the scrolling experience, especially on mobile devices.
   * The viewport element must have css styling: <code>position: relative</code>, and should have a fixed
   * height.
   */
  get viewport(): HTMLElement;
  set viewport(elm: HTMLElement);
  get _hasActionItems(): boolean;
  _updateViewPort: () => void;
  get _fixed(): boolean;
  get _short(): boolean;
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcTopAppBarDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcTopAppBarDirective, "[mdcTopAppBar]", never, {
    "mdcTopAppBar": {
      "alias": "mdcTopAppBar";
      "required": false;
    };
    "prominent": {
      "alias": "prominent";
      "required": false;
    };
    "dense": {
      "alias": "dense";
      "required": false;
    };
    "collapsed": {
      "alias": "collapsed";
      "required": false;
    };
    "fixedAdjust": {
      "alias": "fixedAdjust";
      "required": false;
    };
    "viewport": {
      "alias": "viewport";
      "required": false;
    };
  }, {}, ["_actionItems"], never, false, never>;
}
export declare const TOP_APP_BAR_DIRECTIVES: (typeof MdcTopAppBarRowDirective | typeof MdcTopAppBarSectionDirective | typeof MdcTopAppBarDirective)[];
/**
 * Utility directive to trigger window 'resize' events not only when the browser window
 * is resized, but also when the browser window gets a vertical scrollbar.
 * This solves problems with directives that base their layout or position on the
 * width of the document body. When a scrollbar is added, the body width changes, but the browser
 * doesn't fire a 'resize' (or other) event. As long as at least one <code>mdcScrollbarResize</code>
 * directive is active on the page, 'resize' events will also be fired when the body width changes
 * as a consequence of the addition or removal of a vertical toolbar.
 * The directive adds a hidden iframe to the page, that contains the trickery to make this happen.
 * See this <a href="https://gist.github.com/OrganicPanda/8222636" target="_blank">hacky-scrollbar-resize-listener.js
 * github gist</a> for the original idea.
 */
export declare class MdcScrollbarResizeDirective implements OnDestroy {
  private _scrollbarResize;
  constructor();
  ngOnDestroy(): void;
  /**
   * Set to false to disable triggering resize events because of addition/deletion of a scrollbar.
   * The <code>mdcScrollbarResize</code> behavior is removed after <strong>all</strong>&ngsp;
   * <code>mdcScrollbarResize</code> directives on the page are removed or have the value false.
   */
  get mdcScrollbarResize(): any;
  set mdcScrollbarResize(val: any);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcScrollbarResizeDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<MdcScrollbarResizeDirective, "[mdcScrollbarResize]", never, {
    "mdcScrollbarResize": {
      "alias": "mdcScrollbarResize";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
/**
 * The interface accepted by <code>MdcSnackbarService::show()</code>.
 */
export interface MdcSnackbarMessage {
  /**
   * The text message to display
   */
  message: string;
  /**
   * The text to display for the action button (optional, default is no action button).
   */
  actionText?: string;
  /**
   * Whether to show the snackbar with space for multiple lines of text (optional, default is false).
   */
  multiline?: boolean;
  /**
   * Whether to show the action below the multiple lines of text (optional, only applies when multiline is true).
   */
  actionOnBottom?: boolean;
  /**
   * The amount of time in milliseconds to show the snackbar (optional, default is 2750ms).
   */
  timeout?: number;
}
/**
 * This class provides information about a posted snackbar message.
 * It can also be used to subscribe to action clicks.
 */
declare class MdcSnackbarRef {
  private _action;
  private _show;
  private _hide;
  constructor(_action: Subject<void>, _show: Subject<void>, _hide: Subject<void>);
  /**
   * Subscribe to this observable to be informed when a user clicks the action
   * for the shown snackbar. Note that the observable will complete when the snackbar
   * disappears from screen, so there is no need to unsubscribe.
   */
  action(): Observable<void>;
  /**
   * Subscribe to this observable to be informed when the message is displayed.
   * Note that the observable will complete when the snackbar disappears from screen,
   * so there is no need to unsubscribe.
   */
  afterShow(): Observable<void>;
  /**
   * Subscribe to this observable to be informed when the message disappears.
   * Note that the observable will complete immediately afterwards, so there is
   * no need to unsubscribe.
   */
  afterHide(): Observable<void>;
}
/**
 * A service for showing spec-aligned material design snackbar/toast messages.
 */
export declare class MdcSnackbarService {
  private snackbar;
  private root;
  private isActive;
  private postedMessages;
  private lastActivated;
  private lastDismissed;
  private openMessage;
  private closeMessage;
  constructor();
  private initHtml;
  private getFoundation;
  private activateNext;
  private deactivateLast;
  /**
   * Show a snackbar/toast message. If a snackbar message is already showing, the new
   * message will be queued to show after earlier message have been shown.
   * The returned <code>MdcSnackbarRef</code> provides methods to subscribe to action clicks.
   *
   * @param message Queue a snackbar message to show.
   */
  show(message: MdcSnackbarMessage): MdcSnackbarRef;
  /**
   * Set this property to true to show snackbars start-aligned instead of center-aligned. Desktop and tablet only.
   */
  get startAligned(): boolean;
  set startAligned(value: boolean);
  /**
   * By default the snackbar will be dimissed when the user presses the action button.
   * If you want the snackbar to remain visible until the timeout is reached (regardless of
   * whether the user pressed the action button or not) you can set the dismissesOnAction
   * property to false.
   */
  get dismissesOnAction(): boolean;
  set dismissesOnAction(value: boolean);
  static ɵfac: i0.ɵɵFactoryDeclaration<MdcSnackbarService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export declare class MaterialModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<MaterialModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<MaterialModule, [typeof MdcButtonDirective, typeof MdcButtonIconDirective, typeof MdcCardDirective, typeof MdcCardMediaDirective, typeof MdcCardMediaContentDirective, typeof MdcCardActionButtonsDirective, typeof MdcCardActionIconsDirective, typeof MdcCardActionsDirective, typeof MdcCardPrimaryActionDirective, typeof MdcCheckboxDirective, typeof MdcCheckboxInputDirective, typeof MdcChipIconDirective, typeof MdcChipTextDirective, typeof MdcChipDirective, typeof MdcChipSetDirective, typeof MdcDialogDirective, typeof MdcDialogHeaderTitleDirective, typeof MdcDialogHeaderDirective, typeof MdcDialogBodyDirective, typeof MdcDialogFooterDirective, typeof MdcDialogAcceptDirective, typeof MdcDialogCancelDirective, typeof MdcDialogBackdropDirective, typeof MdcDialogSurfaceDirective, typeof MdcDrawerDirective, typeof MdcDrawerContainerDirective, typeof MdcDrawerToolbarSpacerDirective, typeof MdcDrawerHeaderDirective, typeof MdcDrawerHeaderContentDirective, typeof MdcDrawerContentDirective, typeof MdcElevationDirective, typeof MdcFabDirective, typeof MdcFabIconDirective, typeof MdcFloatingLabelDirective, typeof MdcFocusInitialDirective, typeof MdcFocusTrapDirective, typeof MdcFormFieldDirective, typeof MdcFormFieldInputDirective, typeof MdcFormFieldLabelDirective, typeof MdcIconButtonIconDirective, typeof MdcIconButtonDirective, typeof MdcIconButtonToggleDirective, typeof MdcFormsIconButtonDirective, typeof MdcIconToggleDirective, typeof MdcIconToggleIconDirective, typeof MdcFormsIconToggleDirective, typeof MdcLinearProgressDirective, typeof MdcListDividerDirective, typeof MdcListItemDirective, typeof MdcListItemTextDirective, typeof MdcListItemSecondaryTextDirective, typeof MdcListItemGraphicDirective, typeof MdcListItemMetaDirective, typeof MdcListDirective, typeof MdcListGroupSubHeaderDirective, typeof MdcListGroupDirective, typeof MdcMenuAnchorDirective, typeof MdcMenuDirective, typeof MdcRadioDirective, typeof MdcRadioInputDirective, typeof MdcRippleDirective, typeof MdcSelectDirective, typeof MdcSelectControlDirective, typeof MdcSliderDirective, typeof MdcFormsSliderDirective, typeof MdcSwitchInputDirective, typeof MdcSwitchDirective, typeof MdcTabDirective, typeof MdcTabIconDirective, typeof MdcTabIconTextDirective, typeof MdcTabRouterDirective, typeof MdcTabBarDirective, typeof MdcTabBarScrollerDirective, typeof MdcTabBarScrollerInnerDirective, typeof MdcTabBarScrollerBackDirective, typeof MdcTabBarScrollerForwardDirective, typeof MdcTabBarScrollerFrameDirective, typeof MdcTextFieldDirective, typeof MdcTextFieldInputDirective, typeof MdcTextFieldIconDirective, typeof MdcTextFieldHelperTextDirective, typeof MdcToolbarDirective, typeof MdcToolbarRowDirective, typeof MdcToolbarSectionDirective, typeof MdcToolbarTitleDirective, typeof MdcToolbarIcon, typeof MdcToolbarMenuIcon, typeof MdcToolbarFixedAdjustDirective, typeof MdcTopAppBarRowDirective, typeof MdcTopAppBarSectionDirective, typeof MdcTopAppBarTitleDirective, typeof MdcTopAppBarNavIconDirective, typeof MdcTopAppBarActionDirective, typeof MdcTopAppBarDirective, typeof MdcScrollbarResizeDirective], [typeof i30.CommonModule], [typeof MdcButtonDirective, typeof MdcButtonIconDirective, typeof MdcCardDirective, typeof MdcCardMediaDirective, typeof MdcCardMediaContentDirective, typeof MdcCardActionButtonsDirective, typeof MdcCardActionIconsDirective, typeof MdcCardActionsDirective, typeof MdcCardPrimaryActionDirective, typeof MdcCheckboxDirective, typeof MdcCheckboxInputDirective, typeof MdcChipIconDirective, typeof MdcChipTextDirective, typeof MdcChipDirective, typeof MdcChipSetDirective, typeof MdcDialogDirective, typeof MdcDialogHeaderTitleDirective, typeof MdcDialogHeaderDirective, typeof MdcDialogBodyDirective, typeof MdcDialogFooterDirective, typeof MdcDialogAcceptDirective, typeof MdcDialogCancelDirective, typeof MdcDialogBackdropDirective, typeof MdcDialogSurfaceDirective, typeof MdcDrawerDirective, typeof MdcDrawerContainerDirective, typeof MdcDrawerToolbarSpacerDirective, typeof MdcDrawerHeaderDirective, typeof MdcDrawerHeaderContentDirective, typeof MdcDrawerContentDirective, typeof MdcElevationDirective, typeof MdcFabDirective, typeof MdcFabIconDirective, typeof MdcFloatingLabelDirective, typeof MdcFocusInitialDirective, typeof MdcFocusTrapDirective, typeof MdcFormFieldDirective, typeof MdcFormFieldInputDirective, typeof MdcFormFieldLabelDirective, typeof MdcIconButtonIconDirective, typeof MdcIconButtonDirective, typeof MdcIconButtonToggleDirective, typeof MdcFormsIconButtonDirective, typeof MdcIconToggleDirective, typeof MdcIconToggleIconDirective, typeof MdcFormsIconToggleDirective, typeof MdcLinearProgressDirective, typeof MdcListDividerDirective, typeof MdcListItemDirective, typeof MdcListItemTextDirective, typeof MdcListItemSecondaryTextDirective, typeof MdcListItemGraphicDirective, typeof MdcListItemMetaDirective, typeof MdcListDirective, typeof MdcListGroupSubHeaderDirective, typeof MdcListGroupDirective, typeof MdcMenuAnchorDirective, typeof MdcMenuDirective, typeof MdcRadioDirective, typeof MdcRadioInputDirective, typeof MdcRippleDirective, typeof MdcSelectDirective, typeof MdcSelectControlDirective, typeof MdcSliderDirective, typeof MdcFormsSliderDirective, typeof MdcSwitchInputDirective, typeof MdcSwitchDirective, typeof MdcTabDirective, typeof MdcTabIconDirective, typeof MdcTabIconTextDirective, typeof MdcTabRouterDirective, typeof MdcTabBarDirective, typeof MdcTabBarScrollerDirective, typeof MdcTabBarScrollerInnerDirective, typeof MdcTabBarScrollerBackDirective, typeof MdcTabBarScrollerForwardDirective, typeof MdcTabBarScrollerFrameDirective, typeof MdcTextFieldDirective, typeof MdcTextFieldInputDirective, typeof MdcTextFieldIconDirective, typeof MdcTextFieldHelperTextDirective, typeof MdcToolbarDirective, typeof MdcToolbarRowDirective, typeof MdcToolbarSectionDirective, typeof MdcToolbarTitleDirective, typeof MdcToolbarIcon, typeof MdcToolbarMenuIcon, typeof MdcToolbarFixedAdjustDirective, typeof MdcTopAppBarRowDirective, typeof MdcTopAppBarSectionDirective, typeof MdcTopAppBarTitleDirective, typeof MdcTopAppBarNavIconDirective, typeof MdcTopAppBarActionDirective, typeof MdcTopAppBarDirective, typeof MdcScrollbarResizeDirective]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<MaterialModule>;
}
export {};
//# sourceMappingURL=blox-material.d.ts.map