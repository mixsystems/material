import * as i0 from "@angular/core";
import { ContentChild, ContentChildren, Directive, ElementRef, EventEmitter, HostBinding, HostListener, Injectable, Input, NgModule, Optional, Output, Self, SimpleChange, forwardRef } from "@angular/core";
import { CommonModule } from "@angular/common";
import { MDCRippleFoundation, util } from "@material/ripple";
import { MDCCheckboxFoundation } from "@material/checkbox";
import * as i1 from "@angular/forms";
import { NG_VALUE_ACCESSOR } from "@angular/forms";
import { MDCChipFoundation, MDCChipSetFoundation } from "@material/chips";
import { MDCDialogFoundation } from "@material/dialog";
import { FOCUSABLE_ELEMENTS } from "@material/drawer/slidable";
import { MDCPersistentDrawerFoundation, MDCTemporaryDrawerFoundation, util as util$1 } from "@material/drawer";
import { MDCFloatingLabelFoundation } from "@material/floating-label";
import createFocusTrap from "focus-trap";
import { MDCFormFieldFoundation } from "@material/form-field";
import { MDCIconButtonToggleFoundation } from "@material/icon-button";
import { MDCIconToggleFoundation } from "@material/icon-toggle";
import { MDCLinearProgressFoundation } from "@material/linear-progress";
import { MDCMenu, MDCMenuFoundation } from "@material/menu";
import { getTransformPropertyName } from "@material/menu/util";
import { MDCRadioFoundation } from "@material/radio";
import { MDCSelectFoundation } from "@material/select";
import { MDCLineRippleFoundation } from "@material/line-ripple";
import { MDCNotchedOutlineFoundation } from "@material/notched-outline";
import { MDCSliderFoundation } from "@material/slider";
import { MDCTabBarFoundation, MDCTabBarScrollerFoundation, MDCTabFoundation } from "@material/tabs";
import * as i2 from "@angular/router";
import { NavigationEnd, RouterLink, RouterLinkWithHref } from "@angular/router";
import { Subject } from "rxjs";
import { filter, take, takeUntil } from "rxjs/operators";
import { getCorrectEventName, getCorrectPropertyName } from "@material/animation";
import { MDCTextFieldFoundation } from "@material/textfield";
import { MDCTextFieldHelperTextFoundation } from "@material/textfield/helper-text";
import { MDCTextFieldIconFoundation } from "@material/textfield/icon";
import { MDCToolbarFoundation } from "@material/toolbar";
import { MDCFixedTopAppBarFoundation, MDCShortTopAppBarFoundation, MDCTopAppBarFoundation } from "@material/top-app-bar";
import { MDCSnackbar, MDCSnackbarFoundation } from "@material/snackbar";
function asBoolean(value) {
	return value != null && `${value}` !== "false";
}
function asBooleanOrNull(value) {
	if (value == null) return value;
	return `${value}` !== "false";
}
const matchesProperty = util.getMatchesProperty(HTMLElement.prototype);
var AbstractMdcRipple = class {
	constructor(_rippleElm, _renderer, _registry) {
		this._rippleElm = _rippleElm;
		this._renderer = _renderer;
		this._registry = _registry;
		this.mdcRippleAdapter = {
			browserSupportsCssVars: () => util.supportsCssVariables(window),
			isUnbounded: () => this.isRippleUnbounded(),
			isSurfaceActive: () => this.isRippleSurfaceActive(),
			isSurfaceDisabled: () => this.isRippleSurfaceDisabled(),
			addClass: (className) => this.addClassToRipple(className),
			removeClass: (className) => this.removeClassFromRipple(className),
			containsEventTarget: (target) => this._rippleElm.nativeElement.contains(target),
			registerInteractionHandler: (type, handler) => {
				this._registry.listenElm(this._renderer, type, handler, this.getRippleInteractionElement().nativeElement, util.applyPassive());
			},
			deregisterInteractionHandler: (type, handler) => {
				this._registry.unlisten(type, handler);
			},
			registerDocumentInteractionHandler: (type, handler) => this._registry.listenElm(this._renderer, type, handler, document),
			deregisterDocumentInteractionHandler: (type, handler) => this._registry.unlisten(type, handler),
			registerResizeHandler: (handler) => {
				this._registry.listenElm(this._renderer, "resize", handler, window);
			},
			deregisterResizeHandler: (handler) => {
				this._registry.unlisten("resize", handler);
			},
			updateCssVariable: (name, value) => {
				this._rippleElm.nativeElement.style.setProperty(name, value);
			},
			computeBoundingRect: () => this.computeRippleBoundingRect(),
			getWindowPageOffset: () => ({
				x: window.pageXOffset,
				y: window.pageYOffset
			})
		};
	}
	initRipple() {
		if (this._rippleFoundation) throw new Error("initRipple() is called multiple times");
		this._rippleFoundation = new MDCRippleFoundation(this.mdcRippleAdapter);
		this._rippleFoundation.init();
	}
	destroyRipple() {
		if (this._rippleFoundation) {
			this._rippleFoundation.destroy();
			this._rippleFoundation = null;
		}
	}
	isRippleInitialized() {
		return this._rippleFoundation != null;
	}
	activateRipple() {
		if (this._rippleFoundation) this._rippleFoundation.activate();
	}
	deactivateRipple() {
		if (this._rippleFoundation) this._rippleFoundation.deactivate();
	}
	getRippleInteractionElement() {
		return this._rippleElm;
	}
	isRippleUnbounded() {
		return false;
	}
	isRippleSurfaceActive() {
		let interactionElm = this.getRippleInteractionElement();
		if (interactionElm == null) return false;
		return this.isActiveElement(interactionElm.nativeElement);
	}
	isActiveElement(element) {
		return element == null ? false : element[matchesProperty](":active");
	}
	isRippleSurfaceDisabled() {
		let interactionElm = this.getRippleInteractionElement();
		if (interactionElm == null) return true;
		return !!interactionElm.nativeElement.attributes.getNamedItem("disabled");
	}
	addClassToRipple(name) {
		this._renderer.addClass(this._rippleElm.nativeElement, name);
	}
	removeClassFromRipple(name) {
		this._renderer.removeClass(this._rippleElm.nativeElement, name);
	}
	computeRippleBoundingRect() {
		return this._rippleElm.nativeElement.getBoundingClientRect();
	}
};
const unlisteners = /* @__PURE__ */ new Map();
var MdcEventRegistry = class MdcEventRegistry {
	constructor() {}
	listen(renderer, type, listener, ref, options) {
		this.listenElm(renderer, type, listener, ref.nativeElement, options);
	}
	listenElm(renderer, type, listener, el, options) {
		el.addEventListener(type, listener, options);
		const unlistener = function() {
			el.removeEventListener(type, listener, options);
		};
		this.registerUnlisten(type, listener, unlistener);
	}
	registerUnlisten(type, listener, unlistener) {
		if (!unlisteners.has(type)) unlisteners.set(type, /* @__PURE__ */ new WeakMap());
		unlisteners.get(type).set(listener, unlistener);
	}
	unlisten(type, listener) {
		if (!unlisteners.has(type)) return;
		const unlistenerMap = unlisteners.get(type);
		if (!unlistenerMap.has(listener)) return;
		unlistenerMap.get(listener)();
		unlistenerMap.delete(listener);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcEventRegistry,
			deps: [],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcEventRegistry,
			providedIn: "root"
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcEventRegistry,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}],
	ctorParameters: () => []
});
var MdcButtonIconDirective = class MdcButtonIconDirective {
	constructor() {
		this._cls = true;
		this._ariaHidden = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcButtonIconDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcButtonIconDirective,
			isStandalone: false,
			selector: "mdcButtonIcon",
			host: { properties: {
				"class.mdc-button__icon": "this._cls",
				"attr.aria-hidden": "this._ariaHidden"
			} },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcButtonIconDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "mdcButtonIcon"
		}]
	}],
	propDecorators: {
		_cls: [{
			type: HostBinding,
			args: ["class.mdc-button__icon"]
		}],
		_ariaHidden: [{
			type: HostBinding,
			args: ["attr.aria-hidden"]
		}]
	}
});
var MdcButtonDirective = class MdcButtonDirective extends AbstractMdcRipple {
	constructor(_elm, renderer, registry) {
		super(_elm, renderer, registry);
		this._elm = _elm;
		this._cls = true;
		this._dense = false;
		this._raised = false;
		this._unelevated = false;
		this._outlined = false;
	}
	ngAfterContentInit() {
		this.initRipple();
	}
	ngOnDestroy() {
		this.destroyRipple();
	}
	get raised() {
		return this._raised;
	}
	set raised(val) {
		this._raised = asBoolean(val);
	}
	get outlined() {
		return this._outlined;
	}
	set outlined(val) {
		this._outlined = asBoolean(val);
	}
	get unelevated() {
		return this._unelevated;
	}
	set unelevated(val) {
		this._unelevated = asBoolean(val);
	}
	get dense() {
		return this._dense;
	}
	set dense(val) {
		this._dense = asBoolean(val);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcButtonDirective,
			deps: [
				{ token: i0.ElementRef },
				{ token: i0.Renderer2 },
				{ token: MdcEventRegistry }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcButtonDirective,
			isStandalone: false,
			selector: "button[mdcButton],a[mdcButton]",
			inputs: {
				raised: "raised",
				outlined: "outlined",
				unelevated: "unelevated",
				dense: "dense"
			},
			host: { properties: {
				"class.mdc-button": "this._cls",
				"class.mdc-button--raised": "this.raised",
				"class.mdc-button--outlined": "this.outlined",
				"class.mdc-button--unelevated": "this.unelevated",
				"class.mdc-button--dense": "this.dense"
			} },
			providers: [{
				provide: AbstractMdcRipple,
				useExisting: forwardRef(() => MdcButtonDirective)
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcButtonDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "button[mdcButton],a[mdcButton]",
			providers: [{
				provide: AbstractMdcRipple,
				useExisting: forwardRef(() => MdcButtonDirective)
			}]
		}]
	}],
	ctorParameters: () => [
		{ type: i0.ElementRef },
		{ type: i0.Renderer2 },
		{ type: MdcEventRegistry }
	],
	propDecorators: {
		_cls: [{
			type: HostBinding,
			args: ["class.mdc-button"]
		}],
		raised: [{
			type: HostBinding,
			args: ["class.mdc-button--raised"]
		}, { type: Input }],
		outlined: [{
			type: HostBinding,
			args: ["class.mdc-button--outlined"]
		}, { type: Input }],
		unelevated: [{
			type: HostBinding,
			args: ["class.mdc-button--unelevated"]
		}, { type: Input }],
		dense: [{
			type: HostBinding,
			args: ["class.mdc-button--dense"]
		}, { type: Input }]
	}
});
var AbstractMdcIcon = class extends AbstractMdcRipple {
	constructor(_elm, renderer, registry) {
		super(_elm, renderer, registry);
		this._elm = _elm;
	}
};
var MdcCardMediaDirective = class MdcCardMediaDirective {
	constructor() {
		this._cls = true;
		this._size = "cover";
	}
	get _square() {
		return this._size === "square";
	}
	get _size2() {
		return this._size === "16:9";
	}
	get size() {
		return this._size;
	}
	set size(val) {
		this._size = val;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcCardMediaDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcCardMediaDirective,
			isStandalone: false,
			selector: "[mdcCardMedia]",
			inputs: { size: "size" },
			host: { properties: {
				"class.mdc-card__media": "this._cls",
				"class.mdc-card__media--square": "this._square",
				"class.mdc-card__media--16-9": "this._size2"
			} },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcCardMediaDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcCardMedia]"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		_cls: [{
			type: HostBinding,
			args: ["class.mdc-card__media"]
		}],
		_square: [{
			type: HostBinding,
			args: ["class.mdc-card__media--square"]
		}],
		_size2: [{
			type: HostBinding,
			args: ["class.mdc-card__media--16-9"]
		}],
		size: [{ type: Input }]
	}
});
var MdcCardMediaContentDirective = class MdcCardMediaContentDirective {
	constructor() {
		this._cls = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcCardMediaContentDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcCardMediaContentDirective,
			isStandalone: false,
			selector: "[mdcCardMediaContent]",
			host: { properties: { "class.mdc-card__media-content": "this._cls" } },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcCardMediaContentDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcCardMediaContent]"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { _cls: [{
		type: HostBinding,
		args: ["class.mdc-card__media-content"]
	}] }
});
var MdcCardActionButtonsDirective = class MdcCardActionButtonsDirective {
	constructor() {
		this._cls = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcCardActionButtonsDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcCardActionButtonsDirective,
			isStandalone: false,
			selector: "[mdcCardActionButtons]",
			host: { properties: { "class.mdc-card__action-buttons": "this._cls" } },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcCardActionButtonsDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcCardActionButtons]"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { _cls: [{
		type: HostBinding,
		args: ["class.mdc-card__action-buttons"]
	}] }
});
var MdcCardActionIconsDirective = class MdcCardActionIconsDirective {
	constructor() {
		this._cls = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcCardActionIconsDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcCardActionIconsDirective,
			isStandalone: false,
			selector: "[mdcCardActionIcons]",
			host: { properties: { "class.mdc-card__action-icons": "this._cls" } },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcCardActionIconsDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcCardActionIcons]"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { _cls: [{
		type: HostBinding,
		args: ["class.mdc-card__action-icons"]
	}] }
});
var MdcCardActionsDirective = class MdcCardActionsDirective {
	constructor(renderer) {
		this.renderer = renderer;
		this._cls = true;
		this._initialized = false;
		this._fullBleed = false;
	}
	ngAfterContentInit() {
		this._initialized = true;
		this._initButtons();
		this._initIcons();
		this._buttons.changes.subscribe(() => {
			this._initButtons();
		});
		this._icons.changes.subscribe(() => {
			this._initIcons();
		});
	}
	_initButtons() {
		if (this._initialized) this._buttons.forEach((btn) => {
			this.renderer.addClass(btn._elm.nativeElement, "mdc-card__action");
			this.renderer.addClass(btn._elm.nativeElement, "mdc-card__action--button");
		});
	}
	_initIcons() {
		if (this._initialized) this._icons.forEach((icon) => {
			this.renderer.addClass(icon._elm.nativeElement, "mdc-card__action");
			this.renderer.addClass(icon._elm.nativeElement, "mdc-card__action--icon");
		});
	}
	get fullBleed() {
		return this._fullBleed;
	}
	set fullBleed(val) {
		this._fullBleed = asBoolean(val);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcCardActionsDirective,
			deps: [{ token: i0.Renderer2 }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcCardActionsDirective,
			isStandalone: false,
			selector: "[mdcCardActions]",
			inputs: { fullBleed: "fullBleed" },
			host: { properties: {
				"class.mdc-card__actions": "this._cls",
				"class.mdc-card__actions--full-bleed": "this.fullBleed"
			} },
			queries: [{
				propertyName: "_buttons",
				predicate: MdcButtonDirective,
				descendants: true
			}, {
				propertyName: "_icons",
				predicate: AbstractMdcIcon,
				descendants: true
			}],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcCardActionsDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcCardActions]"
		}]
	}],
	ctorParameters: () => [{ type: i0.Renderer2 }],
	propDecorators: {
		_cls: [{
			type: HostBinding,
			args: ["class.mdc-card__actions"]
		}],
		_buttons: [{
			type: ContentChildren,
			args: [MdcButtonDirective, { descendants: true }]
		}],
		_icons: [{
			type: ContentChildren,
			args: [AbstractMdcIcon, { descendants: true }]
		}],
		fullBleed: [{
			type: HostBinding,
			args: ["class.mdc-card__actions--full-bleed"]
		}, { type: Input }]
	}
});
var MdcCardPrimaryActionDirective = class MdcCardPrimaryActionDirective extends AbstractMdcRipple {
	constructor(elm, renderer, registry) {
		super(elm, renderer, registry);
		this._cls = true;
	}
	ngAfterContentInit() {
		this.initRipple();
	}
	ngOnDestroy() {
		this.destroyRipple();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcCardPrimaryActionDirective,
			deps: [
				{ token: i0.ElementRef },
				{ token: i0.Renderer2 },
				{ token: MdcEventRegistry }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcCardPrimaryActionDirective,
			isStandalone: false,
			selector: "[mdcCardPrimaryAction]",
			host: { properties: { "class.mdc-card__primary-action": "this._cls" } },
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcCardPrimaryActionDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcCardPrimaryAction]"
		}]
	}],
	ctorParameters: () => [
		{ type: i0.ElementRef },
		{ type: i0.Renderer2 },
		{ type: MdcEventRegistry }
	],
	propDecorators: { _cls: [{
		type: HostBinding,
		args: ["class.mdc-card__primary-action"]
	}] }
});
var MdcCardDirective = class MdcCardDirective {
	constructor() {
		this._cls = true;
		this._outlined = false;
	}
	get outlined() {
		return this._outlined;
	}
	set outlined(val) {
		this._outlined = asBoolean(val);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcCardDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcCardDirective,
			isStandalone: false,
			selector: "[mdcCard]",
			inputs: { outlined: "outlined" },
			host: { properties: {
				"class.mdc-card": "this._cls",
				"class.mdc-card--outlined": "this.outlined"
			} },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcCardDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcCard]"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		_cls: [{
			type: HostBinding,
			args: ["class.mdc-card"]
		}],
		outlined: [{
			type: HostBinding,
			args: ["class.mdc-card--outlined"]
		}, { type: Input }]
	}
});
var AbstractMdcInput = class {};
var MdcCheckboxInputDirective = class MdcCheckboxInputDirective extends AbstractMdcInput {
	constructor(_elm, _cntr) {
		super();
		this._elm = _elm;
		this._cntr = _cntr;
		this._cls = true;
		this._disabled = false;
	}
	get id() {
		return this._id;
	}
	set id(value) {
		this._id = value;
	}
	get disabled() {
		return this._cntr ? this._cntr.disabled : this._disabled;
	}
	set disabled(value) {
		this._disabled = asBoolean(value);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcCheckboxInputDirective,
			deps: [{ token: i0.ElementRef }, {
				token: i1.NgControl,
				optional: true,
				self: true
			}],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcCheckboxInputDirective,
			isStandalone: false,
			selector: "input[mdcCheckboxInput][type=checkbox]",
			inputs: {
				id: "id",
				disabled: "disabled"
			},
			host: { properties: {
				"class.mdc-checkbox__native-control": "this._cls",
				"id": "this.id",
				"disabled": "this.disabled"
			} },
			providers: [{
				provide: AbstractMdcInput,
				useExisting: forwardRef(() => MdcCheckboxInputDirective)
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcCheckboxInputDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "input[mdcCheckboxInput][type=checkbox]",
			providers: [{
				provide: AbstractMdcInput,
				useExisting: forwardRef(() => MdcCheckboxInputDirective)
			}]
		}]
	}],
	ctorParameters: () => [{ type: i0.ElementRef }, {
		type: i1.NgControl,
		decorators: [{ type: Optional }, { type: Self }]
	}],
	propDecorators: {
		_cls: [{
			type: HostBinding,
			args: ["class.mdc-checkbox__native-control"]
		}],
		id: [{ type: HostBinding }, { type: Input }],
		disabled: [{ type: HostBinding }, { type: Input }]
	}
});
var MdcCheckboxDirective = class MdcCheckboxDirective extends AbstractMdcRipple {
	constructor(renderer, root, registry) {
		super(root, renderer, registry);
		this.renderer = renderer;
		this.root = root;
		this.registry = registry;
		this._cls = true;
		this.mdcAdapter = {
			addClass: (className) => {
				this.renderer.addClass(this.root.nativeElement, className);
			},
			removeClass: (className) => {
				this.renderer.removeClass(this.root.nativeElement, className);
			},
			setNativeControlAttr: (attr, value) => this._renderer.setAttribute(this._input._elm.nativeElement, attr, value),
			removeNativeControlAttr: (attr) => this._renderer.removeAttribute(this._input._elm.nativeElement, attr),
			registerAnimationEndHandler: (handler) => {
				this.registry.listen(this.renderer, "animationend", handler, this.root);
			},
			deregisterAnimationEndHandler: (handler) => {
				this.registry.unlisten("animationend", handler);
			},
			registerChangeHandler: (handler) => {
				if (this._input) this.registry.listen(this.renderer, "change", handler, this._input._elm);
			},
			deregisterChangeHandler: (handler) => {
				if (this._input) this.registry.unlisten("change", handler);
			},
			getNativeControl: () => this._input ? this._input._elm.nativeElement : null,
			forceLayout: () => this.root.nativeElement.offsetWidth,
			isAttachedToDOM: () => !!this._input
		};
		this.foundation = new MDCCheckboxFoundation(this.mdcAdapter);
	}
	ngAfterContentInit() {
		this.addBackground();
		this.initRipple();
		this.foundation.init();
	}
	ngOnDestroy() {
		this.foundation.destroy();
		this.destroyRipple();
	}
	addBackground() {
		let path = this.renderer.createElement("path", "svg");
		this.renderer.addClass(path, "mdc-checkbox__checkmark-path");
		this.renderer.setAttribute(path, "fill", "none");
		this.renderer.setAttribute(path, "d", "M1.73,12.91 8.1,19.28 22.79,4.59");
		let svg = this.renderer.createElement("svg", "svg");
		this.renderer.appendChild(svg, path);
		this.renderer.addClass(svg, "mdc-checkbox__checkmark");
		this.renderer.setAttribute(svg, "viewBox", "0 0 24 24");
		let mixedmark = this.renderer.createElement("div");
		this.renderer.addClass(mixedmark, "mdc-checkbox__mixedmark");
		let bg = this.renderer.createElement("div");
		this.renderer.appendChild(bg, svg);
		this.renderer.appendChild(bg, mixedmark);
		this.renderer.addClass(bg, "mdc-checkbox__background");
		this.renderer.appendChild(this.root.nativeElement, bg);
	}
	getRippleInteractionElement() {
		return this._input ? this._input._elm : null;
	}
	isRippleUnbounded() {
		return true;
	}
	get _disabled() {
		return this._input == null || this._input.disabled;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcCheckboxDirective,
			deps: [
				{ token: i0.Renderer2 },
				{ token: i0.ElementRef },
				{ token: MdcEventRegistry }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcCheckboxDirective,
			isStandalone: false,
			selector: "[mdcCheckbox]",
			host: { properties: {
				"class.mdc-checkbox": "this._cls",
				"class.mdc-checkbox--disabled": "this._disabled"
			} },
			queries: [{
				propertyName: "_input",
				first: true,
				predicate: MdcCheckboxInputDirective,
				descendants: true
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcCheckboxDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcCheckbox]"
		}]
	}],
	ctorParameters: () => [
		{ type: i0.Renderer2 },
		{ type: i0.ElementRef },
		{ type: MdcEventRegistry }
	],
	propDecorators: {
		_cls: [{
			type: HostBinding,
			args: ["class.mdc-checkbox"]
		}],
		_input: [{
			type: ContentChild,
			args: [MdcCheckboxInputDirective]
		}],
		_disabled: [{
			type: HostBinding,
			args: ["class.mdc-checkbox--disabled"]
		}]
	}
});
var MdcChipIconDirective = class MdcChipIconDirective {
	constructor(_elm, _rndr, _cdRef) {
		this._elm = _elm;
		this._rndr = _rndr;
		this._cdRef = _cdRef;
		this._cls = true;
		this._leading = false;
		this.interact = new EventEmitter();
		this.__trailing = false;
	}
	get _trailing() {
		return this.__trailing;
	}
	set _trailing(val) {
		if (val !== this._trailing) {
			this.__trailing = val;
			if (this._trailing) {
				this._oldTabIndex = this._elm.nativeElement.tabIndex;
				this._elm.nativeElement.tabIndex = 0;
				this._oldRole = this._elm.nativeElement.getAttribute("role");
				this._rndr.setAttribute(this._elm.nativeElement, "role", "button");
			} else {
				if (this._oldTabIndex) {
					this._elm.nativeElement.tabIndex = this._oldTabIndex;
					if (this._oldRole) this._rndr.setAttribute(this._elm.nativeElement, "role", this._oldRole);
					else this._rndr.removeAttribute(this._elm.nativeElement, "role");
				}
				this._oldTabIndex = null;
				this._oldRole = null;
			}
		}
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcChipIconDirective,
			deps: [
				{ token: i0.ElementRef },
				{ token: i0.Renderer2 },
				{ token: i0.ChangeDetectorRef }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcChipIconDirective,
			isStandalone: false,
			selector: "[mdcChipIcon]",
			outputs: { interact: "interact" },
			host: { properties: {
				"class.mdc-chip__icon": "this._cls",
				"class.mdc-chip__icon--leading": "this._leading",
				"class.mdc-chip__icon--trailing": "this._trailing"
			} },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcChipIconDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcChipIcon]"
		}]
	}],
	ctorParameters: () => [
		{ type: i0.ElementRef },
		{ type: i0.Renderer2 },
		{ type: i0.ChangeDetectorRef }
	],
	propDecorators: {
		_cls: [{
			type: HostBinding,
			args: ["class.mdc-chip__icon"]
		}],
		_leading: [{
			type: HostBinding,
			args: ["class.mdc-chip__icon--leading"]
		}],
		interact: [{ type: Output }],
		_trailing: [{
			type: HostBinding,
			args: ["class.mdc-chip__icon--trailing"]
		}]
	}
});
var MdcChipTextDirective = class MdcChipTextDirective {
	constructor(_elm) {
		this._elm = _elm;
		this._cls = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcChipTextDirective,
			deps: [{ token: i0.ElementRef }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcChipTextDirective,
			isStandalone: false,
			selector: "[mdcChipText]",
			host: { properties: { "class.mdc-chip__text": "this._cls" } },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcChipTextDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcChipText]"
		}]
	}],
	ctorParameters: () => [{ type: i0.ElementRef }],
	propDecorators: { _cls: [{
		type: HostBinding,
		args: ["class.mdc-chip__text"]
	}] }
});
var MdcChipDirective = class MdcChipDirective extends AbstractMdcRipple {
	constructor(_elm, rndr, registry) {
		super(_elm, rndr, registry);
		this._elm = _elm;
		this._cls = true;
		this.initialized = false;
		this.selectedMem = false;
		this.interact = new EventEmitter();
		this.remove = new EventEmitter();
		this.selectedChange = new EventEmitter();
		this._adapter = {
			addClass: (className) => {
				let selectedChanged = className === "mdc-chip--selected" && !this._elm.nativeElement.classList.contains(className);
				this._renderer.addClass(this._elm.nativeElement, className);
				if (selectedChanged) this.selectedChange.emit(true);
			},
			removeClass: (className) => {
				let selectedChanged = className === "mdc-chip--selected" && this._elm.nativeElement.classList.contains(className);
				this._renderer.removeClass(this._elm.nativeElement, className);
				if (selectedChanged) this.selectedChange.emit(false);
			},
			hasClass: (className) => this._elm.nativeElement.classList.contains(className),
			addClassToLeadingIcon: (className) => {
				let icon = this._leadingIcon;
				if (icon) this._renderer.addClass(icon._elm.nativeElement, className);
			},
			removeClassFromLeadingIcon: (className) => {
				let icon = this._leadingIcon;
				if (icon) this._renderer.removeClass(icon._elm.nativeElement, className);
			},
			eventTargetHasClass: (target, className) => target.classList.contains(className),
			registerEventHandler: (evt, handler) => this._registry.listen(this._renderer, evt, handler, this._elm),
			deregisterEventHandler: (evt, handler) => this._registry.unlisten(evt, handler),
			registerTrailingIconInteractionHandler: (evt, handler) => {
				let icon = this._trailingIcon;
				if (icon) this._registry.listen(this._renderer, evt, handler, icon._elm);
			},
			deregisterTrailingIconInteractionHandler: (evt, handler) => this._registry.unlisten(evt, handler),
			notifyInteraction: () => this.interact.emit(),
			notifyTrailingIconInteraction: () => this._trailingIcon.interact.emit(),
			notifyRemoval: () => this.remove.emit(),
			getComputedStyleValue: (propertyName) => getComputedStyle(this._elm.nativeElement).getPropertyValue(propertyName),
			setStyleProperty: (style, value) => this._renderer.setStyle(this._elm.nativeElement, style, value)
		};
		this._foundation = new MDCChipFoundation(this._adapter);
	}
	ngAfterContentInit() {
		if (!this._elm.nativeElement.hasAttribute("tabindex")) this._elm.nativeElement.tabIndex = 0;
		this.initIcons();
		this._icons.changes.subscribe(() => {
			this._reInit();
		});
		this._texts.changes.subscribe(() => {
			this._reInit();
		});
		this.initRipple();
		this.initCheckMark();
		this._foundation.init();
		if (this.selectedMem) this.selected = this.selectedMem;
		this.initialized = true;
	}
	ngOnDestroy() {
		this.destroyRipple();
		this._foundation.destroy();
	}
	_reInit() {
		this._foundation.destroy();
		this._foundation = new MDCChipFoundation(this._adapter);
		this.initIcons();
		this.initCheckMark();
		this._foundation.init();
	}
	initIcons() {
		let newLeading = this.computeLeadingIcon();
		let newTrailing = this.computeTrailingIcon(newLeading);
		if (newLeading !== this._leadingIcon || newTrailing !== this._trailingIcon) {
			this._leadingIcon = newLeading;
			this._trailingIcon = newTrailing;
			this._icons.forEach((icon) => {
				let leading = icon === this._leadingIcon;
				let trailing = icon === this._trailingIcon;
				let changed = leading !== icon._leading || trailing !== icon._trailing;
				icon._leading = icon === this._leadingIcon;
				icon._trailing = icon === this._trailingIcon;
				if (changed) icon._cdRef.detectChanges();
			});
			this.removeCheckMark();
		}
	}
	computeLeadingIcon() {
		if (this._icons.length > 0) {
			let icon = this._icons.first;
			let prev = this.previousElement(icon._elm.nativeElement);
			let last = icon._elm.nativeElement;
			while (true) {
				if (prev == null && last != null && last.parentElement !== this._elm.nativeElement) prev = last.parentElement;
				if (prev == null) return icon;
				if (this._text && (prev === this._text._elm.nativeElement || prev.contains(this._text._elm.nativeElement))) return null;
				last = prev;
				prev = this.previousElement(prev);
			}
		}
		return null;
	}
	get _text() {
		return this._texts.first;
	}
	computeTrailingIcon(leading) {
		if (this._icons.length > 0) {
			let icon = this._icons.last;
			if (icon === leading) return null;
			return icon;
		}
		return null;
	}
	previousElement(el) {
		let result = el.previousSibling;
		while (result != null && !(result instanceof Element)) result = result.previousSibling;
		return result;
	}
	initCheckMark() {
		if (this._set && this._set._type === "filter") this.addCheckMark();
		else this.removeCheckMark();
	}
	addCheckMark() {
		if (!this._checkmark) {
			let path = this._renderer.createElement("path", "svg");
			this._renderer.addClass(path, "mdc-chip__checkmark-path");
			this._renderer.setAttribute(path, "fill", "none");
			this._renderer.setAttribute(path, "stroke", "black");
			this._renderer.setAttribute(path, "d", "M1.73,12.91 8.1,19.28 22.79,4.59");
			let svg = this._renderer.createElement("svg", "svg");
			this._renderer.appendChild(svg, path);
			this._renderer.addClass(svg, "mdc-chip__checkmark-svg");
			this._renderer.setAttribute(svg, "viewBox", "-2 -3 30 30");
			this._checkmark = this._renderer.createElement("div");
			this._renderer.appendChild(this._checkmark, svg);
			this._renderer.addClass(this._checkmark, "mdc-chip__checkmark");
			let beforeElement = this._text ? this._text._elm.nativeElement : null;
			if (beforeElement) this._renderer.insertBefore(this._elm.nativeElement, this._checkmark, beforeElement);
			else this._renderer.appendChild(this._elm.nativeElement, this._checkmark);
		}
	}
	removeCheckMark() {
		if (this._checkmark) {
			this._checkmark.parentElement.removeChild(this._checkmark);
			this._checkmark = null;
		}
	}
	get selected() {
		return this.initialized ? this._foundation.isSelected() : this.selectedMem;
	}
	set selected(val) {
		let value = asBoolean(val);
		this.selectedMem = value;
		if (this.initialized && value !== this._foundation.isSelected()) {
			if (value && this._set) this._set._foundation.select(this._foundation);
			else this._foundation.setSelected(val);
		}
	}
	computeRippleBoundingRect() {
		if (this._checkmark && !this._leadingIcon) {
			const height = this._rippleElm.nativeElement.getBoundingClientRect().height;
			return {
				height,
				width: height
			};
		}
		return super.computeRippleBoundingRect();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcChipDirective,
			deps: [
				{ token: i0.ElementRef },
				{ token: i0.Renderer2 },
				{ token: MdcEventRegistry }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcChipDirective,
			isStandalone: false,
			selector: "[mdcChip]",
			inputs: { selected: "selected" },
			outputs: {
				interact: "interact",
				remove: "remove",
				selectedChange: "selectedChange"
			},
			host: { properties: { "class.mdc-chip": "this._cls" } },
			queries: [{
				propertyName: "_icons",
				predicate: MdcChipIconDirective,
				descendants: true
			}, {
				propertyName: "_texts",
				predicate: MdcChipTextDirective,
				descendants: true
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcChipDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcChip]"
		}]
	}],
	ctorParameters: () => [
		{ type: i0.ElementRef },
		{ type: i0.Renderer2 },
		{ type: MdcEventRegistry }
	],
	propDecorators: {
		_cls: [{
			type: HostBinding,
			args: ["class.mdc-chip"]
		}],
		interact: [{ type: Output }],
		remove: [{ type: Output }],
		selectedChange: [{ type: Output }],
		_icons: [{
			type: ContentChildren,
			args: [MdcChipIconDirective, { descendants: true }]
		}],
		_texts: [{
			type: ContentChildren,
			args: [MdcChipTextDirective, { descendants: true }]
		}],
		selected: [{ type: Input }]
	}
});
var MdcChipSetDirective = class MdcChipSetDirective {
	constructor(_elm, _rndr, _registry) {
		this._elm = _elm;
		this._rndr = _rndr;
		this._registry = _registry;
		this._cls = true;
		this._initialized = false;
		this._type = "action";
		this._adapter = {
			hasClass: (className) => this._elm.nativeElement.classList.contains(className),
			registerInteractionHandler: (evt, handler) => {
				if (evt === "MDCChip:interaction") this._interactionHandler = handler;
				else this._registry.listen(this._rndr, evt, handler, this._elm);
			},
			deregisterInteractionHandler: (evt, handler) => {
				if (evt === "MDCChip:interaction") this._interactionHandler = null;
				else this._registry.unlisten(evt, handler);
			},
			removeChip: (chip) => {
				throw new Error("this adapter method should be unreachable in the MdcChipSetDirective implementation");
			}
		};
		this._foundation = new MDCChipSetFoundation(this._adapter);
	}
	ngAfterContentInit() {
		this._chips.changes.subscribe(() => {
			this.initSubscriptions();
			this.initChips();
		});
		this.initSubscriptions();
		this.initChips();
		this._foundation.init();
		this._initialized = true;
	}
	ngOnDestroy() {
		this._foundation.destroy();
		this.destroySubscriptions();
		this._initialized = false;
	}
	get mdcChipSet() {
		return this._type;
	}
	set mdcChipSet(value) {
		if (value !== this._type) {
			if (value === "choice" || value === "filter" || value === "input") this._type = value;
			else this._type = "action";
			if (this._initialized) this.initChips(true);
		}
	}
	initChips(force = false) {
		this._chips.forEach((chip) => {
			if (force || chip._set !== this) {
				chip._set = this;
				chip._reInit();
			}
		});
	}
	destroySubscriptions() {
		try {
			if (this._interactSubscriptions) this._interactSubscriptions.forEach((sub) => sub.unsubscribe());
			if (this._removeSubscriptions) this._removeSubscriptions.forEach((sub) => sub.unsubscribe());
		} finally {
			this._interactSubscriptions = null;
			this._removeSubscriptions = null;
		}
	}
	initSubscriptions() {
		this.destroySubscriptions();
		this._interactSubscriptions = [];
		this._removeSubscriptions = [];
		this._chips.forEach((chip) => {
			this._interactSubscriptions.push(chip.interact.subscribe((event) => {
				if (this._interactionHandler) this._interactionHandler({ detail: { chip: { foundation: chip._foundation } } });
			}));
			this._removeSubscriptions.push(chip.remove.subscribe((event) => {
				this._foundation.deselect(chip._foundation);
			}));
		});
	}
	get _choice() {
		return this._type === "choice";
	}
	get _filter() {
		return this._type === "filter";
	}
	get _input() {
		return this._type === "input";
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcChipSetDirective,
			deps: [
				{ token: i0.ElementRef },
				{ token: i0.Renderer2 },
				{ token: MdcEventRegistry }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcChipSetDirective,
			isStandalone: false,
			selector: "[mdcChipSet]",
			inputs: { mdcChipSet: "mdcChipSet" },
			host: { properties: {
				"class.mdc-chip-set": "this._cls",
				"class.mdc-chip-set--choice": "this._choice",
				"class.mdc-chip-set--filter": "this._filter",
				"class.mdc-chip-set--input": "this._input"
			} },
			queries: [{
				propertyName: "_chips",
				predicate: MdcChipDirective,
				descendants: true
			}],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcChipSetDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcChipSet]"
		}]
	}],
	ctorParameters: () => [
		{ type: i0.ElementRef },
		{ type: i0.Renderer2 },
		{ type: MdcEventRegistry }
	],
	propDecorators: {
		_cls: [{
			type: HostBinding,
			args: ["class.mdc-chip-set"]
		}],
		_chips: [{
			type: ContentChildren,
			args: [MdcChipDirective, { descendants: true }]
		}],
		mdcChipSet: [{ type: Input }],
		_choice: [{
			type: HostBinding,
			args: ["class.mdc-chip-set--choice"]
		}],
		_filter: [{
			type: HostBinding,
			args: ["class.mdc-chip-set--filter"]
		}],
		_input: [{
			type: HostBinding,
			args: ["class.mdc-chip-set--input"]
		}]
	}
});
const CHIP_DIRECTIVES = [
	MdcChipIconDirective,
	MdcChipTextDirective,
	MdcChipDirective,
	MdcChipSetDirective
];
var AbstractMdcFocusInitial = class {};
var AbstractMdcFocusTrap = class {
	constructor() {}
};
var MdcDialogHeaderTitleDirective = class MdcDialogHeaderTitleDirective {
	constructor() {
		this._cls = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcDialogHeaderTitleDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcDialogHeaderTitleDirective,
			isStandalone: false,
			selector: "[mdcDialogHeaderTitle]",
			host: { properties: { "class.mdc-dialog__header__title": "this._cls" } },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcDialogHeaderTitleDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcDialogHeaderTitle]"
		}]
	}],
	propDecorators: { _cls: [{
		type: HostBinding,
		args: ["class.mdc-dialog__header__title"]
	}] }
});
var MdcDialogHeaderDirective = class MdcDialogHeaderDirective {
	constructor() {
		this._cls = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcDialogHeaderDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcDialogHeaderDirective,
			isStandalone: false,
			selector: "[mdcDialogHeader]",
			host: { properties: { "class.mdc-dialog__header": "this._cls" } },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcDialogHeaderDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcDialogHeader]"
		}]
	}],
	propDecorators: { _cls: [{
		type: HostBinding,
		args: ["class.mdc-dialog__header"]
	}] }
});
var MdcDialogBodyDirective = class MdcDialogBodyDirective {
	constructor(_elm) {
		this._elm = _elm;
		this._cls = true;
		this._scrollable = false;
	}
	get scrollable() {
		return this._scrollable;
	}
	set scrollable(val) {
		this._scrollable = asBoolean(val);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcDialogBodyDirective,
			deps: [{ token: i0.ElementRef }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcDialogBodyDirective,
			isStandalone: false,
			selector: "[mdcDialogBody]",
			inputs: { scrollable: "scrollable" },
			host: { properties: {
				"class.mdc-dialog__body": "this._cls",
				"class.mdc-dialog__body--scrollable": "this.scrollable"
			} },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcDialogBodyDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcDialogBody]"
		}]
	}],
	ctorParameters: () => [{ type: i0.ElementRef }],
	propDecorators: {
		_cls: [{
			type: HostBinding,
			args: ["class.mdc-dialog__body"]
		}],
		scrollable: [{
			type: HostBinding,
			args: ["class.mdc-dialog__body--scrollable"]
		}, { type: Input }]
	}
});
var MdcDialogFooterDirective = class MdcDialogFooterDirective {
	constructor(_rndr) {
		this._rndr = _rndr;
		this._cls = true;
	}
	ngAfterContentInit() {
		this.initButtons();
		this._buttons.changes.subscribe(() => {
			this.initButtons();
		});
	}
	initButtons() {
		this._buttons.forEach((btn) => {
			this._rndr.addClass(btn._elm.nativeElement, "mdc-dialog__footer__button");
		});
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcDialogFooterDirective,
			deps: [{ token: i0.Renderer2 }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcDialogFooterDirective,
			isStandalone: false,
			selector: "[mdcDialogFooter]",
			host: { properties: { "class.mdc-dialog__footer": "this._cls" } },
			queries: [{
				propertyName: "_buttons",
				predicate: MdcButtonDirective,
				descendants: true
			}],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcDialogFooterDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcDialogFooter]"
		}]
	}],
	ctorParameters: () => [{ type: i0.Renderer2 }],
	propDecorators: {
		_cls: [{
			type: HostBinding,
			args: ["class.mdc-dialog__footer"]
		}],
		_buttons: [{
			type: ContentChildren,
			args: [MdcButtonDirective, { descendants: true }]
		}]
	}
});
var MdcDialogAcceptDirective = class MdcDialogAcceptDirective extends AbstractMdcFocusInitial {
	constructor(_elm) {
		super();
		this._elm = _elm;
		this.priority = 1;
		this._cls = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcDialogAcceptDirective,
			deps: [{ token: i0.ElementRef }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcDialogAcceptDirective,
			isStandalone: false,
			selector: "[mdcDialogAccept]",
			host: { properties: { "class.mdc-dialog__footer__button--accept": "this._cls" } },
			providers: [{
				provide: AbstractMdcFocusInitial,
				useExisting: forwardRef(() => MdcDialogAcceptDirective)
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcDialogAcceptDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcDialogAccept]",
			providers: [{
				provide: AbstractMdcFocusInitial,
				useExisting: forwardRef(() => MdcDialogAcceptDirective)
			}]
		}]
	}],
	ctorParameters: () => [{ type: i0.ElementRef }],
	propDecorators: { _cls: [{
		type: HostBinding,
		args: ["class.mdc-dialog__footer__button--accept"]
	}] }
});
var MdcDialogCancelDirective = class MdcDialogCancelDirective {
	constructor(_elm) {
		this._elm = _elm;
		this._cls = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcDialogCancelDirective,
			deps: [{ token: i0.ElementRef }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcDialogCancelDirective,
			isStandalone: false,
			selector: "[mdcDialogCancel]",
			host: { properties: { "class.mdc-dialog__footer__button--cancel": "this._cls" } },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcDialogCancelDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcDialogCancel]"
		}]
	}],
	ctorParameters: () => [{ type: i0.ElementRef }],
	propDecorators: { _cls: [{
		type: HostBinding,
		args: ["class.mdc-dialog__footer__button--cancel"]
	}] }
});
var MdcDialogBackdropDirective = class MdcDialogBackdropDirective {
	constructor() {
		this._cls = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcDialogBackdropDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcDialogBackdropDirective,
			isStandalone: false,
			selector: "[mdcDialogBackdrop]",
			host: { properties: { "class.mdc-dialog__backdrop": "this._cls" } },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcDialogBackdropDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcDialogBackdrop]"
		}]
	}],
	propDecorators: { _cls: [{
		type: HostBinding,
		args: ["class.mdc-dialog__backdrop"]
	}] }
});
var MdcDialogSurfaceDirective = class MdcDialogSurfaceDirective {
	constructor(_elm) {
		this._elm = _elm;
		this._cls = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcDialogSurfaceDirective,
			deps: [{ token: i0.ElementRef }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcDialogSurfaceDirective,
			isStandalone: false,
			selector: "[mdcDialogSurface]",
			host: { properties: { "class.mdc-dialog__surface": "this._cls" } },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcDialogSurfaceDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcDialogSurface]"
		}]
	}],
	ctorParameters: () => [{ type: i0.ElementRef }],
	propDecorators: { _cls: [{
		type: HostBinding,
		args: ["class.mdc-dialog__surface"]
	}] }
});
var MdcDialogDirective = class MdcDialogDirective {
	constructor(_elm, _rndr, _registry, _focusTrap) {
		this._elm = _elm;
		this._rndr = _rndr;
		this._registry = _registry;
		this._focusTrap = _focusTrap;
		this._cls = true;
		this.accept = new EventEmitter();
		this.cancel = new EventEmitter();
		this._initialized = false;
		this.mdcAdapter = {
			addClass: (className) => this._rndr.addClass(this._elm.nativeElement, className),
			removeClass: (className) => this._rndr.removeClass(this._elm.nativeElement, className),
			addBodyClass: (className) => this._rndr.addClass(document.body, className),
			removeBodyClass: (className) => this._rndr.removeClass(document.body, className),
			eventTargetHasClass: (target, className) => {
				if (className === "mdc-dialog__footer__button--accept") return this._accept.find((e) => e._elm.nativeElement === target) != null;
				else if (className === "mdc-dialog__footer__button--cancel") return this._cancel.find((e) => e._elm.nativeElement === target) != null;
				return target.classList.contains(className);
			},
			registerInteractionHandler: (evt, handler) => this._registry.listen(this._rndr, evt, handler, this._elm),
			deregisterInteractionHandler: (evt, handler) => this._registry.unlisten(evt, handler),
			registerSurfaceInteractionHandler: (evt, handler) => {
				if (this._surface) this._registry.listen(this._rndr, evt, handler, this._surface._elm);
			},
			deregisterSurfaceInteractionHandler: (evt, handler) => this._registry.unlisten(evt, handler),
			registerDocumentKeydownHandler: (handler) => this._registry.listenElm(this._rndr, "keydown", handler, document.body),
			deregisterDocumentKeydownHandler: (handler) => this._registry.unlisten("keydown", handler),
			registerTransitionEndHandler: (handler) => {
				if (this._surface) this._registry.listen(this._rndr, "transitionend", handler, this._surface._elm);
			},
			deregisterTransitionEndHandler: (handler) => this._registry.unlisten("transitionend", handler),
			notifyAccept: () => this.accept.emit(),
			notifyCancel: () => this.cancel.emit(),
			trapFocusOnSurface: () => this.trapFocus(),
			untrapFocusOnSurface: () => this.untrapFocus(),
			isDialog: (el) => this._surface && el === this._surface._elm.nativeElement
		};
		this.foundation = new MDCDialogFoundation(this.mdcAdapter);
	}
	ngAfterContentInit() {
		this.foundation.init();
		this._initialized = true;
	}
	ngOnDestroy() {
		this._initialized = false;
		this.foundation.destroy();
	}
	open() {
		this.foundation.open();
	}
	trapFocus() {
		this.untrapFocus();
		if (this._focusTrap) this.focusTrapHandle = this._focusTrap.trapFocus();
	}
	untrapFocus() {
		if (this.focusTrapHandle && this.focusTrapHandle.active) {
			this.focusTrapHandle.untrap();
			this.focusTrapHandle = null;
		}
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcDialogDirective,
			deps: [
				{ token: i0.ElementRef },
				{ token: i0.Renderer2 },
				{ token: MdcEventRegistry },
				{
					token: AbstractMdcFocusTrap,
					optional: true,
					self: true
				}
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcDialogDirective,
			isStandalone: false,
			selector: "[mdcDialog]",
			outputs: {
				accept: "accept",
				cancel: "cancel"
			},
			host: { properties: { "class.mdc-dialog": "this._cls" } },
			queries: [
				{
					propertyName: "_surface",
					first: true,
					predicate: MdcDialogSurfaceDirective,
					descendants: true
				},
				{
					propertyName: "_accept",
					predicate: MdcDialogAcceptDirective,
					descendants: true
				},
				{
					propertyName: "_cancel",
					predicate: MdcDialogCancelDirective,
					descendants: true
				}
			],
			exportAs: ["mdcDialog"],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcDialogDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcDialog]",
			exportAs: "mdcDialog"
		}]
	}],
	ctorParameters: () => [
		{ type: i0.ElementRef },
		{ type: i0.Renderer2 },
		{ type: MdcEventRegistry },
		{
			type: AbstractMdcFocusTrap,
			decorators: [{ type: Optional }, { type: Self }]
		}
	],
	propDecorators: {
		_cls: [{
			type: HostBinding,
			args: ["class.mdc-dialog"]
		}],
		_surface: [{
			type: ContentChild,
			args: [MdcDialogSurfaceDirective]
		}],
		_accept: [{
			type: ContentChildren,
			args: [MdcDialogAcceptDirective, { descendants: true }]
		}],
		_cancel: [{
			type: ContentChildren,
			args: [MdcDialogCancelDirective, { descendants: true }]
		}],
		accept: [{ type: Output }],
		cancel: [{ type: Output }]
	}
});
const DIALOG_DIRECTIVES = [
	MdcDialogDirective,
	MdcDialogHeaderTitleDirective,
	MdcDialogHeaderDirective,
	MdcDialogBodyDirective,
	MdcDialogFooterDirective,
	MdcDialogAcceptDirective,
	MdcDialogCancelDirective,
	MdcDialogBackdropDirective,
	MdcDialogSurfaceDirective
];
var AbstractDrawerElement = class {
	constructor() {
		this._drawerType = "permanent";
	}
};
var MdcDrawerToolbarSpacerDirective = class MdcDrawerToolbarSpacerDirective extends AbstractDrawerElement {
	constructor() {
		super();
		this._cls = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcDrawerToolbarSpacerDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcDrawerToolbarSpacerDirective,
			isStandalone: false,
			selector: "[mdcDrawerToolbarSpacer]",
			host: { properties: { "class.mdc-drawer__toolbar-spacer": "this._cls" } },
			providers: [{
				provide: AbstractDrawerElement,
				useExisting: forwardRef(() => MdcDrawerToolbarSpacerDirective)
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcDrawerToolbarSpacerDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcDrawerToolbarSpacer]",
			providers: [{
				provide: AbstractDrawerElement,
				useExisting: forwardRef(() => MdcDrawerToolbarSpacerDirective)
			}]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { _cls: [{
		type: HostBinding,
		args: ["class.mdc-drawer__toolbar-spacer"]
	}] }
});
var MdcDrawerHeaderDirective = class MdcDrawerHeaderDirective extends AbstractDrawerElement {
	constructor() {
		super();
		this._cls = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcDrawerHeaderDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcDrawerHeaderDirective,
			isStandalone: false,
			selector: "[mdcDrawerHeader]",
			host: { properties: { "class.mdc-drawer__header": "this._cls" } },
			providers: [{
				provide: AbstractDrawerElement,
				useExisting: forwardRef(() => MdcDrawerHeaderDirective)
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcDrawerHeaderDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcDrawerHeader]",
			providers: [{
				provide: AbstractDrawerElement,
				useExisting: forwardRef(() => MdcDrawerHeaderDirective)
			}]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { _cls: [{
		type: HostBinding,
		args: ["class.mdc-drawer__header"]
	}] }
});
var MdcDrawerHeaderContentDirective = class MdcDrawerHeaderContentDirective extends AbstractDrawerElement {
	constructor() {
		super();
		this._cls = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcDrawerHeaderContentDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcDrawerHeaderContentDirective,
			isStandalone: false,
			selector: "[mdcDrawerHeaderContent]",
			host: { properties: { "class.mdc-drawer__header-content": "this._cls" } },
			providers: [{
				provide: AbstractDrawerElement,
				useExisting: forwardRef(() => MdcDrawerHeaderContentDirective)
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcDrawerHeaderContentDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcDrawerHeaderContent]",
			providers: [{
				provide: AbstractDrawerElement,
				useExisting: forwardRef(() => MdcDrawerHeaderContentDirective)
			}]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { _cls: [{
		type: HostBinding,
		args: ["class.mdc-drawer__header-content"]
	}] }
});
var MdcDrawerContentDirective = class MdcDrawerContentDirective extends AbstractDrawerElement {
	constructor() {
		super();
		this._cls = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcDrawerContentDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcDrawerContentDirective,
			isStandalone: false,
			selector: "[mdcDrawerContent]",
			host: { properties: { "class.mdc-drawer__content": "this._cls" } },
			providers: [{
				provide: AbstractDrawerElement,
				useExisting: forwardRef(() => MdcDrawerContentDirective)
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcDrawerContentDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcDrawerContent]",
			providers: [{
				provide: AbstractDrawerElement,
				useExisting: forwardRef(() => MdcDrawerContentDirective)
			}]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { _cls: [{
		type: HostBinding,
		args: ["class.mdc-drawer__content"]
	}] }
});
var MdcDrawerDirective = class MdcDrawerDirective {
	constructor(_elm) {
		this._elm = _elm;
		this.initialized = false;
		this.type = "permanent";
	}
	ngAfterContentInit() {
		this.initialized = true;
		this.updateTypeForChildren();
		this._children.changes.subscribe(() => {
			this.updateTypeForChildren();
		});
	}
	updateTypeForChildren() {
		if (this.initialized) this._children.forEach((child) => {
			child._drawerType = this.type;
		});
	}
	_setType(drawerType) {
		this.type = drawerType;
		this.updateTypeForChildren();
	}
	get _isPermanent() {
		return this.type === "permanent";
	}
	get _isContainedDrawer() {
		return this.type === "persistent" || this.type === "temporary";
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcDrawerDirective,
			deps: [{ token: i0.ElementRef }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcDrawerDirective,
			isStandalone: false,
			selector: "[mdcDrawer]",
			host: { properties: {
				"class.mdc-drawer--permanent": "this._isPermanent",
				"class.mdc-drawer__drawer": "this._isContainedDrawer"
			} },
			providers: [{
				provide: AbstractDrawerElement,
				useExisting: forwardRef(() => MdcDrawerDirective)
			}],
			queries: [{
				propertyName: "_children",
				predicate: AbstractDrawerElement,
				descendants: true
			}],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcDrawerDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcDrawer]",
			providers: [{
				provide: AbstractDrawerElement,
				useExisting: forwardRef(() => MdcDrawerDirective)
			}]
		}]
	}],
	ctorParameters: () => [{ type: i0.ElementRef }],
	propDecorators: {
		_children: [{
			type: ContentChildren,
			args: [AbstractDrawerElement, { descendants: true }]
		}],
		_isPermanent: [{
			type: HostBinding,
			args: ["class.mdc-drawer--permanent"]
		}],
		_isContainedDrawer: [{
			type: HostBinding,
			args: ["class.mdc-drawer__drawer"]
		}]
	}
});
var MdcDrawerContainerDirective = class MdcDrawerContainerDirective {
	constructor(_elm, _rndr, _registry) {
		this._elm = _elm;
		this._rndr = _rndr;
		this._registry = _registry;
		this.initialized = false;
		this.openChange = new EventEmitter();
		this.type = "persistent";
	}
	ngAfterContentInit() {
		this.initialized = true;
		this.updateType();
		this.initDrawer();
		this._drawers.changes.subscribe(() => {
			this.updateType();
		});
	}
	ngOnDestroy() {
		this.destroyDrawer();
	}
	updateType() {
		if (this.initialized) this.forDrawer((d) => {
			d._setType(this.type);
		});
	}
	destroyDrawer() {
		if (this.foundation) {
			this.openMem = this.foundation.isOpen();
			this.foundation.destroy();
			this.foundation = null;
		}
	}
	initDrawer() {
		if (this.initialized) {
			this.destroyDrawer();
			if (this.hasNecessaryDom()) {
				this.createAdapter();
				let newFoundation = this.type === "temporary" ? new MDCTemporaryDrawerFoundation(this.mdcAdapter) : new MDCPersistentDrawerFoundation(this.mdcAdapter);
				newFoundation.init();
				this.open = this.openMem;
				this.foundation = newFoundation;
			} else console.error("mdcDrawerContainer can't be constructed because of missing DOM elements");
		}
	}
	createAdapter() {
		let adapter = {
			addClass: (className) => {
				if ("mdc-drawer--open" !== className) this._rndr.addClass(this._elm.nativeElement, className);
			},
			removeClass: (className) => {
				if ("mdc-drawer--open" !== className) this._rndr.removeClass(this._elm.nativeElement, className);
			},
			hasClass: (className) => {
				if ("mdc-drawer--persistent" === className) return this.type === "persistent";
				else if ("mdc-drawer--temporary" === className) return this.type === "temporary";
				else if ("mdc-drawer--open" === className) return this.open;
				else return this._elm.nativeElement.classList.contains(className);
			},
			hasNecessaryDom: () => this.hasNecessaryDom(),
			registerInteractionHandler: (evt, handler) => this._registry.listen(this._rndr, util$1.remapEvent(evt), handler, this._elm, util$1.applyPassive()),
			deregisterInteractionHandler: (evt, handler) => this._registry.unlisten(util$1.remapEvent(evt), handler),
			registerDrawerInteractionHandler: (evt, handler) => this._registry.listen(this._rndr, util$1.remapEvent(evt), handler, this.drawer._elm),
			deregisterDrawerInteractionHandler: (evt, handler) => this._registry.unlisten(util$1.remapEvent(evt), handler),
			registerTransitionEndHandler: (handler) => this._registry.listen(this._rndr, "transitionend", handler, this._elm),
			deregisterTransitionEndHandler: (handler) => this._registry.unlisten("transitionend", handler),
			registerDocumentKeydownHandler: (handler) => this._registry.listenElm(this._rndr, "keydown", handler, document),
			deregisterDocumentKeydownHandler: (handler) => this._registry.unlisten("keydown", handler),
			setTranslateX: (value) => this.forDrawer((d) => {
				return d._elm.nativeElement.style.setProperty(util$1.getTransformPropertyName(), value === null ? null : `translateX(${value}px)`);
			}),
			getFocusableElements: () => this.forDrawer((d) => {
				return d._elm.nativeElement.querySelectorAll(FOCUSABLE_ELEMENTS);
			}),
			saveElementTabState: (el) => util$1.saveElementTabState(el),
			restoreElementTabState: (el) => util$1.restoreElementTabState(el),
			makeElementUntabbable: (el) => el.tabIndex = -1,
			notifyOpen: () => this.openChange.emit(true),
			notifyClose: () => this.openChange.emit(false),
			isRtl: () => getComputedStyle(this._elm.nativeElement).getPropertyValue("direction") === "rtl",
			getDrawerWidth: () => this.forDrawer((d) => d._elm.nativeElement.offsetWidth, 0),
			isDrawer: (el) => this.drawer && this.drawer._elm.nativeElement === el,
			addBodyClass: (className) => {
				this._rndr.addClass(document.body, className);
			},
			removeBodyClass: (className) => {
				this._rndr.removeClass(document.body, className);
			},
			updateCssVariable: (value) => {
				if (util$1.supportsCssCustomProperties()) this._elm.nativeElement.style.setProperty(MDCTemporaryDrawerFoundation.strings.OPACITY_VAR_NAME, value);
			},
			eventTargetHasClass: (target, className) => {
				if (target === this._elm.nativeElement && className === "mdc-drawer--temporary") return this.type === "temporary";
				return target.classList.contains(className);
			}
		};
		this.mdcAdapter = adapter;
	}
	hasNecessaryDom() {
		return this.drawer != null;
	}
	get drawer() {
		if (this._drawers && this._drawers.length > 0) return this._drawers.first;
		return null;
	}
	forDrawer(func, defaultVal = null) {
		let theDrawer = this.drawer;
		return theDrawer ? func(theDrawer) : defaultVal;
	}
	get mdcDrawerContainer() {
		return this.type;
	}
	set mdcDrawerContainer(value) {
		const type = value === "temporary" ? "temporary" : "persistent";
		if (type !== this.type) {
			this.type = type;
			this.updateType();
			this.initDrawer();
		}
	}
	get _isPersistent() {
		return this.type === "persistent";
	}
	get _isTemporary() {
		return this.type === "temporary";
	}
	get _isOpenCls() {
		return (this.type === "persistent" || this.type === "temporary") && this.open;
	}
	get open() {
		return this.foundation ? this.foundation.isOpen() : this.openMem;
	}
	set open(value) {
		let newValue = asBoolean(value);
		if (newValue !== this.open) {
			this.openMem = newValue;
			if (this.foundation) {
				if (newValue) this.foundation.open();
				else this.foundation.close();
			} else this.openChange.emit(newValue);
		}
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcDrawerContainerDirective,
			deps: [
				{ token: i0.ElementRef },
				{ token: i0.Renderer2 },
				{ token: MdcEventRegistry }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcDrawerContainerDirective,
			isStandalone: false,
			selector: "[mdcDrawerContainer]",
			inputs: {
				mdcDrawerContainer: "mdcDrawerContainer",
				open: "open"
			},
			outputs: { openChange: "openChange" },
			host: { properties: {
				"class.mdc-drawer--persistent": "this._isPersistent",
				"class.mdc-drawer--temporary": "this._isTemporary",
				"class.mdc-drawer--open": "this._isOpenCls"
			} },
			queries: [{
				propertyName: "_drawers",
				predicate: MdcDrawerDirective
			}],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcDrawerContainerDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcDrawerContainer]"
		}]
	}],
	ctorParameters: () => [
		{ type: i0.ElementRef },
		{ type: i0.Renderer2 },
		{ type: MdcEventRegistry }
	],
	propDecorators: {
		_drawers: [{
			type: ContentChildren,
			args: [MdcDrawerDirective]
		}],
		openChange: [{ type: Output }],
		mdcDrawerContainer: [{ type: Input }],
		_isPersistent: [{
			type: HostBinding,
			args: ["class.mdc-drawer--persistent"]
		}],
		_isTemporary: [{
			type: HostBinding,
			args: ["class.mdc-drawer--temporary"]
		}],
		_isOpenCls: [{
			type: HostBinding,
			args: ["class.mdc-drawer--open"]
		}],
		open: [{ type: Input }]
	}
});
var MdcElevationDirective = class MdcElevationDirective {
	constructor(rndr, _elm) {
		this.rndr = rndr;
		this._elm = _elm;
		this._z = null;
	}
	get mdcElevation() {
		return this._z;
	}
	set mdcElevation(value) {
		let newValue = value == null || value === "" ? 1 : +value;
		if (newValue < 0) newValue = 0;
		if (newValue > 24) newValue = 24;
		if (isNaN(newValue)) newValue = 0;
		if (newValue !== this._z) {
			if (this._z != null) this.rndr.removeClass(this._elm.nativeElement, "mdc-elevation--z" + this._z);
			this.rndr.addClass(this._elm.nativeElement, "mdc-elevation--z" + newValue);
		}
		this._z = newValue;
	}
	get animateTransition() {
		return this._transition;
	}
	set animateTransition(value) {
		this._transition = asBoolean(value);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcElevationDirective,
			deps: [{ token: i0.Renderer2 }, { token: i0.ElementRef }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcElevationDirective,
			isStandalone: false,
			selector: "[mdcElevation]",
			inputs: {
				mdcElevation: "mdcElevation",
				animateTransition: "animateTransition"
			},
			host: { properties: { "class.mdc-elevation-transition": "this.animateTransition" } },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcElevationDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcElevation]"
		}]
	}],
	ctorParameters: () => [{ type: i0.Renderer2 }, { type: i0.ElementRef }],
	propDecorators: {
		mdcElevation: [{ type: Input }],
		animateTransition: [{
			type: HostBinding,
			args: ["class.mdc-elevation-transition"]
		}, { type: Input }]
	}
});
var MdcFabIconDirective = class MdcFabIconDirective {
	constructor() {
		this._cls = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcFabIconDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcFabIconDirective,
			isStandalone: false,
			selector: "[mdcFabIcon]",
			host: { properties: { "class.mdc-fab__icon": "this._cls" } },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcFabIconDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcFabIcon]"
		}]
	}],
	propDecorators: { _cls: [{
		type: HostBinding,
		args: ["class.mdc-fab__icon"]
	}] }
});
var MdcFabDirective = class MdcFabDirective extends AbstractMdcRipple {
	constructor(_elm, renderer, registry) {
		super(_elm, renderer, registry);
		this._elm = _elm;
		this._cls = true;
		this._mini = false;
		this._exited = false;
	}
	ngAfterContentInit() {
		this.initRipple();
	}
	ngOnDestroy() {
		this.destroyRipple();
	}
	get mini() {
		return this._mini;
	}
	set mini(val) {
		this._mini = asBoolean(val);
	}
	get exited() {
		return this._exited;
	}
	set exited(val) {
		this._exited = asBoolean(val);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcFabDirective,
			deps: [
				{ token: i0.ElementRef },
				{ token: i0.Renderer2 },
				{ token: MdcEventRegistry }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcFabDirective,
			isStandalone: false,
			selector: "[mdcFab]",
			inputs: {
				mini: "mini",
				exited: "exited"
			},
			host: { properties: {
				"class.mdc-fab": "this._cls",
				"class.mdc-fab--mini": "this.mini",
				"class.mdc-fab--exited": "this.exited"
			} },
			providers: [{
				provide: AbstractMdcRipple,
				useExisting: forwardRef(() => MdcFabDirective)
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcFabDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcFab]",
			providers: [{
				provide: AbstractMdcRipple,
				useExisting: forwardRef(() => MdcFabDirective)
			}]
		}]
	}],
	ctorParameters: () => [
		{ type: i0.ElementRef },
		{ type: i0.Renderer2 },
		{ type: MdcEventRegistry }
	],
	propDecorators: {
		_cls: [{
			type: HostBinding,
			args: ["class.mdc-fab"]
		}],
		mini: [{
			type: HostBinding,
			args: ["class.mdc-fab--mini"]
		}, { type: Input }],
		exited: [{
			type: HostBinding,
			args: ["class.mdc-fab--exited"]
		}, { type: Input }]
	}
});
var AbstractMdcLabel = class {};
var MdcFloatingLabelDirective = class MdcFloatingLabelDirective extends AbstractMdcLabel {
	constructor(_rndr, _elm, registry) {
		super();
		this._rndr = _rndr;
		this._elm = _elm;
		this.registry = registry;
		this._initialized = false;
		this._cls = true;
		this._mdcAdapter = {
			addClass: (className) => {
				this._rndr.addClass(this._elm.nativeElement, className);
			},
			removeClass: (className) => {
				this._rndr.removeClass(this._elm.nativeElement, className);
			},
			getWidth: () => this._elm.nativeElement.offsetWidth,
			registerInteractionHandler: (type, handler) => {
				this.registry.listen(this._rndr, type, handler, this._elm);
			},
			deregisterInteractionHandler: (type, handler) => {
				this.registry.unlisten(type, handler);
			}
		};
		this._foundation = new MDCFloatingLabelFoundation(this._mdcAdapter);
	}
	ngAfterContentInit() {
		this._foundation.init();
		this._initialized = true;
	}
	ngOnDestroy() {
		this._foundation.init();
		this._initialized = false;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcFloatingLabelDirective,
			deps: [
				{ token: i0.Renderer2 },
				{ token: i0.ElementRef },
				{ token: MdcEventRegistry }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcFloatingLabelDirective,
			isStandalone: false,
			selector: "label[mdcFloatingLabel]",
			host: { properties: {
				"for": "this.for",
				"class.mdc-floating-label": "this._cls"
			} },
			providers: [{
				provide: AbstractMdcLabel,
				useExisting: forwardRef(() => MdcFloatingLabelDirective)
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcFloatingLabelDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "label[mdcFloatingLabel]",
			providers: [{
				provide: AbstractMdcLabel,
				useExisting: forwardRef(() => MdcFloatingLabelDirective)
			}]
		}]
	}],
	ctorParameters: () => [
		{ type: i0.Renderer2 },
		{ type: i0.ElementRef },
		{ type: MdcEventRegistry }
	],
	propDecorators: {
		for: [{ type: HostBinding }],
		_cls: [{
			type: HostBinding,
			args: ["class.mdc-floating-label"]
		}]
	}
});
var MdcFocusInitialDirective = class MdcFocusInitialDirective extends AbstractMdcFocusInitial {
	constructor(_elm) {
		super();
		this._elm = _elm;
		this.priority = 100;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcFocusInitialDirective,
			deps: [{ token: i0.ElementRef }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcFocusInitialDirective,
			isStandalone: false,
			selector: "[mdcFocusInitial]",
			providers: [{
				provide: AbstractMdcFocusInitial,
				useExisting: forwardRef(() => MdcFocusInitialDirective)
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcFocusInitialDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcFocusInitial]",
			providers: [{
				provide: AbstractMdcFocusInitial,
				useExisting: forwardRef(() => MdcFocusInitialDirective)
			}]
		}]
	}],
	ctorParameters: () => [{ type: i0.ElementRef }]
});
var FocusTrapHandleImpl = class {
	constructor(_elm, options) {
		this._elm = _elm;
		this._active = true;
		options.onActivate = () => {
			this._active = true;
			activeTrap = this;
		};
		options.onDeactivate = () => {
			this._active = false;
			activeTrap = null;
		};
		this.trap = createFocusTrap(_elm.nativeElement, options);
		this.trap.activate();
	}
	untrap() {
		this.trap.deactivate();
	}
	get active() {
		return this._active;
	}
};
let activeTrap = null;
var MdcFocusTrapDirective = class MdcFocusTrapDirective extends AbstractMdcFocusTrap {
	constructor(_elm) {
		super();
		this._elm = _elm;
		this._untrapOnOutsideClick = false;
		this._ignoreEscape = false;
	}
	ngOnDestroy() {
		if (activeTrap && activeTrap._elm.nativeElement === this._elm.nativeElement) activeTrap.untrap();
	}
	trapFocus() {
		if (activeTrap) throw new Error("An mdcFocusTrap is already active.");
		let options = {
			clickOutsideDeactivates: this._untrapOnOutsideClick,
			escapeDeactivates: !this._ignoreEscape
		};
		if (this._focusInitial.length > 0) {
			let fi = null;
			this._focusInitial.forEach((focus) => fi = fi == null || fi.priority <= focus.priority ? focus : fi);
			if (fi) options.initialFocus = fi._elm.nativeElement;
		}
		return new FocusTrapHandleImpl(this._elm, options);
	}
	get untrapOnOutsideClick() {
		return this._untrapOnOutsideClick;
	}
	set untrapOnOutsideClick(value) {
		this._untrapOnOutsideClick = asBoolean(value);
	}
	get ignoreEscape() {
		return this._ignoreEscape;
	}
	set ignoreEscape(value) {
		this._ignoreEscape = asBoolean(value);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcFocusTrapDirective,
			deps: [{ token: i0.ElementRef }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcFocusTrapDirective,
			isStandalone: false,
			selector: "[mdcFocusTrap]",
			inputs: {
				untrapOnOutsideClick: "untrapOnOutsideClick",
				ignoreEscape: "ignoreEscape"
			},
			providers: [{
				provide: AbstractMdcFocusTrap,
				useExisting: forwardRef(() => MdcFocusTrapDirective)
			}],
			queries: [{
				propertyName: "_focusInitial",
				predicate: AbstractMdcFocusInitial,
				descendants: true
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcFocusTrapDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcFocusTrap]",
			providers: [{
				provide: AbstractMdcFocusTrap,
				useExisting: forwardRef(() => MdcFocusTrapDirective)
			}]
		}]
	}],
	ctorParameters: () => [{ type: i0.ElementRef }],
	propDecorators: {
		_focusInitial: [{
			type: ContentChildren,
			args: [AbstractMdcFocusInitial, { descendants: true }]
		}],
		untrapOnOutsideClick: [{ type: Input }],
		ignoreEscape: [{ type: Input }]
	}
});
const FOCUS_TRAP_DIRECTIVES = [MdcFocusInitialDirective, MdcFocusTrapDirective];
let nextId$2 = 1;
var MdcFormFieldInputDirective = class MdcFormFieldInputDirective extends AbstractMdcInput {
	constructor(_elm, _cntr) {
		super();
		this._elm = _elm;
		this._cntr = _cntr;
		this._disabled = false;
	}
	get id() {
		return this._id;
	}
	set id(value) {
		this._id = value;
	}
	get disabled() {
		return this._cntr ? this._cntr.disabled : this._disabled;
	}
	set disabled(value) {
		this._disabled = asBoolean(value);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcFormFieldInputDirective,
			deps: [{ token: i0.ElementRef }, {
				token: i1.NgControl,
				optional: true,
				self: true
			}],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcFormFieldInputDirective,
			isStandalone: false,
			selector: "input[mdcFormFieldInput], textarea[mdcFormFieldInput]",
			inputs: {
				id: "id",
				disabled: "disabled"
			},
			host: { properties: {
				"id": "this.id",
				"disabled": "this.disabled"
			} },
			providers: [{
				provide: AbstractMdcInput,
				useExisting: forwardRef(() => MdcFormFieldInputDirective)
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcFormFieldInputDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "input[mdcFormFieldInput], textarea[mdcFormFieldInput]",
			providers: [{
				provide: AbstractMdcInput,
				useExisting: forwardRef(() => MdcFormFieldInputDirective)
			}]
		}]
	}],
	ctorParameters: () => [{ type: i0.ElementRef }, {
		type: i1.NgControl,
		decorators: [{ type: Optional }, { type: Self }]
	}],
	propDecorators: {
		id: [{ type: HostBinding }, { type: Input }],
		disabled: [{ type: HostBinding }, { type: Input }]
	}
});
var MdcFormFieldLabelDirective = class MdcFormFieldLabelDirective extends AbstractMdcLabel {
	constructor(_elm) {
		super();
		this._elm = _elm;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcFormFieldLabelDirective,
			deps: [{ token: i0.ElementRef }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcFormFieldLabelDirective,
			isStandalone: false,
			selector: "label[mdcFormFieldLabel]",
			inputs: { for: "for" },
			host: { properties: { "for": "this.for" } },
			providers: [{
				provide: AbstractMdcLabel,
				useExisting: forwardRef(() => MdcFormFieldLabelDirective)
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcFormFieldLabelDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "label[mdcFormFieldLabel]",
			providers: [{
				provide: AbstractMdcLabel,
				useExisting: forwardRef(() => MdcFormFieldLabelDirective)
			}]
		}]
	}],
	ctorParameters: () => [{ type: i0.ElementRef }],
	propDecorators: { for: [{ type: HostBinding }, { type: Input }] }
});
var MdcFormFieldDirective = class MdcFormFieldDirective {
	constructor(renderer, root, registry) {
		this.renderer = renderer;
		this.root = root;
		this.registry = registry;
		this._cls = true;
		this._alignEnd = false;
		this.mdcAdapter = {
			registerInteractionHandler: (type, handler) => {
				this.registry.listen(this.renderer, type, handler, this.root);
			},
			deregisterInteractionHandler: (type, handler) => {
				this.registry.unlisten(type, handler);
			},
			activateInputRipple: () => {
				if (this.rippleChild) this.rippleChild.activateRipple();
			},
			deactivateInputRipple: () => {
				if (this.rippleChild) this.rippleChild.deactivateRipple();
			}
		};
		this.foundation = new MDCFormFieldFoundation(this.mdcAdapter);
	}
	ngAfterContentInit() {
		if (this.mdcInput != null && this.mdcLabel != null) {
			if (this.mdcInput.id == null && this.mdcLabel.for == null) this.mdcInput.id = this.mdcLabel.for = `mdc-form-input-${nextId$2++}`;
			else if (this.mdcInput.id == null) this.mdcInput.id = this.mdcLabel.for;
			else if (this.mdcLabel.for == null) this.mdcLabel.for = this.mdcInput.id;
		}
		this.foundation.init();
	}
	ngOnDestroy() {
		this.foundation.destroy();
	}
	get alignEnd() {
		return this._alignEnd;
	}
	set alignEnd(val) {
		this._alignEnd = asBoolean(val);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcFormFieldDirective,
			deps: [
				{ token: i0.Renderer2 },
				{ token: i0.ElementRef },
				{ token: MdcEventRegistry }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcFormFieldDirective,
			isStandalone: false,
			selector: "[mdcFormField]",
			inputs: { alignEnd: "alignEnd" },
			host: { properties: {
				"class.mdc-form-field": "this._cls",
				"class.mdc-form-field--align-end": "this.alignEnd"
			} },
			queries: [
				{
					propertyName: "rippleChild",
					first: true,
					predicate: AbstractMdcRipple,
					descendants: true
				},
				{
					propertyName: "mdcInput",
					first: true,
					predicate: AbstractMdcInput,
					descendants: true
				},
				{
					propertyName: "mdcLabel",
					first: true,
					predicate: AbstractMdcLabel,
					descendants: true
				}
			],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcFormFieldDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcFormField]"
		}]
	}],
	ctorParameters: () => [
		{ type: i0.Renderer2 },
		{ type: i0.ElementRef },
		{ type: MdcEventRegistry }
	],
	propDecorators: {
		_cls: [{
			type: HostBinding,
			args: ["class.mdc-form-field"]
		}],
		rippleChild: [{
			type: ContentChild,
			args: [AbstractMdcRipple]
		}],
		mdcInput: [{
			type: ContentChild,
			args: [AbstractMdcInput]
		}],
		mdcLabel: [{
			type: ContentChild,
			args: [AbstractMdcLabel]
		}],
		alignEnd: [{ type: Input }, {
			type: HostBinding,
			args: ["class.mdc-form-field--align-end"]
		}]
	}
});
var MdcIconButtonIconDirective = class MdcIconButtonIconDirective {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcIconButtonIconDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcIconButtonIconDirective,
			isStandalone: false,
			selector: "[mdcIconButtonIcon]",
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcIconButtonIconDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcIconButtonIcon]"
		}]
	}]
});
var MdcIconButtonDirective = class MdcIconButtonDirective extends AbstractMdcIcon {
	constructor(_elm, renderer, registry) {
		super(_elm, renderer, registry);
		this._hostClass = true;
		this._disabled = false;
	}
	ngAfterContentInit() {
		this.initRipple();
	}
	ngOnDestroy() {
		this.destroyRipple();
	}
	get disabled() {
		return this._disabled;
	}
	set disabled(value) {
		this._disabled = asBoolean(value);
	}
	isRippleUnbounded() {
		return true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcIconButtonDirective,
			deps: [
				{ token: i0.ElementRef },
				{ token: i0.Renderer2 },
				{ token: MdcEventRegistry }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcIconButtonDirective,
			isStandalone: false,
			selector: "[mdcIconButton]:not([iconOn])",
			inputs: { disabled: "disabled" },
			host: { properties: {
				"class.mdc-icon-button": "this._hostClass",
				"class.mdc-icon-button--disabled": "this.disabled"
			} },
			providers: [{
				provide: AbstractMdcRipple,
				useExisting: forwardRef(() => MdcIconButtonDirective)
			}, {
				provide: AbstractMdcIcon,
				useExisting: forwardRef(() => MdcIconButtonDirective)
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcIconButtonDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcIconButton]:not([iconOn])",
			providers: [{
				provide: AbstractMdcRipple,
				useExisting: forwardRef(() => MdcIconButtonDirective)
			}, {
				provide: AbstractMdcIcon,
				useExisting: forwardRef(() => MdcIconButtonDirective)
			}]
		}]
	}],
	ctorParameters: () => [
		{ type: i0.ElementRef },
		{ type: i0.Renderer2 },
		{ type: MdcEventRegistry }
	],
	propDecorators: {
		_hostClass: [{
			type: HostBinding,
			args: ["class.mdc-icon-button"]
		}],
		disabled: [{ type: Input }, {
			type: HostBinding,
			args: ["class.mdc-icon-button--disabled"]
		}]
	}
});
var MdcIconButtonToggleDirective = class MdcIconButtonToggleDirective extends AbstractMdcIcon {
	constructor(_elm, rndr, registry) {
		super(_elm, rndr, registry);
		this._hostClass = true;
		this.onChange = new EventEmitter();
		this._onChange = (value) => {};
		this._onTouched = () => {};
		this._initialized = false;
		this._on = false;
		this.toggleAdapter = {
			addClass: (className) => this._renderer.addClass(this.iconElm, className),
			removeClass: (className) => this._renderer.removeClass(this.iconElm, className),
			registerInteractionHandler: (type, handler) => this._registry.listen(this._renderer, type, handler, this._elm),
			deregisterInteractionHandler: (type, handler) => this._registry.unlisten(type, handler),
			setText: (text) => this.iconElm.textContent = text,
			getAttr: (name) => {
				if (name === "data-toggle-on-label") return this._labelOn;
				else if (name === "data-toggle-off-label") return this._labelOff;
				else if (name === "data-toggle-on-content") return this.iconIsClass ? null : this._iconOn;
				else if (name === "data-toggle-off-content") return this.iconIsClass ? null : this._iconOff;
				else if (name === "data-toggle-on-class") return this.iconIsClass ? this._iconOn : null;
				else if (name === "data-toggle-off-class") return this.iconIsClass ? this._iconOff : null;
				return this._elm.nativeElement.getAttribute(name);
			},
			setAttr: (name, value) => this._renderer.setAttribute(this._elm.nativeElement, name, value),
			notifyChange: (evtData) => {
				this._on = evtData.isOn;
				this.notifyChange();
			}
		};
	}
	ngAfterContentInit() {
		this.initRipple();
		this.toggleFoundation = new MDCIconButtonToggleFoundation(this.toggleAdapter);
		this.toggleFoundation.init();
		this.toggleFoundation.toggle(this._on);
		this._initialized = true;
	}
	ngOnDestroy() {
		this.destroyRipple();
		this.toggleFoundation.destroy();
	}
	refreshToggleData() {
		if (this._initialized) {
			this.toggleFoundation.refreshToggleData();
			this.toggleFoundation.toggle(this._on);
		}
	}
	get iconElm() {
		return this._innerIcon ? this._innerIcon.nativeElement : this._elm.nativeElement;
	}
	notifyChange() {
		this._onChange(this._on);
		this.onChange.emit(this._on);
	}
	writeValue(obj) {
		this._on;
		this._on = !!obj;
		if (this._initialized) this.toggleFoundation.toggle(this._on);
	}
	registerOnChange(onChange) {
		this._onChange = onChange;
	}
	registerOnTouched(onTouched) {
		this._onTouched = onTouched;
	}
	setDisabledState(disabled) {
		this._disabled = disabled;
	}
	isRippleUnbounded() {
		return true;
	}
	get on() {
		return this._on;
	}
	set on(value) {
		let newValue = asBoolean(value);
		if (newValue !== this._on) {
			this._on = newValue;
			if (this._initialized) this.toggleFoundation.toggle(this._on);
		}
	}
	get labelOn() {
		return this._labelOn;
	}
	set labelOn(value) {
		this._labelOn = value;
		this.refreshToggleData();
	}
	get labelOff() {
		return this._labelOff;
	}
	set labelOff(value) {
		this._labelOff = value;
		this.refreshToggleData();
	}
	get iconOn() {
		return this._iconOn;
	}
	set iconOn(value) {
		if (value !== this._iconOn) {
			if (this.iconIsClass) this.toggleAdapter.removeClass(this._iconOn);
			this._iconOn = value;
			this.refreshToggleData();
		}
	}
	get iconOff() {
		return this._iconOff;
	}
	set iconOff(value) {
		if (value !== this._iconOff) {
			if (this.iconIsClass) this.toggleAdapter.removeClass(this._iconOff);
			this._iconOff = value;
			this.refreshToggleData();
		}
	}
	get iconIsClass() {
		return this._iconIsClass == null ? this._innerIcon != null : this._iconIsClass;
	}
	set iconIsClass(value) {
		let newValue = asBooleanOrNull(value);
		if (this._initialized && this._iconIsClass !== newValue) throw new Error("iconIsClass property should not be changed after the mdcIconButton is initialized");
		this._iconIsClass = newValue;
	}
	_onBlur() {
		this._onTouched();
	}
	get disabled() {
		return this._disabled;
	}
	set disabled(value) {
		this._disabled = asBoolean(value);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcIconButtonToggleDirective,
			deps: [
				{ token: i0.ElementRef },
				{ token: i0.Renderer2 },
				{ token: MdcEventRegistry }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcIconButtonToggleDirective,
			isStandalone: false,
			selector: "[mdcIconButton][iconOn]",
			inputs: {
				on: "on",
				labelOn: "labelOn",
				labelOff: "labelOff",
				iconOn: "iconOn",
				iconOff: "iconOff",
				iconIsClass: "iconIsClass",
				disabled: "disabled"
			},
			outputs: { onChange: "onChange" },
			host: {
				listeners: { "(blur": "_onBlur()" },
				properties: {
					"class.mdc-icon-button": "this._hostClass",
					"class.mdc-icon-button--disabled": "this.disabled"
				}
			},
			providers: [{
				provide: AbstractMdcRipple,
				useExisting: forwardRef(() => MdcIconButtonToggleDirective)
			}, {
				provide: AbstractMdcIcon,
				useExisting: forwardRef(() => MdcIconButtonToggleDirective)
			}],
			queries: [{
				propertyName: "_innerIcon",
				first: true,
				predicate: MdcIconButtonIconDirective,
				descendants: true,
				read: ElementRef
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcIconButtonToggleDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcIconButton][iconOn]",
			providers: [{
				provide: AbstractMdcRipple,
				useExisting: forwardRef(() => MdcIconButtonToggleDirective)
			}, {
				provide: AbstractMdcIcon,
				useExisting: forwardRef(() => MdcIconButtonToggleDirective)
			}]
		}]
	}],
	ctorParameters: () => [
		{ type: i0.ElementRef },
		{ type: i0.Renderer2 },
		{ type: MdcEventRegistry }
	],
	propDecorators: {
		_hostClass: [{
			type: HostBinding,
			args: ["class.mdc-icon-button"]
		}],
		_innerIcon: [{
			type: ContentChild,
			args: [MdcIconButtonIconDirective, { read: ElementRef }]
		}],
		onChange: [{ type: Output }],
		on: [{ type: Input }],
		labelOn: [{ type: Input }],
		labelOff: [{ type: Input }],
		iconOn: [{ type: Input }],
		iconOff: [{ type: Input }],
		iconIsClass: [{ type: Input }],
		_onBlur: [{
			type: HostListener,
			args: ["(blur"]
		}],
		disabled: [{ type: Input }, {
			type: HostBinding,
			args: ["class.mdc-icon-button--disabled"]
		}]
	}
});
var MdcFormsIconButtonDirective = class MdcFormsIconButtonDirective {
	constructor(mdcIconButton) {
		this.mdcIconButton = mdcIconButton;
	}
	writeValue(obj) {
		this.mdcIconButton.writeValue(obj);
	}
	registerOnChange(onChange) {
		this.mdcIconButton.registerOnChange(onChange);
	}
	registerOnTouched(onTouched) {
		this.mdcIconButton.registerOnTouched(onTouched);
	}
	setDisabledState(disabled) {
		this.mdcIconButton.setDisabledState(disabled);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcFormsIconButtonDirective,
			deps: [{
				token: MdcIconButtonToggleDirective,
				self: true
			}],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcFormsIconButtonDirective,
			isStandalone: false,
			selector: "[mdcIconButton][iconOn][formControlName],[mdcIconButton][iconOn][formControl],[mdcIconButton][iconOn][ngModel]",
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => MdcFormsIconButtonDirective),
				multi: true
			}],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcFormsIconButtonDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcIconButton][iconOn][formControlName],[mdcIconButton][iconOn][formControl],[mdcIconButton][iconOn][ngModel]",
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => MdcFormsIconButtonDirective),
				multi: true
			}]
		}]
	}],
	ctorParameters: () => [{
		type: MdcIconButtonToggleDirective,
		decorators: [{ type: Self }]
	}]
});
const ICON_BUTTON_DIRECTIVES = [
	MdcIconButtonIconDirective,
	MdcIconButtonDirective,
	MdcIconButtonToggleDirective,
	MdcFormsIconButtonDirective
];
var MdcIconToggleIconDirective = class MdcIconToggleIconDirective {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcIconToggleIconDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcIconToggleIconDirective,
			isStandalone: false,
			selector: "[mdcIconToggleIcon]",
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcIconToggleIconDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcIconToggleIcon]"
		}]
	}]
});
var MdcIconToggleDirective = class MdcIconToggleDirective extends AbstractMdcIcon {
	constructor(_elm, renderer, registry) {
		super(_elm, renderer, registry);
		this.renderer = renderer;
		this.registry = registry;
		this._hostClass = true;
		this._role = "button";
		this.onChange = new EventEmitter();
		this._onChange = (value) => {};
		this._onTouched = () => {};
		this._beforeInitQueu = [];
		this._initialized = false;
		this.mdcAdapter = {
			addClass: (className) => {
				let inner = this._innerIcon && this._iconIsClass !== false && (className === this._iconOn || className === this._iconOff);
				this.renderer.addClass(inner ? this._innerIcon.nativeElement : this._elm.nativeElement, className);
			},
			removeClass: (className) => {
				let inner = this._innerIcon && this._iconIsClass !== false && (className === this._iconOn || className === this._iconOff);
				this.renderer.removeClass(inner ? this._innerIcon.nativeElement : this._elm.nativeElement, className);
			},
			registerInteractionHandler: (type, handler) => {
				this.registry.listen(this.renderer, type, handler, this._elm);
			},
			deregisterInteractionHandler: (type, handler) => {
				this.registry.unlisten(type, handler);
			},
			setText: (text) => {
				if (this._innerIcon) this._innerIcon.nativeElement.textContent = text;
				else this._elm.nativeElement.textContent = text;
			},
			getTabIndex: () => this._elm.nativeElement.tabIndex,
			setTabIndex: (tabIndex) => {
				this._elm.nativeElement.tabIndex = tabIndex;
			},
			getAttr: (name) => this._elm.nativeElement.getAttribute(name),
			setAttr: (name, value) => {
				this.renderer.setAttribute(this._elm.nativeElement, name, value);
			},
			rmAttr: (name) => {
				this.renderer.removeAttribute(this._elm.nativeElement, name);
			},
			notifyChange: (evtData) => {
				this._onChange(evtData.isOn);
				this.onChange.emit(evtData.isOn);
			}
		};
		this.foundation = new MDCIconToggleFoundation(this.mdcAdapter);
	}
	ngAfterContentInit() {
		this.initDefaultAttributes();
		this.initializeData();
		this.foundation.init();
		for (let fun of this._beforeInitQueu) fun();
		this._beforeInitQueu = [];
		this.foundation.toggle(this.foundation.isOn());
		this.initRipple();
		this._initialized = true;
	}
	ngOnDestroy() {
		this.destroyRipple();
		this.foundation.destroy();
	}
	execAfterInit(fun) {
		if (this._initialized) fun();
		else this._beforeInitQueu.push(fun);
	}
	refreshData() {
		if (this._initialized) {
			this.initializeData();
			this.foundation.refreshToggleData();
			this.foundation.toggle(this.foundation.isOn());
		}
	}
	initDefaultAttributes() {
		if (!this._elm.nativeElement.hasAttribute("tabindex")) this._elm.nativeElement.tabIndex = 0;
	}
	initializeData() {
		let iconIsClass = this.renderIconAsClass;
		this.renderer.setAttribute(this._elm.nativeElement, "data-toggle-on", this.createDataAttrForToggle(this._labelOn, this._iconOn, iconIsClass));
		this.renderer.setAttribute(this._elm.nativeElement, "data-toggle-off", this.createDataAttrForToggle(this._labelOff, this._iconOff, iconIsClass));
	}
	get renderIconAsClass() {
		return this._iconIsClass == null ? this._innerIcon != null : this._iconIsClass;
	}
	createDataAttrForToggle(label, icon, iconIsClass) {
		let data = { label };
		data[iconIsClass ? "cssClass" : "content"] = icon;
		return JSON.stringify(data);
	}
	writeValue(obj) {
		this.execAfterInit(() => this.foundation.toggle(!!obj));
	}
	registerOnChange(onChange) {
		this._onChange = onChange;
	}
	registerOnTouched(onTouched) {
		this._onTouched = onTouched;
	}
	setDisabledState(disabled) {
		this.disabled = disabled;
	}
	isRippleUnbounded() {
		return true;
	}
	isRippleSurfaceActive() {
		return this.foundation.isKeyboardActivated();
	}
	get on() {
		return this.foundation.isOn();
	}
	set on(value) {
		this.execAfterInit(() => this.foundation.toggle(asBoolean(value)));
	}
	get labelOn() {
		return this._labelOn;
	}
	set labelOn(value) {
		this._labelOn = value;
		this.refreshData();
	}
	get labelOff() {
		return this._labelOff;
	}
	set labelOff(value) {
		this._labelOff = value;
		this.refreshData();
	}
	get iconOn() {
		return this._iconOn;
	}
	set iconOn(value) {
		if (value !== this._iconOn) {
			if (this.renderIconAsClass) this.mdcAdapter.removeClass(this._iconOn);
			this._iconOn = value;
			this.refreshData();
		}
	}
	get iconOff() {
		return this._iconOff;
	}
	set iconOff(value) {
		if (value !== this._iconOff) {
			if (this.renderIconAsClass) this.mdcAdapter.removeClass(this._iconOff);
			this._iconOff = value;
			this.refreshData();
		}
	}
	get iconIsClass() {
		return this._iconIsClass;
	}
	set iconIsClass(value) {
		this._iconIsClass = asBooleanOrNull(value);
		this.refreshData();
	}
	get disabled() {
		return this.foundation.isDisabled();
	}
	set disabled(value) {
		this.execAfterInit(() => {
			let newValue = asBoolean(value);
			if (this.foundation.isDisabled() != newValue) this.foundation.setDisabled(asBoolean(value));
		});
	}
	_onBlur() {
		this._onTouched();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcIconToggleDirective,
			deps: [
				{ token: i0.ElementRef },
				{ token: i0.Renderer2 },
				{ token: MdcEventRegistry }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcIconToggleDirective,
			isStandalone: false,
			selector: "[mdcIconToggle]",
			inputs: {
				on: "on",
				labelOn: "labelOn",
				labelOff: "labelOff",
				iconOn: "iconOn",
				iconOff: "iconOff",
				iconIsClass: "iconIsClass",
				disabled: "disabled"
			},
			outputs: { onChange: "onChange" },
			host: {
				listeners: { "(blur": "_onBlur()" },
				properties: {
					"class.mdc-icon-toggle": "this._hostClass",
					"attr.role": "this._role"
				}
			},
			providers: [{
				provide: AbstractMdcIcon,
				useExisting: forwardRef(() => MdcIconToggleDirective)
			}],
			queries: [{
				propertyName: "_innerIcon",
				first: true,
				predicate: MdcIconToggleIconDirective,
				descendants: true,
				read: ElementRef
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcIconToggleDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcIconToggle]",
			providers: [{
				provide: AbstractMdcIcon,
				useExisting: forwardRef(() => MdcIconToggleDirective)
			}]
		}]
	}],
	ctorParameters: () => [
		{ type: i0.ElementRef },
		{ type: i0.Renderer2 },
		{ type: MdcEventRegistry }
	],
	propDecorators: {
		_hostClass: [{
			type: HostBinding,
			args: ["class.mdc-icon-toggle"]
		}],
		_role: [{
			type: HostBinding,
			args: ["attr.role"]
		}],
		_innerIcon: [{
			type: ContentChild,
			args: [MdcIconToggleIconDirective, { read: ElementRef }]
		}],
		onChange: [{ type: Output }],
		on: [{ type: Input }],
		labelOn: [{ type: Input }],
		labelOff: [{ type: Input }],
		iconOn: [{ type: Input }],
		iconOff: [{ type: Input }],
		iconIsClass: [{ type: Input }],
		disabled: [{ type: Input }],
		_onBlur: [{
			type: HostListener,
			args: ["(blur"]
		}]
	}
});
var MdcFormsIconToggleDirective = class MdcFormsIconToggleDirective {
	constructor(mdcIconToggle) {
		this.mdcIconToggle = mdcIconToggle;
	}
	writeValue(obj) {
		this.mdcIconToggle.writeValue(obj);
	}
	registerOnChange(onChange) {
		this.mdcIconToggle.registerOnChange(onChange);
	}
	registerOnTouched(onTouched) {
		this.mdcIconToggle.registerOnTouched(onTouched);
	}
	setDisabledState(disabled) {
		this.mdcIconToggle.setDisabledState(disabled);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcFormsIconToggleDirective,
			deps: [{
				token: MdcIconToggleDirective,
				self: true
			}],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcFormsIconToggleDirective,
			isStandalone: false,
			selector: "[mdcIconToggle][formControlName],[mdcIconToggle][formControl],[mdcIconToggle][ngModel]",
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => MdcFormsIconToggleDirective),
				multi: true
			}],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcFormsIconToggleDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcIconToggle][formControlName],[mdcIconToggle][formControl],[mdcIconToggle][ngModel]",
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => MdcFormsIconToggleDirective),
				multi: true
			}]
		}]
	}],
	ctorParameters: () => [{
		type: MdcIconToggleDirective,
		decorators: [{ type: Self }]
	}]
});
const CLASS_INDETERMINATE = "mdc-linear-progress--indeterminate";
const CLASS_REVERSED = "mdc-linear-progress--reversed";
var MdcLinearProgressDirective = class MdcLinearProgressDirective {
	constructor(_rndr, _root, _registry) {
		this._rndr = _rndr;
		this._root = _root;
		this._registry = _registry;
		this._cls = true;
		this._role = "progressbar";
		this._initialized = false;
		this._indeterminate = false;
		this._reverse = false;
		this._progress = 0;
		this._buffer = 1;
		this._closed = false;
		this.mdcAdapter = {
			addClass: (className) => {
				if (className !== CLASS_INDETERMINATE && className != CLASS_REVERSED) this._rndr.addClass(this._root.nativeElement, className);
			},
			getPrimaryBar: () => this._elmPrimaryBar,
			getBuffer: () => this._elmBuffer,
			hasClass: (className) => {
				if (className === CLASS_INDETERMINATE) return this._indeterminate;
				if (className === CLASS_REVERSED) return this._reverse;
				return this._root.nativeElement.classList.contains(className);
			},
			removeClass: (className) => {
				if (className !== CLASS_INDETERMINATE && className != CLASS_REVERSED) this._rndr.removeClass(this._root.nativeElement, className);
			},
			setStyle: (el, styleProperty, value) => {
				this._rndr.setStyle(el, styleProperty, value);
			}
		};
		this.foundation = new MDCLinearProgressFoundation(this.mdcAdapter);
	}
	ngAfterContentInit() {
		this.initElements();
		this.foundation.init();
		this._initialized = true;
		this.foundation.setProgress(this._progress);
		this.foundation.setBuffer(this._buffer);
		if (this._closed) this.foundation.close();
	}
	ngOnDestroy() {
		this.foundation.destroy();
	}
	initElements() {
		this.addElement(this._root.nativeElement, "div", ["mdc-linear-progress__buffering-dots"]);
		this._elmBuffer = this.addElement(this._root.nativeElement, "div", ["mdc-linear-progress__buffer"]);
		this._elmPrimaryBar = this.addElement(this._root.nativeElement, "div", ["mdc-linear-progress__bar", "mdc-linear-progress__primary-bar"]);
		this.addElement(this._elmPrimaryBar, "span", ["mdc-linear-progress__bar-inner"]);
		this.addElement(this._root.nativeElement, "div", ["mdc-linear-progress__bar", "mdc-linear-progress__secondary-bar"]);
		this.addElement(this._elmPrimaryBar, "span", ["mdc-linear-progress__bar-inner"]);
	}
	addElement(parent, element, classNames) {
		let child = this._rndr.createElement(element);
		classNames.forEach((name) => {
			this._rndr.addClass(child, name);
		});
		this._rndr.appendChild(parent, child);
		return child;
	}
	get indeterminate() {
		return this._indeterminate;
	}
	set indeterminate(value) {
		let newValue = asBoolean(value);
		if (newValue !== this._indeterminate) {
			this._indeterminate = newValue;
			if (this._initialized) {
				this.foundation.setDeterminate(!this._indeterminate);
				if (!this._indeterminate) {
					this.foundation.setProgress(this._progress);
					this.foundation.setBuffer(this._buffer);
				}
			}
		}
	}
	get reversed() {
		return this._reverse;
	}
	set reversed(value) {
		this._reverse = asBoolean(value);
		if (this._initialized) this.foundation.setReverse(this._reverse);
	}
	get progressValue() {
		return this._progress;
	}
	set progressValue(value) {
		this._progress = +value;
		if (this._initialized) this.foundation.setProgress(this._progress);
	}
	get bufferValue() {
		return this._buffer;
	}
	set bufferValue(value) {
		this._buffer = +value;
		if (this._initialized) this.foundation.setBuffer(this._buffer);
	}
	get closed() {
		return this._closed;
	}
	set closed(value) {
		let newValue = asBoolean(value);
		if (newValue !== this._closed) {
			this._closed = newValue;
			if (this._initialized) {
				if (newValue) this.foundation.close();
				else this.foundation.open();
			}
		}
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcLinearProgressDirective,
			deps: [
				{ token: i0.Renderer2 },
				{ token: i0.ElementRef },
				{ token: MdcEventRegistry }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcLinearProgressDirective,
			isStandalone: false,
			selector: "[mdcLinearProgress]",
			inputs: {
				indeterminate: "indeterminate",
				reversed: "reversed",
				progressValue: "progressValue",
				bufferValue: "bufferValue",
				closed: "closed"
			},
			host: { properties: {
				"class.mdc-linear-progress": "this._cls",
				"attr.role": "this._role",
				"class.mdc-linear-progress--indeterminate": "this.indeterminate",
				"class.mdc-linear-progress--reversed": "this.reversed"
			} },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcLinearProgressDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcLinearProgress]"
		}]
	}],
	ctorParameters: () => [
		{ type: i0.Renderer2 },
		{ type: i0.ElementRef },
		{ type: MdcEventRegistry }
	],
	propDecorators: {
		_cls: [{
			type: HostBinding,
			args: ["class.mdc-linear-progress"]
		}],
		_role: [{
			type: HostBinding,
			args: ["attr.role"]
		}],
		_indeterminate: [{
			type: HostBinding,
			args: ["class." + CLASS_INDETERMINATE]
		}],
		_reverse: [{
			type: HostBinding,
			args: ["class." + CLASS_REVERSED]
		}],
		indeterminate: [{ type: Input }, {
			type: HostBinding,
			args: ["class." + CLASS_INDETERMINATE]
		}],
		reversed: [{ type: Input }, {
			type: HostBinding,
			args: ["class." + CLASS_REVERSED]
		}],
		progressValue: [{ type: Input }],
		bufferValue: [{ type: Input }],
		closed: [{ type: Input }]
	}
});
var MdcListDividerDirective = class MdcListDividerDirective {
	constructor(_elm) {
		this._elm = _elm;
		this._cls = true;
		this._role = "separator";
		this._disabled = false;
		this._inset = false;
		this._padded = false;
		if (_elm.nativeElement.nodeName === "OPTION") {
			this._role = "presentation";
			this._disabled = true;
		} else if (_elm.nativeElement.nodeName === "HR") this._role = null;
	}
	get inset() {
		return this._inset;
	}
	set inset(val) {
		this._inset = asBoolean(val);
	}
	get padded() {
		return this._padded;
	}
	set padded(val) {
		this._padded = asBoolean(val);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcListDividerDirective,
			deps: [{ token: i0.ElementRef }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcListDividerDirective,
			isStandalone: false,
			selector: "[mdcListDivider]",
			inputs: {
				inset: "inset",
				padded: "padded"
			},
			host: { properties: {
				"class.mdc-list-divider": "this._cls",
				"attr.role": "this._role",
				"attr.disabled": "this._disabled",
				"class.mdc-list-divider--inset": "this.inset",
				"class.mdc-list-divider--padded": "this.padded"
			} },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcListDividerDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcListDivider]"
		}]
	}],
	ctorParameters: () => [{ type: i0.ElementRef }],
	propDecorators: {
		_cls: [{
			type: HostBinding,
			args: ["class.mdc-list-divider"]
		}],
		_role: [{
			type: HostBinding,
			args: ["attr.role"]
		}],
		_disabled: [{
			type: HostBinding,
			args: ["attr.disabled"]
		}],
		inset: [{ type: Input }, {
			type: HostBinding,
			args: ["class.mdc-list-divider--inset"]
		}],
		padded: [{ type: Input }, {
			type: HostBinding,
			args: ["class.mdc-list-divider--padded"]
		}]
	}
});
var MdcListItemDirective = class MdcListItemDirective extends AbstractMdcRipple {
	constructor(_elm, rndr, registry) {
		super(_elm, rndr, registry);
		this._elm = _elm;
		this._cls = true;
		this._role = null;
		this._initialized = false;
		this._interactive = false;
		this._disabled = false;
		this._selected = false;
		this._activated = false;
	}
	ngAfterContentInit() {
		this._initialized = true;
		if (this._interactive) this.initRipple();
	}
	ngOnDestroy() {
		this.destroyRipple();
	}
	_setInteractive(interactive) {
		if (this._interactive !== interactive) {
			this._interactive = interactive;
			if (this._initialized) {
				if (this._interactive) this.initRipple();
				else this.destroyRipple();
			}
		}
	}
	get disabled() {
		return this._disabled;
	}
	set disabled(val) {
		this._disabled = asBoolean(val);
	}
	get selected() {
		return this._selected;
	}
	set selected(val) {
		this._selected = asBoolean(val);
	}
	get activated() {
		return this._activated;
	}
	set activated(val) {
		this._activated = asBoolean(val);
	}
	get _tabIndex() {
		if (this._role === "menuitem" || this._role === "option") return this._disabled ? -1 : 0;
		return null;
	}
	get _ariaDisabled() {
		if (this._disabled) return "true";
		return null;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcListItemDirective,
			deps: [
				{ token: i0.ElementRef },
				{ token: i0.Renderer2 },
				{ token: MdcEventRegistry }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcListItemDirective,
			isStandalone: false,
			selector: "[mdcListItem]",
			inputs: {
				value: "value",
				disabled: "disabled",
				selected: "selected",
				activated: "activated"
			},
			host: { properties: {
				"class.mdc-list-item": "this._cls",
				"attr.role": "this._role",
				"class.mdc-list-item--selected": "this.selected",
				"class.mdc-list-item--activated": "this.activated",
				"attr.tabindex": "this._tabIndex",
				"attr.aria-disabled": "this._ariaDisabled"
			} },
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcListItemDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcListItem]"
		}]
	}],
	ctorParameters: () => [
		{ type: i0.ElementRef },
		{ type: i0.Renderer2 },
		{ type: MdcEventRegistry }
	],
	propDecorators: {
		_cls: [{
			type: HostBinding,
			args: ["class.mdc-list-item"]
		}],
		_role: [{
			type: HostBinding,
			args: ["attr.role"]
		}],
		value: [{ type: Input }],
		disabled: [{ type: Input }],
		selected: [{ type: Input }, {
			type: HostBinding,
			args: ["class.mdc-list-item--selected"]
		}],
		activated: [{ type: Input }, {
			type: HostBinding,
			args: ["class.mdc-list-item--activated"]
		}],
		_tabIndex: [{
			type: HostBinding,
			args: ["attr.tabindex"]
		}],
		_ariaDisabled: [{
			type: HostBinding,
			args: ["attr.aria-disabled"]
		}]
	}
});
var MdcListItemTextDirective = class MdcListItemTextDirective {
	constructor() {
		this._cls = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcListItemTextDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcListItemTextDirective,
			isStandalone: false,
			selector: "[mdcListItemText]",
			host: { properties: { "class.mdc-list-item__text": "this._cls" } },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcListItemTextDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcListItemText]"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { _cls: [{
		type: HostBinding,
		args: ["class.mdc-list-item__text"]
	}] }
});
var MdcListItemSecondaryTextDirective = class MdcListItemSecondaryTextDirective {
	constructor() {
		this._cls = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcListItemSecondaryTextDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcListItemSecondaryTextDirective,
			isStandalone: false,
			selector: "[mdcListItemSecondaryText]",
			host: { properties: { "class.mdc-list-item__secondary-text": "this._cls" } },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcListItemSecondaryTextDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcListItemSecondaryText]"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { _cls: [{
		type: HostBinding,
		args: ["class.mdc-list-item__secondary-text"]
	}] }
});
var MdcListItemGraphicDirective = class MdcListItemGraphicDirective {
	constructor() {
		this._cls = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcListItemGraphicDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcListItemGraphicDirective,
			isStandalone: false,
			selector: "[mdcListItemGraphic]",
			host: { properties: { "class.mdc-list-item__graphic": "this._cls" } },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcListItemGraphicDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcListItemGraphic]"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { _cls: [{
		type: HostBinding,
		args: ["class.mdc-list-item__graphic"]
	}] }
});
var MdcListItemMetaDirective = class MdcListItemMetaDirective {
	constructor() {
		this._cls = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcListItemMetaDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcListItemMetaDirective,
			isStandalone: false,
			selector: "[mdcListItemMeta]",
			host: { properties: { "class.mdc-list-item__meta": "this._cls" } },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcListItemMetaDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcListItemMeta]"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { _cls: [{
		type: HostBinding,
		args: ["class.mdc-list-item__meta"]
	}] }
});
var MdcListFunction;
(function(MdcListFunction) {
	MdcListFunction[MdcListFunction["plain"] = 0] = "plain";
	MdcListFunction[MdcListFunction["menu"] = 1] = "menu";
})(MdcListFunction || (MdcListFunction = {}));
var MdcListDirective = class MdcListDirective {
	constructor(_elm) {
		this._elm = _elm;
		this._cls = true;
		this._twoLine = false;
		this._function = MdcListFunction.plain;
		this._hidden = false;
		this._dense = false;
		this._avatar = false;
		this._nonInteractive = false;
	}
	ngAfterContentInit() {
		this.updateItems();
		this._items.changes.subscribe(() => {
			this.updateItems();
		});
		this._texts.changes.subscribe((_) => this._twoLine = this._texts.length > 0);
		this._twoLine = this._texts.length > 0;
	}
	updateItems() {
		let itemRole = null;
		if (this._function === MdcListFunction.menu) itemRole = "menuitem";
		this._items.forEach((item) => {
			item._role = itemRole;
			item._setInteractive(!this._nonInteractive);
		});
	}
	get _role() {
		return this._function === MdcListFunction.menu ? "menu" : null;
	}
	get _ariaHidden() {
		return this._hidden && this._function === MdcListFunction.menu ? "true" : null;
	}
	get _isMenu() {
		return this._function === MdcListFunction.menu;
	}
	_setFunction(val) {
		this._function = val;
		this.updateItems();
	}
	get dense() {
		return this._dense;
	}
	set dense(val) {
		this._dense = asBoolean(val);
	}
	get nonInteractive() {
		return this._nonInteractive;
	}
	set nonInteractive(val) {
		let newValue = asBoolean(val);
		if (newValue !== this._nonInteractive) {
			this._nonInteractive = newValue;
			this.updateItems();
		}
	}
	get avatarList() {
		return this._avatar;
	}
	set avatarList(val) {
		this._avatar = asBoolean(val);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcListDirective,
			deps: [{ token: i0.ElementRef }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcListDirective,
			isStandalone: false,
			selector: "[mdcList]",
			inputs: {
				dense: "dense",
				nonInteractive: "nonInteractive",
				avatarList: "avatarList"
			},
			host: { properties: {
				"class.mdc-list": "this._cls",
				"class.mdc-list--two-line": "this._twoLine",
				"attr.role": "this._role",
				"attr.aria-hidden": "this._ariaHidden",
				"class.mdc-menu__items": "this._isMenu",
				"class.mdc-list--dense": "this.dense",
				"class.mdc-list--non-interactive": "this.nonInteractive",
				"class.mdc-list--avatar-list": "this.avatarList"
			} },
			queries: [{
				propertyName: "_items",
				predicate: MdcListItemDirective
			}, {
				propertyName: "_texts",
				predicate: MdcListItemTextDirective,
				descendants: true
			}],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcListDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcList]"
		}]
	}],
	ctorParameters: () => [{ type: i0.ElementRef }],
	propDecorators: {
		_cls: [{
			type: HostBinding,
			args: ["class.mdc-list"]
		}],
		_items: [{
			type: ContentChildren,
			args: [MdcListItemDirective]
		}],
		_texts: [{
			type: ContentChildren,
			args: [MdcListItemTextDirective, { descendants: true }]
		}],
		_twoLine: [{
			type: HostBinding,
			args: ["class.mdc-list--two-line"]
		}],
		_role: [{
			type: HostBinding,
			args: ["attr.role"]
		}],
		_ariaHidden: [{
			type: HostBinding,
			args: ["attr.aria-hidden"]
		}],
		_isMenu: [{
			type: HostBinding,
			args: ["class.mdc-menu__items"]
		}],
		dense: [{ type: Input }, {
			type: HostBinding,
			args: ["class.mdc-list--dense"]
		}],
		nonInteractive: [{ type: Input }, {
			type: HostBinding,
			args: ["class.mdc-list--non-interactive"]
		}],
		avatarList: [{ type: Input }, {
			type: HostBinding,
			args: ["class.mdc-list--avatar-list"]
		}]
	}
});
var MdcListGroupSubHeaderDirective = class MdcListGroupSubHeaderDirective {
	constructor() {
		this._cls = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcListGroupSubHeaderDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcListGroupSubHeaderDirective,
			isStandalone: false,
			selector: "[mdcListGroupSubHeader]",
			host: { properties: { "class.mdc-list-group__subheader": "this._cls" } },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcListGroupSubHeaderDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcListGroupSubHeader]"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { _cls: [{
		type: HostBinding,
		args: ["class.mdc-list-group__subheader"]
	}] }
});
var MdcListGroupDirective = class MdcListGroupDirective {
	constructor() {
		this._cls = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcListGroupDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcListGroupDirective,
			isStandalone: false,
			selector: "[mdcListGroup]",
			host: { properties: { "class.mdc-list-group": "this._cls" } },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcListGroupDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcListGroup]"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { _cls: [{
		type: HostBinding,
		args: ["class.mdc-list-group"]
	}] }
});
const CLASS_MENU = "mdc-menu";
const CLASS_MENU_OPEN = "mdc-menu--open";
const CLASS_TOP_LEFT = "mdc-menu--open-from-top-left";
const CLASS_TOP_RIGHT = "mdc-menu--open-from-top-right";
const CLASS_BOTTOM_LEFT = "mdc-menu--open-from-bottom-left";
const CLASS_BOTTOM_RIGHT = "mdc-menu--open-from-bottom-right";
var MdcMenuAnchorDirective = class MdcMenuAnchorDirective {
	constructor(_elm) {
		this._elm = _elm;
		this._cls = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcMenuAnchorDirective,
			deps: [{ token: i0.ElementRef }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcMenuAnchorDirective,
			isStandalone: false,
			selector: "[mdcMenuAnchor]",
			host: { properties: { "class.mdc-menu-anchor": "this._cls" } },
			exportAs: ["mdcMenuAnchor"],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcMenuAnchorDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcMenuAnchor]",
			exportAs: "mdcMenuAnchor"
		}]
	}],
	ctorParameters: () => [{ type: i0.ElementRef }],
	propDecorators: { _cls: [{
		type: HostBinding,
		args: ["class.mdc-menu-anchor"]
	}] }
});
var MdcMenuDirective = class MdcMenuDirective {
	constructor(_elm, _rndr, _registry) {
		this._elm = _elm;
		this._rndr = _rndr;
		this._registry = _registry;
		this._cls = true;
		this._function = MdcListFunction.menu;
		this._openMemory = false;
		this._openFrom = null;
		this.pick = new EventEmitter();
		this.cancel = new EventEmitter();
		this.openChange = new EventEmitter();
		this.mdcAdapter = {
			addClass: (className) => {
				this._rndr.addClass(this._elm.nativeElement, className);
			},
			removeClass: (className) => {
				this._rndr.removeClass(this._elm.nativeElement, className);
			},
			hasClass: (className) => {
				if (CLASS_MENU === className) return true;
				if (CLASS_MENU_OPEN === className) return this.open;
				if (CLASS_TOP_LEFT === className) return this._openFrom === "tl";
				if (CLASS_TOP_RIGHT === className) return this._openFrom === "tr";
				if (CLASS_BOTTOM_LEFT === className) return this._openFrom === "bl";
				if (CLASS_BOTTOM_RIGHT === className) return this._openFrom === "br";
				return this._elm.nativeElement.classList.contains(className);
			},
			hasNecessaryDom: () => this._listQuery.length != 0,
			getAttributeForEventTarget: (target, attrName) => target.getAttribute(attrName),
			getInnerDimensions: () => {
				let elm = this._list._elm.nativeElement;
				return {
					width: elm.offsetWidth,
					height: elm.offsetHeight
				};
			},
			hasAnchor: () => this.menuAnchor != null,
			getAnchorDimensions: () => {
				if (!this.viewport) return this.menuAnchor._elm.nativeElement.getBoundingClientRect();
				let viewportRect = this.viewport.getBoundingClientRect();
				let anchorRect = this.menuAnchor._elm.nativeElement.getBoundingClientRect();
				return {
					bottom: anchorRect.bottom - viewportRect.top,
					left: anchorRect.left - viewportRect.left,
					right: anchorRect.right - viewportRect.left,
					top: anchorRect.top - viewportRect.top,
					width: anchorRect.width,
					height: anchorRect.height
				};
			},
			getWindowDimensions: () => ({
				width: this.viewport ? this.viewport.clientWidth : window.innerWidth,
				height: this.viewport ? this.viewport.clientHeight : window.innerHeight
			}),
			getNumberOfItems: () => this._list._items.length,
			registerInteractionHandler: (type, handler) => {
				this._registry.listen(this._rndr, type, handler, this._elm);
			},
			deregisterInteractionHandler: (type, handler) => {
				this._registry.unlisten(type, handler);
			},
			registerBodyClickHandler: (handler) => {
				this._registry.listenElm(this._rndr, "click", handler, document.body);
			},
			deregisterBodyClickHandler: (handler) => {
				this._registry.unlisten("click", handler);
			},
			getIndexForEventTarget: (target) => this._list._items.toArray().map((i) => i._elm.nativeElement).indexOf(target),
			notifySelected: (evtData) => {
				this.pick.emit({
					index: evtData.index,
					value: this._list._items.toArray()[evtData.index].value
				});
				window.setTimeout(() => this._onOpenClose(), 0);
			},
			notifyCancel: () => {
				this.cancel.emit();
				window.setTimeout(() => this._onOpenClose(), 0);
			},
			saveFocus: () => {
				this._prevFocus = document.activeElement;
			},
			restoreFocus: () => {
				if (this._prevFocus) this._prevFocus.focus();
			},
			isFocused: () => document.activeElement === this._elm.nativeElement,
			focus: () => {
				this._elm.nativeElement.focus();
			},
			getFocusedItemIndex: () => this._list._items.toArray().map((i) => i._elm.nativeElement).indexOf(document.activeElement),
			focusItemAtIndex: (index) => {
				this._list._items.toArray()[index]._elm.nativeElement.focus();
			},
			isRtl: () => getComputedStyle(this._elm.nativeElement).getPropertyValue("direction") === "rtl",
			setTransformOrigin: (origin) => {
				this._elm.nativeElement.style[`${getTransformPropertyName(window)}-origin`] = origin;
			},
			setPosition: (position) => {
				let el = this._elm.nativeElement;
				this._rndr.setStyle(el, "left", "left" in position ? position.left : null);
				this._rndr.setStyle(el, "right", "right" in position ? position.right : null);
				this._rndr.setStyle(el, "top", "top" in position ? position.top : null);
				this._rndr.setStyle(el, "bottom", "bottom" in position ? position.bottom : null);
			},
			setMaxHeight: (value) => {
				this._elm.nativeElement.style.maxHeight = value;
			}
		};
		this.foundation = new MDCMenuFoundation(this.mdcAdapter);
	}
	ngAfterContentInit() {
		this._lastList = this._listQuery.first;
		if (this._lastList) {
			this._lastList._setFunction(MdcListFunction.menu);
			this._onOpenClose(false);
		}
		this._listQuery.changes.subscribe(() => {
			if (this._lastList !== this._listQuery.first) {
				this._lastList._setFunction(MdcListFunction.plain);
				this._lastList = this._listQuery.first;
				if (this._lastList) {
					this._lastList._setFunction(MdcListFunction.menu);
					this._onOpenClose(false);
					if (this._component == null) {
						this._component = new MDCMenu(this._elm.nativeElement, this.foundation);
						this._component.open = this._openMemory;
					}
				} else if (this._component) {
					this._openMemory = this._component.open;
					this._component.destroy();
					this._component = null;
					this.foundation = new MDCMenuFoundation(this.mdcAdapter);
				}
			}
		});
		if (this._lastList) this._component = new MDCMenu(this._elm.nativeElement, this.foundation);
	}
	ngOnDestroy() {
		if (this._component) this._component.destroy();
	}
	_onOpenClose(emit = true) {
		if (this._list) this._list._hidden = !this.open;
		if (emit) this.openChange.emit(this.open);
	}
	set _listFunction(val) {
		this._function = val;
		if (this._lastList) this._list._setFunction(val);
	}
	get _list() {
		return this._listQuery.first;
	}
	get open() {
		return this._component ? this.foundation.isOpen() : this._openMemory;
	}
	set open(val) {
		let newValue = asBoolean(val);
		if (newValue !== this.open) {
			this._openMemory = newValue;
			if (this._component != null) {
				if (newValue) this.foundation.open();
				else this.foundation.close();
			}
			this._onOpenClose(false);
		}
	}
	get openFrom() {
		return this._openFrom;
	}
	set openFrom(val) {
		if (val === "br" || val === "bl" || val === "tr" || val === "tl") this._openFrom = val;
		else this._openFrom = null;
	}
	get _tl() {
		return this._openFrom === "tl";
	}
	get _tr() {
		return this._openFrom === "tr";
	}
	get _bl() {
		return this._openFrom === "bl";
	}
	get _br() {
		return this._openFrom === "br";
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcMenuDirective,
			deps: [
				{ token: i0.ElementRef },
				{ token: i0.Renderer2 },
				{ token: MdcEventRegistry }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcMenuDirective,
			isStandalone: false,
			selector: "[mdcMenu]",
			inputs: {
				menuAnchor: "menuAnchor",
				open: "open",
				openFrom: "openFrom",
				viewport: "viewport"
			},
			outputs: {
				pick: "pick",
				cancel: "cancel",
				openChange: "openChange"
			},
			host: { properties: {
				"class.mdc-menu": "this._cls",
				"class.mdc-menu--open": "this.open",
				"class.mdc-menu--open-from-top-left": "this._tl",
				"class.mdc-menu--open-from-top-right": "this._tr",
				"class.mdc-menu--open-from-bottom-left": "this._bl",
				"class.mdc-menu--open-from-bottom-right": "this._br"
			} },
			queries: [{
				propertyName: "_listQuery",
				predicate: MdcListDirective
			}],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcMenuDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcMenu]"
		}]
	}],
	ctorParameters: () => [
		{ type: i0.ElementRef },
		{ type: i0.Renderer2 },
		{ type: MdcEventRegistry }
	],
	propDecorators: {
		_cls: [{
			type: HostBinding,
			args: ["class.mdc-menu"]
		}],
		menuAnchor: [{ type: Input }],
		pick: [{ type: Output }],
		cancel: [{ type: Output }],
		openChange: [{ type: Output }],
		_listQuery: [{
			type: ContentChildren,
			args: [MdcListDirective]
		}],
		open: [{ type: Input }, {
			type: HostBinding,
			args: ["class.mdc-menu--open"]
		}],
		openFrom: [{ type: Input }],
		_tl: [{
			type: HostBinding,
			args: ["class.mdc-menu--open-from-top-left"]
		}],
		_tr: [{
			type: HostBinding,
			args: ["class.mdc-menu--open-from-top-right"]
		}],
		_bl: [{
			type: HostBinding,
			args: ["class.mdc-menu--open-from-bottom-left"]
		}],
		_br: [{
			type: HostBinding,
			args: ["class.mdc-menu--open-from-bottom-right"]
		}],
		viewport: [{ type: Input }]
	}
});
var MdcRadioInputDirective = class MdcRadioInputDirective extends AbstractMdcInput {
	constructor(_elm, _cntr) {
		super();
		this._elm = _elm;
		this._cntr = _cntr;
		this._cls = true;
		this._disabled = false;
	}
	get id() {
		return this._id;
	}
	set id(value) {
		this._id = value;
	}
	get disabled() {
		return this._cntr ? this._cntr.disabled : this._disabled;
	}
	set disabled(value) {
		this._disabled = asBoolean(value);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcRadioInputDirective,
			deps: [{ token: i0.ElementRef }, {
				token: i1.NgControl,
				optional: true,
				self: true
			}],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcRadioInputDirective,
			isStandalone: false,
			selector: "input[mdcRadioInput][type=radio]",
			inputs: {
				id: "id",
				disabled: "disabled"
			},
			host: { properties: {
				"class.mdc-radio__native-control": "this._cls",
				"id": "this.id",
				"disabled": "this.disabled"
			} },
			providers: [{
				provide: AbstractMdcInput,
				useExisting: forwardRef(() => MdcRadioInputDirective)
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcRadioInputDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "input[mdcRadioInput][type=radio]",
			providers: [{
				provide: AbstractMdcInput,
				useExisting: forwardRef(() => MdcRadioInputDirective)
			}]
		}]
	}],
	ctorParameters: () => [{ type: i0.ElementRef }, {
		type: i1.NgControl,
		decorators: [{ type: Optional }, { type: Self }]
	}],
	propDecorators: {
		_cls: [{
			type: HostBinding,
			args: ["class.mdc-radio__native-control"]
		}],
		id: [{ type: HostBinding }, { type: Input }],
		disabled: [{ type: HostBinding }, { type: Input }]
	}
});
var MdcRadioDirective = class MdcRadioDirective extends AbstractMdcRipple {
	constructor(renderer, root, registry) {
		super(root, renderer, registry);
		this.renderer = renderer;
		this.root = root;
		this.registry = registry;
		this._cls = true;
		this.mdcAdapter = {
			addClass: (className) => {
				this.renderer.addClass(this.root.nativeElement, className);
			},
			removeClass: (className) => {
				this.renderer.removeClass(this.root.nativeElement, className);
			},
			getNativeControl: () => this._input ? this._input._elm.nativeElement : null
		};
		this.foundation = new MDCRadioFoundation(this.mdcAdapter);
	}
	ngAfterContentInit() {
		this.addBackground();
		this.initRipple();
		this.foundation.init();
	}
	ngOnDestroy() {
		this.destroyRipple();
		this.foundation.destroy();
	}
	addBackground() {
		let outerCircle = this.renderer.createElement("div");
		this.renderer.addClass(outerCircle, "mdc-radio__outer-circle");
		let innerCircle = this.renderer.createElement("div");
		this.renderer.addClass(innerCircle, "mdc-radio__inner-circle");
		let bg = this.renderer.createElement("div");
		this.renderer.appendChild(bg, outerCircle);
		this.renderer.appendChild(bg, innerCircle);
		this.renderer.addClass(bg, "mdc-radio__background");
		this.renderer.appendChild(this.root.nativeElement, bg);
	}
	getRippleInteractionElement() {
		return this._input ? this._input._elm : null;
	}
	isRippleUnbounded() {
		return true;
	}
	isRippleSurfaceActive() {
		return false;
	}
	get _disabled() {
		return this._input == null || this._input.disabled;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcRadioDirective,
			deps: [
				{ token: i0.Renderer2 },
				{ token: i0.ElementRef },
				{ token: MdcEventRegistry }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcRadioDirective,
			isStandalone: false,
			selector: "[mdcRadio]",
			host: { properties: {
				"class.mdc-radio": "this._cls",
				"class.mdc-radio--disabled": "this._disabled"
			} },
			queries: [{
				propertyName: "_input",
				first: true,
				predicate: MdcRadioInputDirective,
				descendants: true
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcRadioDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcRadio]"
		}]
	}],
	ctorParameters: () => [
		{ type: i0.Renderer2 },
		{ type: i0.ElementRef },
		{ type: MdcEventRegistry }
	],
	propDecorators: {
		_cls: [{
			type: HostBinding,
			args: ["class.mdc-radio"]
		}],
		_input: [{
			type: ContentChild,
			args: [MdcRadioInputDirective]
		}],
		_disabled: [{
			type: HostBinding,
			args: ["class.mdc-radio--disabled"]
		}]
	}
});
var MdcRippleDirective = class MdcRippleDirective extends AbstractMdcRipple {
	constructor(elm, renderer, registry) {
		super(elm, renderer, registry);
		this.elm = elm;
		this.renderer = renderer;
		this.registry = registry;
		this._initialized = false;
		this._on = false;
		this._disabled = null;
		this._unbounded = false;
		this._surface = false;
		this._dim = null;
	}
	ngAfterContentInit() {
		if (this._on) this.initRipple();
		this._initialized = true;
	}
	ngOnDestroy() {
		this.destroyRipple();
	}
	isRippleUnbounded() {
		return this._unbounded;
	}
	isRippleSurfaceDisabled() {
		return this._disabled == null ? super.isRippleSurfaceDisabled() : this._disabled;
	}
	computeRippleBoundingRect() {
		if (this._dim == null) return super.computeRippleBoundingRect();
		const { left, top } = this.elm.nativeElement.getBoundingClientRect();
		return {
			left,
			top,
			width: this._dim,
			height: this._dim,
			right: left + this._dim,
			bottom: left + this._dim
		};
	}
	get mdcRipple() {
		return !this._on;
	}
	set mdcRipple(value) {
		let newValue = asBoolean(value);
		if (newValue !== this._on) {
			this._on = newValue;
			if (this._initialized) {
				if (newValue) this.initRipple();
				else this.destroyRipple();
			}
		}
	}
	get unbounded() {
		return this._unbounded;
	}
	set unbounded(value) {
		let newValue = asBoolean(value);
		if (newValue !== this._unbounded) {
			this._unbounded = newValue;
			this.reInit();
		}
	}
	get _attrUnbounded() {
		return this._unbounded ? "" : null;
	}
	get dimension() {
		return this._dim;
	}
	set dimension(value) {
		this._dim = value == null ? null : +value;
		this.layout();
	}
	get disabled() {
		return this._disabled;
	}
	set disabled(value) {
		this._disabled = asBooleanOrNull(value);
	}
	get surface() {
		return this._surface;
	}
	set surface(value) {
		this._surface = asBoolean(value);
	}
	reInit() {
		if (this._initialized && this.isRippleInitialized()) {
			this.destroyRipple();
			this.initRipple();
		}
	}
	layout() {
		if (this._initialized && this.isRippleInitialized()) this._rippleFoundation.layout();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcRippleDirective,
			deps: [
				{ token: i0.ElementRef },
				{ token: i0.Renderer2 },
				{ token: MdcEventRegistry }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcRippleDirective,
			isStandalone: false,
			selector: "[mdcRipple]",
			inputs: {
				mdcRipple: "mdcRipple",
				unbounded: "unbounded",
				dimension: "dimension",
				disabled: "disabled",
				surface: "surface"
			},
			host: { properties: {
				"attr.data-mdc-ripple-is-unbounded": "this._attrUnbounded",
				"class.mdc-ripple-surface": "this.surface"
			} },
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcRippleDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcRipple]"
		}]
	}],
	ctorParameters: () => [
		{ type: i0.ElementRef },
		{ type: i0.Renderer2 },
		{ type: MdcEventRegistry }
	],
	propDecorators: {
		mdcRipple: [{ type: Input }],
		unbounded: [{ type: Input }],
		_attrUnbounded: [{
			type: HostBinding,
			args: ["attr.data-mdc-ripple-is-unbounded"]
		}],
		dimension: [{ type: Input }],
		disabled: [{ type: Input }],
		surface: [{ type: Input }, {
			type: HostBinding,
			args: ["class.mdc-ripple-surface"]
		}]
	}
});
var NotchedOutlineSupport = class {
	constructor(_elm, _rndr) {
		this._elm = _elm;
		this._rndr = _rndr;
		this._initialized = false;
		this._adapter = {
			getWidth: () => this._outline.offsetWidth,
			getHeight: () => this._outline.offsetHeight,
			addClass: (className) => this._rndr.addClass(this._outline, className),
			removeClass: (className) => this._rndr.removeClass(this._outline, className),
			setOutlinePathAttr: (value) => this._rndr.setAttribute(this.path, "d", value),
			getIdleOutlineStyleValue: (propertyName) => window.getComputedStyle(this._outlineIdle).getPropertyValue(propertyName)
		};
	}
	get foundation() {
		return this._foundation;
	}
	init() {
		if (this._foundation == null) {
			let path = this._rndr.createElement("path", "svg");
			this._rndr.addClass(path, "mdc-notched-outline__path");
			let svg = this._rndr.createElement("svg", "svg");
			this._rndr.appendChild(svg, path);
			this._rndr.appendChild(this._elm.nativeElement, svg);
			let outline = this._rndr.createElement("div");
			this._rndr.addClass(outline, "mdc-notched-outline");
			this._rndr.appendChild(outline, svg);
			let outlineIdle = this._rndr.createElement("div");
			this._rndr.addClass(outlineIdle, "mdc-notched-outline__idle");
			this._rndr.appendChild(this._elm.nativeElement, outline);
			this._rndr.appendChild(this._elm.nativeElement, outlineIdle);
			this._outline = outline;
			this._outlineIdle = outlineIdle;
			this.path = path;
			this._foundation = new MDCNotchedOutlineFoundation(this._adapter);
			this._foundation.init();
		}
	}
	destroy() {
		if (this._foundation != null) try {
			this._foundation.destroy();
			this._rndr.removeChild(this._elm.nativeElement, this._outlineIdle);
			this._rndr.removeChild(this._elm.nativeElement, this._outline);
		} finally {
			this._outline = null;
			this._outlineIdle = null;
			this.path = null;
			this._foundation = null;
		}
	}
};
const CLASS_LINE_RIPPLE$1 = "mdc-line-ripple";
let nextId$1 = 1;
var MdcSelectControlDirective = class MdcSelectControlDirective extends AbstractMdcInput {
	constructor(_elm, renderer, _registry, _cntr) {
		super();
		this._elm = _elm;
		this.renderer = renderer;
		this._registry = _registry;
		this._cntr = _cntr;
		this._cls = true;
		this._onChange = (value) => {};
		this._disabled = false;
	}
	ngOnInit() {
		this.id = this.id;
		if (this._cntr) this._cntr.valueChanges.subscribe((value) => {
			this._onChange(this._elm.nativeElement.selectedIndex);
		});
	}
	ngOnDestroy() {}
	get id() {
		return this._id;
	}
	set id(value) {
		this._id = value || this._newId();
	}
	get disabled() {
		return this._cntr ? this._cntr.disabled : this._disabled;
	}
	set disabled(value) {
		this._disabled = asBoolean(value);
	}
	_newId() {
		this.cachedId = this.cachedId || `mdc-select-${nextId$1++}`;
		return this.cachedId;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcSelectControlDirective,
			deps: [
				{ token: i0.ElementRef },
				{ token: i0.Renderer2 },
				{ token: MdcEventRegistry },
				{
					token: i1.NgControl,
					optional: true,
					self: true
				}
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcSelectControlDirective,
			isStandalone: false,
			selector: "select[mdcSelectControl]",
			inputs: {
				id: "id",
				disabled: "disabled"
			},
			host: { properties: {
				"class.mdc-select__native-control": "this._cls",
				"id": "this.id",
				"disabled": "this.disabled"
			} },
			providers: [{
				provide: AbstractMdcInput,
				useExisting: forwardRef(() => MdcSelectControlDirective)
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcSelectControlDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "select[mdcSelectControl]",
			providers: [{
				provide: AbstractMdcInput,
				useExisting: forwardRef(() => MdcSelectControlDirective)
			}]
		}]
	}],
	ctorParameters: () => [
		{ type: i0.ElementRef },
		{ type: i0.Renderer2 },
		{ type: MdcEventRegistry },
		{
			type: i1.NgControl,
			decorators: [{ type: Optional }, { type: Self }]
		}
	],
	propDecorators: {
		_cls: [{
			type: HostBinding,
			args: ["class.mdc-select__native-control"]
		}],
		id: [{ type: HostBinding }, { type: Input }],
		disabled: [{ type: HostBinding }, { type: Input }]
	}
});
var MdcSelectDirective = class MdcSelectDirective extends AbstractMdcRipple {
	constructor(_elm, _rndr, _registry) {
		super(_elm, _rndr, _registry);
		this._elm = _elm;
		this._rndr = _rndr;
		this._cls = true;
		this._initialized = false;
		this._box = false;
		this._outlined = false;
		this._bottomLineElm = null;
		this._lineRippleAdapter = {
			addClass: (className) => this._rndr.addClass(this._bottomLineElm, className),
			removeClass: (className) => this._rndr.removeClass(this._bottomLineElm, className),
			hasClass: (className) => this._bottomLineElm.classList.contains(className),
			setStyle: (name, value) => this._rndr.setStyle(this._bottomLineElm, name, value),
			registerEventHandler: (evtType, handler) => this._registry.listenElm(this._rndr, evtType, handler, this._bottomLineElm),
			deregisterEventHandler: (evtType, handler) => this._registry.unlisten(evtType, handler)
		};
		this._lineRippleFoundation = new MDCLineRippleFoundation(this._lineRippleAdapter);
		this.adapter = {
			addClass: (className) => this._rndr.addClass(this._elm.nativeElement, className),
			removeClass: (className) => this._rndr.removeClass(this._elm.nativeElement, className),
			floatLabel: (value) => {
				if (this._label) this._label._foundation.float(value);
			},
			activateBottomLine: () => this._lineRippleFoundation.activate(),
			deactivateBottomLine: () => this._lineRippleFoundation.deactivate(),
			registerInteractionHandler: (type, handler) => this._control._registry.listen(this._rndr, type, handler, this._control._elm),
			deregisterInteractionHandler: (type, handler) => this._control._registry.unlisten(type, handler),
			getSelectedIndex: () => this._control._elm.nativeElement.selectedIndex,
			setSelectedIndex: (index) => this._control._elm.nativeElement.selectedIndex = index,
			setDisabled: (disabled) => this._control._elm.nativeElement.disabled = disabled,
			getValue: () => this._control._elm.nativeElement.value,
			setValue: (value) => this._control._elm.nativeElement.value = value,
			isRtl: () => getComputedStyle(this._elm.nativeElement).getPropertyValue("direction") === "rtl",
			hasLabel: () => !!this._label,
			getLabelWidth: () => this._label._foundation.getWidth(),
			hasOutline: () => this._outlined,
			notchOutline: (labelWidth, isRtl) => this._outlineSupport.foundation.notch(labelWidth, isRtl),
			closeOutline: () => this._outlineSupport.foundation.closeNotch()
		};
		this._outlineSupport = new NotchedOutlineSupport(_elm, _rndr);
	}
	ngAfterContentInit() {
		if (!this._control || !this._label) throw new Error("mdcSelect requires an embedded mdcSelectControl and mdcFloatingLabel");
		if (!this._label._initialized) throw new Error("mdcFloatingLabel not properly initialized");
		this._initialized = true;
		this.initComponent();
		if (this._control) this._control._onChange = (value) => this.foundation.setSelectedIndex(value);
	}
	ngOnDestroy() {
		this.destroyLineRipple();
		this.foundation.destroy();
		this._control._onChange = (value) => {};
	}
	initComponent() {
		this.initLineRipple();
		this.initBox();
		this.initOutline();
		this.foundation = new MDCSelectFoundation(this.adapter);
		this.foundation.init();
	}
	destroyComponent() {
		this.destroyLineRipple();
		this.destroyBox();
		this.destroyOutline();
		this.foundation.destroy();
	}
	reconstructComponent() {
		if (this._initialized) {
			this.destroyComponent();
			this.initComponent();
			this.recomputeOutline();
		}
	}
	initLineRipple() {
		if (!this._outlined) {
			this._bottomLineElm = this._rndr.createElement("div");
			this._rndr.addClass(this._bottomLineElm, CLASS_LINE_RIPPLE$1);
			this._rndr.appendChild(this._elm.nativeElement, this._bottomLineElm);
			this._lineRippleFoundation.init();
		}
	}
	destroyLineRipple() {
		if (this._bottomLineElm) {
			this._lineRippleFoundation.destroy();
			this._rndr.removeChild(this._elm.nativeElement, this._bottomLineElm);
			this._bottomLineElm = null;
		}
	}
	initBox() {
		if (this._box) this.initRipple();
	}
	destroyBox() {
		this.destroyRipple();
	}
	initOutline() {
		if (this._outlined) this._outlineSupport.init();
	}
	destroyOutline() {
		this._outlineSupport.destroy();
	}
	recomputeOutline() {
		if (this._outlined) {
			let inputValue = this._control._elm.nativeElement.value;
			let shouldFloat = inputValue != null && inputValue.length > 0;
			setTimeout(() => {
				this.foundation.notchOutline(shouldFloat);
			}, 0);
		}
	}
	get box() {
		return this._box;
	}
	set box(val) {
		if (asBoolean(val) !== this._box) {
			this._box = asBoolean(val);
			this.reconstructComponent();
		}
	}
	get outlined() {
		return this._outlined;
	}
	set outlined(val) {
		if (asBoolean(val) !== this._outlined) {
			this._outlined = asBoolean(val);
			this.reconstructComponent();
		}
	}
	get _disabled() {
		return !this._control || this._control.disabled;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcSelectDirective,
			deps: [
				{ token: i0.ElementRef },
				{ token: i0.Renderer2 },
				{ token: MdcEventRegistry }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcSelectDirective,
			isStandalone: false,
			selector: "[mdcSelect]",
			inputs: {
				box: "box",
				outlined: "outlined"
			},
			host: { properties: {
				"class.mdc-select": "this._cls",
				"class.mdc-select--box": "this.box",
				"class.mdc-select--outlined": "this.outlined",
				"class.mdc-select--disabled": "this._disabled"
			} },
			queries: [{
				propertyName: "_control",
				first: true,
				predicate: MdcSelectControlDirective,
				descendants: true
			}, {
				propertyName: "_label",
				first: true,
				predicate: MdcFloatingLabelDirective,
				descendants: true
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcSelectDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcSelect]"
		}]
	}],
	ctorParameters: () => [
		{ type: i0.ElementRef },
		{ type: i0.Renderer2 },
		{ type: MdcEventRegistry }
	],
	propDecorators: {
		_cls: [{
			type: HostBinding,
			args: ["class.mdc-select"]
		}],
		_control: [{
			type: ContentChild,
			args: [MdcSelectControlDirective]
		}],
		_label: [{
			type: ContentChild,
			args: [MdcFloatingLabelDirective]
		}],
		box: [{ type: Input }, {
			type: HostBinding,
			args: ["class.mdc-select--box"]
		}],
		outlined: [{
			type: HostBinding,
			args: ["class.mdc-select--outlined"]
		}, { type: Input }],
		_disabled: [{
			type: HostBinding,
			args: ["class.mdc-select--disabled"]
		}]
	}
});
var MdcSliderDirective = class MdcSliderDirective {
	constructor(_rndr, _root, _registry) {
		this._rndr = _rndr;
		this._root = _root;
		this._registry = _registry;
		this._cls = true;
		this._role = "slider";
		this.valueChange = new EventEmitter();
		this.minValueChange = new EventEmitter();
		this.maxValueChange = new EventEmitter();
		this.stepValueChange = new EventEmitter();
		this._initialized = false;
		this._onChange = (value) => {};
		this._onTouched = () => {};
		this._discrete = false;
		this._markers = false;
		this._disabled = false;
		this._value = 0;
		this._min = 0;
		this._max = 100;
		this._step = 0;
		this.mdcAdapter = {
			hasClass: (className) => {
				if (className === "mdc-slider--discrete") return this._discrete;
				if (className === "mdc-slider--display-markers") return this._markers;
				return this._root.nativeElement.classList.contains(className);
			},
			addClass: (className) => {
				this._rndr.addClass(this._root.nativeElement, className);
			},
			removeClass: (className) => {
				this._rndr.removeClass(this._root.nativeElement, className);
			},
			getAttribute: (name) => this._root.nativeElement.getAttribute(name),
			setAttribute: (name, value) => {
				this._rndr.setAttribute(this._root.nativeElement, name, value);
			},
			removeAttribute: (name) => {
				this._rndr.removeAttribute(this._root.nativeElement, name);
			},
			computeBoundingRect: () => this._root.nativeElement.getBoundingClientRect(),
			getTabIndex: () => this._root.nativeElement.tabIndex,
			registerInteractionHandler: (type, handler) => {
				this._registry.listen(this._rndr, type, handler, this._root);
			},
			deregisterInteractionHandler: (type, handler) => {
				this._registry.unlisten(type, handler);
			},
			registerThumbContainerInteractionHandler: (type, handler) => {
				this._registry.listenElm(this._rndr, type, handler, this._elmThumbCntr);
			},
			deregisterThumbContainerInteractionHandler: (type, handler) => {
				this._registry.unlisten(type, handler);
			},
			registerBodyInteractionHandler: (type, handler) => {
				this._registry.listenElm(this._rndr, type, handler, document.body);
			},
			deregisterBodyInteractionHandler: (type, handler) => {
				this._registry.unlisten(type, handler);
			},
			registerResizeHandler: (handler) => {
				this._registry.listenElm(this._rndr, "resize", handler, window);
			},
			deregisterResizeHandler: (handler) => {
				this._registry.unlisten("resize", handler);
			},
			notifyInput: () => {
				let newValue = this.asNumber(this.foundation.getValue());
				if (newValue !== this._value) {
					this._value = newValue;
					this.notifyValueChanged();
				}
			},
			notifyChange: () => {},
			setThumbContainerStyleProperty: (propertyName, value) => {
				this._rndr.setStyle(this._elmThumbCntr, propertyName, value);
			},
			setTrackStyleProperty: (propertyName, value) => {
				this._rndr.setStyle(this._elmTrack, propertyName, value);
			},
			setMarkerValue: (value) => {
				if (this._elmValueMarker) this._elmValueMarker.innerText = value != null ? value.toString() : null;
			},
			appendTrackMarkers: (numMarkers) => {
				if (this._elmTrackMarkerCntr) {
					const frag = document.createDocumentFragment();
					for (let i = 0; i < numMarkers; i++) {
						const marker = document.createElement("div");
						marker.classList.add("mdc-slider__track-marker");
						frag.appendChild(marker);
					}
					this._rndr.appendChild(this._elmTrackMarkerCntr, frag);
				}
			},
			removeTrackMarkers: () => {
				if (this._elmTrackMarkerCntr) while (this._elmTrackMarkerCntr.firstChild) this._rndr.removeChild(this._elmTrackMarkerCntr, this._elmTrackMarkerCntr.firstChild);
			},
			setLastTrackMarkersStyleProperty: (propertyName, value) => {
				const lastTrackMarker = this._root.nativeElement.querySelector(".mdc-slider__track-marker:last-child");
				if (lastTrackMarker) this._rndr.setStyle(lastTrackMarker, propertyName, value);
			},
			isRTL: () => getComputedStyle(this._root.nativeElement).direction === "rtl"
		};
		this.foundation = new MDCSliderFoundation(this.mdcAdapter);
	}
	ngAfterContentInit() {
		this.initElements();
		this.initDefaultAttributes();
		this.foundation.init();
		this._lastWidth = this.mdcAdapter.computeBoundingRect().width;
		this.updateValues({});
		this._initialized = true;
	}
	ngAfterViewInit() {
		this.updateLayout();
	}
	ngOnDestroy() {
		this.foundation.destroy();
	}
	ngOnChanges(changes) {
		this._onChanges(changes);
	}
	_onChanges(changes) {
		if (this._initialized) {
			if (this.isChanged("discrete", changes) || this.isChanged("markers", changes)) {
				this.foundation.destroy();
				this.initElements();
				this.initDefaultAttributes();
				this.foundation = new MDCSliderFoundation(this.mdcAdapter);
				this.foundation.init();
			}
			this.updateValues(changes);
			this.updateLayout();
		}
	}
	isChanged(name, changes) {
		return changes[name] && changes[name].currentValue !== changes[name].previousValue;
	}
	initElements() {
		while (this._root.nativeElement.firstChild) this._rndr.removeChild(this._root.nativeElement, this._root.nativeElement.firstChild);
		const elmTrackContainer = this.addElement(this._root.nativeElement, "div", ["mdc-slider__track-container"]);
		this._elmTrack = this.addElement(elmTrackContainer, "div", ["mdc-slider__track"]);
		if (this._discrete && this._markers) this._elmTrackMarkerCntr = this.addElement(elmTrackContainer, "div", ["mdc-slider__track-marker-container"]);
		else this._elmTrackMarkerCntr = null;
		this._elmThumbCntr = this.addElement(this._root.nativeElement, "div", ["mdc-slider__thumb-container"]);
		if (this._discrete) {
			this._elmSliderPin = this.addElement(this._elmThumbCntr, "div", ["mdc-slider__pin"]);
			this._elmValueMarker = this.addElement(this._elmSliderPin, "div", ["mdc-slider__pin-value-marker"]);
		} else {
			this._elmSliderPin = null;
			this._elmValueMarker = null;
		}
		const svg = this._rndr.createElement("svg", "svg");
		this._rndr.addClass(svg, "mdc-slider__thumb");
		this._rndr.setAttribute(svg, "width", "21");
		this._rndr.setAttribute(svg, "height", "21");
		this._rndr.appendChild(this._elmThumbCntr, svg);
		const circle = this._rndr.createElement("circle", "svg");
		this._rndr.setAttribute(circle, "cx", "10.5");
		this._rndr.setAttribute(circle, "cy", "10.5");
		this._rndr.setAttribute(circle, "r", "7.875");
		this._rndr.appendChild(svg, circle);
		this.addElement(this._elmThumbCntr, "div", ["mdc-slider__focus-ring"]);
	}
	addElement(parent, element, classNames) {
		let child = this._rndr.createElement(element);
		classNames.forEach((name) => {
			this._rndr.addClass(child, name);
		});
		this._rndr.appendChild(parent, child);
		return child;
	}
	initDefaultAttributes() {
		if (this._reinitTabIndex) this._root.nativeElement.tabIndex = this._reinitTabIndex;
		else if (!this._root.nativeElement.hasAttribute("tabindex")) {
			this._root.nativeElement.tabIndex = 0;
			this._reinitTabIndex = 0;
		} else this._reinitTabIndex = this._root.nativeElement.tabIndex;
	}
	updateValues(changes) {
		if (this._discrete && this._step < 1) {
			this._step = 1;
			setTimeout(() => {
				this.stepValueChange.emit(this._step);
			}, 0);
		} else if (this._step < 0) {
			this._step = 0;
			setTimeout(() => {
				this.stepValueChange.emit(this._step);
			}, 0);
		}
		if (this._min > this._max) {
			if (this.isChanged("maxValue", changes)) {
				this._min = this._max;
				setTimeout(() => {
					this.minValueChange.emit(this._min);
				}, 0);
			} else {
				this._max = this._min;
				setTimeout(() => {
					this.maxValueChange.emit(this._max);
				}, 0);
			}
		}
		let currValue = changes["value"] ? changes["value"].currentValue : this._value;
		if (this._value < this._min) this._value = this._min;
		if (this._value > this._max) this._value = this._max;
		if (this._min < this.foundation.getMax()) {
			this.foundation.setMin(this._min);
			this.foundation.setMax(this._max);
		} else {
			this.foundation.setMax(this._max);
			this.foundation.setMin(this._min);
		}
		this.foundation.setStep(this._step);
		if (this.foundation.isDisabled() !== this._disabled) this.foundation.setDisabled(this._disabled);
		this.foundation.setValue(this._value == null ? void 0 : this._value);
		this._value = this.asNumber(this.foundation.getValue());
		if (currValue != this._value && !(isNaN(currValue) && isNaN(this._value))) setTimeout(() => {
			this.notifyValueChanged();
		}, 0);
	}
	updateLayout() {
		let newWidth = this.mdcAdapter.computeBoundingRect().width;
		if (newWidth !== this._lastWidth) {
			this._lastWidth = newWidth;
			this.foundation.layout();
		}
	}
	notifyValueChanged() {
		this.valueChange.emit(this._value);
		this._onChange(this._value);
	}
	registerOnChange(onChange) {
		this._onChange = onChange;
	}
	registerOnTouched(onTouched) {
		this._onTouched = onTouched;
	}
	get discrete() {
		return this._discrete;
	}
	set discrete(value) {
		this._discrete = asBoolean(value);
	}
	get markers() {
		return this._markers;
	}
	set markers(value) {
		this._markers = asBoolean(value);
	}
	get value() {
		return this._value;
	}
	set value(value) {
		this._value = this.asNumber(value);
	}
	get minValue() {
		return this._min;
	}
	set minValue(value) {
		this._min = this.asNumber(value);
	}
	get maxValue() {
		return this._max;
	}
	set maxValue(value) {
		this._max = this.asNumber(value);
	}
	get stepValue() {
		return this._step;
	}
	set stepValue(value) {
		this._step = this.asNumber(value);
	}
	get disabled() {
		return this._disabled;
	}
	set disabled(value) {
		this._disabled = asBoolean(value);
	}
	asNumber(value) {
		if (value == null) return value;
		let result = +value;
		if (isNaN(result)) return null;
		return result;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcSliderDirective,
			deps: [
				{ token: i0.Renderer2 },
				{ token: i0.ElementRef },
				{ token: MdcEventRegistry }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcSliderDirective,
			isStandalone: false,
			selector: "[mdcSlider]",
			inputs: {
				discrete: "discrete",
				markers: "markers",
				value: "value",
				minValue: "minValue",
				maxValue: "maxValue",
				stepValue: "stepValue",
				disabled: "disabled"
			},
			outputs: {
				valueChange: "valueChange",
				minValueChange: "minValueChange",
				maxValueChange: "maxValueChange",
				stepValueChange: "stepValueChange"
			},
			host: { properties: {
				"class.mdc-slider": "this._cls",
				"attr.role": "this._role",
				"class.mdc-slider--discrete": "this.discrete",
				"class.mdc-slider--display-markers": "this.markers",
				"attr.aria-valuenow": "this.value",
				"attr.aria-valuemin": "this.minValue",
				"attr.aria-valuemax": "this.maxValue",
				"attr.aria-disabled": "this.disabled"
			} },
			usesOnChanges: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcSliderDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcSlider]"
		}]
	}],
	ctorParameters: () => [
		{ type: i0.Renderer2 },
		{ type: i0.ElementRef },
		{ type: MdcEventRegistry }
	],
	propDecorators: {
		_cls: [{
			type: HostBinding,
			args: ["class.mdc-slider"]
		}],
		_role: [{
			type: HostBinding,
			args: ["attr.role"]
		}],
		valueChange: [{ type: Output }],
		minValueChange: [{ type: Output }],
		maxValueChange: [{ type: Output }],
		stepValueChange: [{ type: Output }],
		discrete: [{ type: Input }, {
			type: HostBinding,
			args: ["class.mdc-slider--discrete"]
		}],
		markers: [{ type: Input }, {
			type: HostBinding,
			args: ["class.mdc-slider--display-markers"]
		}],
		value: [{ type: Input }, {
			type: HostBinding,
			args: ["attr.aria-valuenow"]
		}],
		minValue: [{ type: Input }, {
			type: HostBinding,
			args: ["attr.aria-valuemin"]
		}],
		maxValue: [{ type: Input }, {
			type: HostBinding,
			args: ["attr.aria-valuemax"]
		}],
		stepValue: [{ type: Input }],
		disabled: [{ type: Input }, {
			type: HostBinding,
			args: ["attr.aria-disabled"]
		}]
	}
});
var MdcFormsSliderDirective = class MdcFormsSliderDirective {
	constructor(mdcSlider) {
		this.mdcSlider = mdcSlider;
	}
	writeValue(obj) {
		let change = new SimpleChange(this.mdcSlider.value, this.mdcSlider.asNumber(obj), false);
		this.mdcSlider.value = obj;
		this.mdcSlider._onChanges({ value: change });
	}
	registerOnChange(onChange) {
		this.mdcSlider.registerOnChange(onChange);
	}
	registerOnTouched(onTouched) {
		this.mdcSlider.registerOnTouched(onTouched);
	}
	setDisabledState(disabled) {
		this.mdcSlider.disabled = disabled;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcFormsSliderDirective,
			deps: [{
				token: MdcSliderDirective,
				self: true
			}],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcFormsSliderDirective,
			isStandalone: false,
			selector: "[mdcSlider][formControlName],[mdcSlider][formControl],[mdcSlider][ngModel]",
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => MdcFormsSliderDirective),
				multi: true
			}],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcFormsSliderDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcSlider][formControlName],[mdcSlider][formControl],[mdcSlider][ngModel]",
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => MdcFormsSliderDirective),
				multi: true
			}]
		}]
	}],
	ctorParameters: () => [{
		type: MdcSliderDirective,
		decorators: [{ type: Self }]
	}]
});
var MdcSwitchInputDirective = class MdcSwitchInputDirective extends AbstractMdcInput {
	constructor(_elm, _cntr) {
		super();
		this._elm = _elm;
		this._cntr = _cntr;
		this._cls = true;
		this._disabled = false;
	}
	get id() {
		return this._id;
	}
	set id(value) {
		this._id = value;
	}
	get disabled() {
		return this._cntr ? this._cntr.disabled : this._disabled;
	}
	set disabled(value) {
		this._disabled = asBoolean(value);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcSwitchInputDirective,
			deps: [{ token: i0.ElementRef }, {
				token: i1.NgControl,
				optional: true,
				self: true
			}],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcSwitchInputDirective,
			isStandalone: false,
			selector: "input[mdcSwitchInput][type=checkbox]",
			inputs: {
				id: "id",
				disabled: "disabled"
			},
			host: { properties: {
				"class.mdc-switch__native-control": "this._cls",
				"id": "this.id",
				"disabled": "this.disabled"
			} },
			providers: [{
				provide: AbstractMdcInput,
				useExisting: forwardRef(() => MdcSwitchInputDirective)
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcSwitchInputDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "input[mdcSwitchInput][type=checkbox]",
			providers: [{
				provide: AbstractMdcInput,
				useExisting: forwardRef(() => MdcSwitchInputDirective)
			}]
		}]
	}],
	ctorParameters: () => [{ type: i0.ElementRef }, {
		type: i1.NgControl,
		decorators: [{ type: Optional }, { type: Self }]
	}],
	propDecorators: {
		_cls: [{
			type: HostBinding,
			args: ["class.mdc-switch__native-control"]
		}],
		id: [{ type: HostBinding }, { type: Input }],
		disabled: [{ type: HostBinding }, { type: Input }]
	}
});
var MdcSwitchDirective = class MdcSwitchDirective {
	constructor(rndr, root) {
		this.rndr = rndr;
		this.root = root;
		this._cls = true;
	}
	ngAfterContentInit() {
		this.addBackground();
	}
	addBackground() {
		let knob = this.rndr.createElement("div");
		this.rndr.addClass(knob, "mdc-switch__knob");
		let bg = this.rndr.createElement("div");
		this.rndr.addClass(bg, "mdc-switch__background");
		this.rndr.appendChild(bg, knob);
		this.rndr.appendChild(this.root.nativeElement, bg);
	}
	get _disabled() {
		return this._input == null || this._input.disabled;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcSwitchDirective,
			deps: [{ token: i0.Renderer2 }, { token: i0.ElementRef }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcSwitchDirective,
			isStandalone: false,
			selector: "[mdcSwitch]",
			host: { properties: {
				"class.mdc-switch": "this._cls",
				"class.mdc-switch--disabled": "this._disabled"
			} },
			queries: [{
				propertyName: "_input",
				first: true,
				predicate: MdcSwitchInputDirective,
				descendants: true
			}],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcSwitchDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcSwitch]"
		}]
	}],
	ctorParameters: () => [{ type: i0.Renderer2 }, { type: i0.ElementRef }],
	propDecorators: {
		_cls: [{
			type: HostBinding,
			args: ["class.mdc-switch"]
		}],
		_input: [{
			type: ContentChild,
			args: [MdcSwitchInputDirective]
		}],
		_disabled: [{
			type: HostBinding,
			args: ["class.mdc-switch--disabled"]
		}]
	}
});
var MdcTabIconDirective = class MdcTabIconDirective {
	constructor() {
		this._hostClass = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcTabIconDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcTabIconDirective,
			isStandalone: false,
			selector: "[mdcTabIcon]",
			host: { properties: { "class.mdc-tab__icon": "this._hostClass" } },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcTabIconDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcTabIcon]"
		}]
	}],
	propDecorators: { _hostClass: [{
		type: HostBinding,
		args: ["class.mdc-tab__icon"]
	}] }
});
var MdcTabIconTextDirective = class MdcTabIconTextDirective {
	constructor() {
		this._hostClass = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcTabIconTextDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcTabIconTextDirective,
			isStandalone: false,
			selector: "[mdcTabIconText]",
			host: { properties: { "class.mdc-tab__icon-text": "this._hostClass" } },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcTabIconTextDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcTabIconText]"
		}]
	}],
	propDecorators: { _hostClass: [{
		type: HostBinding,
		args: ["class.mdc-tab__icon-text"]
	}] }
});
var AbstractMdcTabDirective = class AbstractMdcTabDirective extends AbstractMdcRipple {
	constructor(_rndr, _root, _registry) {
		super(_root, _rndr, _registry);
		this._rndr = _rndr;
		this._root = _root;
		this._registry = _registry;
		this._hostClass = true;
		this.activate = new EventEmitter();
		this._adapter = {
			addClass: (className) => this._rndr.addClass(this._root.nativeElement, className),
			removeClass: (className) => this._rndr.removeClass(this._root.nativeElement, className),
			registerInteractionHandler: (type, handler) => this._registry.listen(this._rndr, type, handler, this._root),
			deregisterInteractionHandler: (type, handler) => this._registry.unlisten(type, handler),
			getOffsetWidth: () => this._root.nativeElement.offsetWidth,
			getOffsetLeft: () => this._root.nativeElement.offsetLeft,
			notifySelected: () => this.activate.emit({
				tab: this,
				tabIndex: null
			})
		};
		this._foundation = new MDCTabFoundation(this._adapter);
	}
	ngAfterContentInit() {
		this.initRipple();
		this._foundation.init();
	}
	ngOnDestroy() {
		this.destroyRipple();
		this._foundation.destroy();
	}
	get _tabWithIconAndText() {
		return this._mdcTabIcon != null && this._mdcTabIconText != null;
	}
	get _active() {
		return this._foundation.isActive();
	}
	set _active(value) {
		this._foundation.setActive(value);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: AbstractMdcTabDirective,
			deps: [
				{ token: i0.Renderer2 },
				{ token: i0.ElementRef },
				{ token: MdcEventRegistry }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: AbstractMdcTabDirective,
			isStandalone: true,
			outputs: { activate: "activate" },
			host: { properties: {
				"class.mdc-tab": "this._hostClass",
				"class.mdc-tab--with-icon-and-text": "this._tabWithIconAndText",
				"class.mdc-tab--active": "this._active"
			} },
			queries: [{
				propertyName: "_mdcTabIcon",
				first: true,
				predicate: MdcTabIconDirective,
				descendants: true
			}, {
				propertyName: "_mdcTabIconText",
				first: true,
				predicate: MdcTabIconTextDirective,
				descendants: true
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: AbstractMdcTabDirective,
	decorators: [{ type: Directive }],
	ctorParameters: () => [
		{ type: i0.Renderer2 },
		{ type: i0.ElementRef },
		{ type: MdcEventRegistry }
	],
	propDecorators: {
		_hostClass: [{
			type: HostBinding,
			args: ["class.mdc-tab"]
		}],
		_mdcTabIcon: [{
			type: ContentChild,
			args: [MdcTabIconDirective]
		}],
		_mdcTabIconText: [{
			type: ContentChild,
			args: [MdcTabIconTextDirective]
		}],
		activate: [{ type: Output }],
		_tabWithIconAndText: [{
			type: HostBinding,
			args: ["class.mdc-tab--with-icon-and-text"]
		}],
		_active: [{
			type: HostBinding,
			args: ["class.mdc-tab--active"]
		}]
	}
});
var MdcTabDirective = class MdcTabDirective extends AbstractMdcTabDirective {
	constructor(rndr, root, registry) {
		super(rndr, root, registry);
	}
	get active() {
		return this._active;
	}
	set active(value) {
		if (asBoolean(value)) {
			this._active = true;
			this._adapter.notifySelected();
		}
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcTabDirective,
			deps: [
				{ token: i0.Renderer2 },
				{ token: i0.ElementRef },
				{ token: MdcEventRegistry }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcTabDirective,
			isStandalone: false,
			selector: "[mdcTab]",
			inputs: { active: "active" },
			providers: [{
				provide: AbstractMdcTabDirective,
				useExisting: forwardRef(() => MdcTabDirective)
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcTabDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcTab]",
			providers: [{
				provide: AbstractMdcTabDirective,
				useExisting: forwardRef(() => MdcTabDirective)
			}]
		}]
	}],
	ctorParameters: () => [
		{ type: i0.Renderer2 },
		{ type: i0.ElementRef },
		{ type: MdcEventRegistry }
	],
	propDecorators: { active: [{ type: Input }] }
});
var RouterActiveDetector = class {
	constructor(component, links, linksWithHrefs, router, cdr) {
		this.component = component;
		this.links = links;
		this.linksWithHrefs = linksWithHrefs;
		this.router = router;
		this.cdr = cdr;
		this.onDestroy$ = new Subject();
		router.events.pipe(takeUntil(this.onDestroy$)).subscribe((s) => {
			if (s instanceof NavigationEnd) this.update();
		});
	}
	init() {
		this.links.changes.subscribe((_) => this.update());
		this.linksWithHrefs.changes.subscribe((_) => this.update());
		this.update();
	}
	destroy() {
		this.onDestroy$.next();
		this.onDestroy$.complete();
	}
	update() {
		if (!this.links || !this.linksWithHrefs || !this.router.navigated) return;
		const hasActiveLinks = this.hasActiveLinks();
		if (this.component.isRouterActive() !== hasActiveLinks) this.component.setRouterActive(hasActiveLinks);
	}
	hasActiveLinks() {
		return this.links.some(this.isLinkActive(this.router)) || this.linksWithHrefs.some(this.isLinkActive(this.router));
	}
	isLinkActive(router) {
		return (link) => router.isActive(link.urlTree, false);
	}
};
var MdcTabRouterDirective = class MdcTabRouterDirective extends AbstractMdcTabDirective {
	constructor(rndr, root, registry, router, cdr) {
		super(rndr, root, registry);
		this.router = router;
		this.cdr = cdr;
	}
	ngOnDestroy() {
		this.routerActive.destroy();
		this.routerActive = null;
		super.ngOnDestroy();
	}
	ngAfterContentInit() {
		super.ngAfterContentInit();
		this.routerActive = new RouterActiveDetector(this, this._links, this._linksWithHrefs, this.router, this.cdr);
		this.routerActive.init();
	}
	isRouterActive() {
		return this._active;
	}
	setRouterActive(active) {
		this._active = active;
		if (active) this._adapter.notifySelected();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcTabRouterDirective,
			deps: [
				{ token: i0.Renderer2 },
				{ token: i0.ElementRef },
				{ token: MdcEventRegistry },
				{ token: i2.Router },
				{ token: i0.ChangeDetectorRef }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcTabRouterDirective,
			isStandalone: false,
			selector: "[mdcTabRouter]",
			providers: [{
				provide: AbstractMdcTabDirective,
				useExisting: forwardRef(() => MdcTabRouterDirective)
			}],
			queries: [{
				propertyName: "_links",
				predicate: RouterLink,
				descendants: true
			}, {
				propertyName: "_linksWithHrefs",
				predicate: RouterLinkWithHref,
				descendants: true
			}],
			exportAs: ["mdcTabRouter"],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcTabRouterDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcTabRouter]",
			exportAs: "mdcTabRouter",
			providers: [{
				provide: AbstractMdcTabDirective,
				useExisting: forwardRef(() => MdcTabRouterDirective)
			}]
		}]
	}],
	ctorParameters: () => [
		{ type: i0.Renderer2 },
		{ type: i0.ElementRef },
		{ type: MdcEventRegistry },
		{ type: i2.Router },
		{ type: i0.ChangeDetectorRef }
	],
	propDecorators: {
		_links: [{
			type: ContentChildren,
			args: [RouterLink, { descendants: true }]
		}],
		_linksWithHrefs: [{
			type: ContentChildren,
			args: [RouterLinkWithHref, { descendants: true }]
		}]
	}
});
const CLASS_INDICATOR$1 = "mdc-tab-bar__indicator";
var MdcTabBarDirective = class MdcTabBarDirective {
	constructor(_rndr, _el, registry) {
		this._rndr = _rndr;
		this._el = _el;
		this.registry = registry;
		this._hostClass = true;
		this._insideScrollFrame = false;
		this.tabChange = new EventEmitter();
		this._adapter = {
			addClass: (className) => this._rndr.addClass(this._el.nativeElement, className),
			removeClass: (className) => this._rndr.removeClass(this._el.nativeElement, className),
			bindOnMDCTabSelectedEvent: () => this._listenTabSelected(),
			unbindOnMDCTabSelectedEvent: () => this._unlistenTabSelected(),
			registerResizeHandler: (handler) => window.addEventListener("resize", handler),
			deregisterResizeHandler: (handler) => window.removeEventListener("resize", handler),
			getOffsetWidth: () => this._el.nativeElement.offsetWidth,
			setStyleForIndicator: (propertyName, value) => this._rndr.setStyle(this._indicator, propertyName, value),
			getOffsetWidthForIndicator: () => this._indicator.offsetWidth,
			notifyChange: (evtData) => {
				this.tabChange.emit({
					tab: null,
					tabIndex: evtData.activeTabIndex
				});
			},
			getNumberOfTabs: () => this._tabs.length,
			isTabActiveAtIndex: (index) => index >= 0 ? this._tabs.toArray()[index]._active : false,
			setTabActiveAtIndex: (index, isActive = true) => this._tabs.toArray()[index]._active = isActive,
			isDefaultPreventedOnClickForTabAtIndex: (index) => !!this._tabs.toArray()[index]._foundation.preventsDefaultOnClick,
			setPreventDefaultOnClickForTabAtIndex: (index, preventDefaultOnClick) => this._tabs.toArray()[index]._foundation.setPreventDefaultOnClick(preventDefaultOnClick),
			measureTabAtIndex: (index) => this._tabs.toArray()[index]._foundation.measureSelf(),
			getComputedWidthForTabAtIndex: (index) => this._tabs.toArray()[index]._foundation.getComputedWidth(),
			getComputedLeftForTabAtIndex: (index) => this._tabs.toArray()[index]._foundation.getComputedLeft()
		};
		this._foundation = new MDCTabBarFoundation(this._adapter);
	}
	ngAfterContentInit() {
		this._tabs.changes.subscribe(() => {
			if (this._subscriptions) this._listenTabSelected();
		});
		this.addIndicator();
		this._foundation.init();
	}
	ngOnDestroy() {
		this._foundation.destroy();
	}
	addIndicator() {
		this._indicator = this._rndr.createElement("span");
		this._rndr.addClass(this._indicator, CLASS_INDICATOR$1);
		this._rndr.appendChild(this._el.nativeElement, this._indicator);
	}
	_listenTabSelected() {
		if (this._subscriptions) this._unlistenTabSelected();
		this._subscriptions = new Array();
		this._tabs.forEach((tab) => {
			this._subscriptions.push(tab.activate.subscribe((event) => {
				this._setActive(event.tab, true);
			}));
		});
	}
	_unlistenTabSelected() {
		this._subscriptions.forEach((sub) => sub.unsubscribe());
		this._subscriptions = null;
	}
	_setActive(tab, notifyChange) {
		const index = this._tabs.toArray().indexOf(tab);
		this._foundation.switchToTabAtIndex(index, notifyChange);
	}
	get _tabBarWithIcon() {
		return this._tabs.length > 0 && this._tabs.first._mdcTabIcon != null && this._tabs.first._mdcTabIconText == null;
	}
	get _tabBarWithIconAndText() {
		return this._tabs.length > 0 && this._tabs.first._mdcTabIcon != null && this._tabs.first._mdcTabIconText != null;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcTabBarDirective,
			deps: [
				{ token: i0.Renderer2 },
				{ token: i0.ElementRef },
				{ token: MdcEventRegistry }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcTabBarDirective,
			isStandalone: false,
			selector: "[mdcTabBar]",
			outputs: { tabChange: "tabChange" },
			host: { properties: {
				"class.mdc-tab-bar": "this._hostClass",
				"class.mdc-tab-bar-scroller__scroll-frame__tabs": "this._insideScrollFrame",
				"class.mdc-tab-bar--icon-tab-bar": "this._tabBarWithIcon",
				"class.mdc-tab-bar--icons-with-text": "this._tabBarWithIconAndText"
			} },
			queries: [{
				propertyName: "_tabs",
				predicate: AbstractMdcTabDirective
			}],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcTabBarDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcTabBar]"
		}]
	}],
	ctorParameters: () => [
		{ type: i0.Renderer2 },
		{ type: i0.ElementRef },
		{ type: MdcEventRegistry }
	],
	propDecorators: {
		_hostClass: [{
			type: HostBinding,
			args: ["class.mdc-tab-bar"]
		}],
		_insideScrollFrame: [{
			type: HostBinding,
			args: ["class.mdc-tab-bar-scroller__scroll-frame__tabs"]
		}],
		_tabs: [{
			type: ContentChildren,
			args: [AbstractMdcTabDirective, { descendants: false }]
		}],
		tabChange: [{ type: Output }],
		_tabBarWithIcon: [{
			type: HostBinding,
			args: ["class.mdc-tab-bar--icon-tab-bar"]
		}],
		_tabBarWithIconAndText: [{
			type: HostBinding,
			args: ["class.mdc-tab-bar--icons-with-text"]
		}]
	}
});
const CLASS_INDICATOR = "mdc-tab-bar-scroller__indicator";
var MdcTabBarScrollerInnerDirective = class MdcTabBarScrollerInnerDirective {
	constructor() {
		this._hostClass = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcTabBarScrollerInnerDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcTabBarScrollerInnerDirective,
			isStandalone: false,
			selector: "[mdcTabBarScrollerInner]",
			host: { properties: { "class.mdc-tab-bar-scroller__indicator__inner": "this._hostClass" } },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcTabBarScrollerInnerDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcTabBarScrollerInner]"
		}]
	}],
	propDecorators: { _hostClass: [{
		type: HostBinding,
		args: ["class.mdc-tab-bar-scroller__indicator__inner"]
	}] }
});
var MdcTabBarScrollerBackDirective = class MdcTabBarScrollerBackDirective {
	constructor(_el) {
		this._el = _el;
		this._hostClass = true;
		this._back = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcTabBarScrollerBackDirective,
			deps: [{ token: i0.ElementRef }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcTabBarScrollerBackDirective,
			isStandalone: false,
			selector: "[mdcTabBarScrollerBack]",
			host: { properties: {
				"class.mdc-tab-bar-scroller__indicator": "this._hostClass",
				"class.mdc-tab-bar-scroller__indicator--back": "this._back"
			} },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcTabBarScrollerBackDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcTabBarScrollerBack]"
		}]
	}],
	ctorParameters: () => [{ type: i0.ElementRef }],
	propDecorators: {
		_hostClass: [{
			type: HostBinding,
			args: ["class." + CLASS_INDICATOR]
		}],
		_back: [{
			type: HostBinding,
			args: ["class.mdc-tab-bar-scroller__indicator--back"]
		}]
	}
});
var MdcTabBarScrollerForwardDirective = class MdcTabBarScrollerForwardDirective {
	constructor(_el) {
		this._el = _el;
		this._hostClass = true;
		this._forward = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcTabBarScrollerForwardDirective,
			deps: [{ token: i0.ElementRef }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcTabBarScrollerForwardDirective,
			isStandalone: false,
			selector: "[mdcTabBarScrollerForward]",
			host: { properties: {
				"class.mdc-tab-bar-scroller__indicator": "this._hostClass",
				"class.mdc-tab-bar-scroller__indicator--forward": "this._forward"
			} },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcTabBarScrollerForwardDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcTabBarScrollerForward]"
		}]
	}],
	ctorParameters: () => [{ type: i0.ElementRef }],
	propDecorators: {
		_hostClass: [{
			type: HostBinding,
			args: ["class." + CLASS_INDICATOR]
		}],
		_forward: [{
			type: HostBinding,
			args: ["class.mdc-tab-bar-scroller__indicator--forward"]
		}]
	}
});
var MdcTabBarScrollerFrameDirective = class MdcTabBarScrollerFrameDirective {
	constructor(_el) {
		this._el = _el;
		this._hostClass = true;
	}
	ngAfterContentInit() {
		if (this._tabBar) this._tabBar._insideScrollFrame = true;
	}
	_tabAt(index) {
		if (this._tabBar) {
			let tabs = this._tabBar._tabs.toArray();
			if (index >= 0 && index < tabs.length) return tabs[index];
		}
		return null;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcTabBarScrollerFrameDirective,
			deps: [{ token: i0.ElementRef }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcTabBarScrollerFrameDirective,
			isStandalone: false,
			selector: "[mdcTabBarScrollerFrame]",
			host: { properties: { "class.mdc-tab-bar-scroller__scroll-frame": "this._hostClass" } },
			queries: [{
				propertyName: "_tabBar",
				first: true,
				predicate: MdcTabBarDirective,
				descendants: true
			}],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcTabBarScrollerFrameDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcTabBarScrollerFrame]"
		}]
	}],
	ctorParameters: () => [{ type: i0.ElementRef }],
	propDecorators: {
		_hostClass: [{
			type: HostBinding,
			args: ["class.mdc-tab-bar-scroller__scroll-frame"]
		}],
		_tabBar: [{
			type: ContentChild,
			args: [MdcTabBarDirective]
		}]
	}
});
var MdcTabBarScrollerDirective = class MdcTabBarScrollerDirective {
	constructor(_rndr, _el, registry) {
		this._rndr = _rndr;
		this._el = _el;
		this.registry = registry;
		this._hostClass = true;
		this._adapter = {
			addClass: (className) => this._rndr.addClass(this._el.nativeElement, className),
			removeClass: (className) => this._rndr.removeClass(this._el.nativeElement, className),
			eventTargetHasClass: (target, className) => target.classList.contains(className),
			addClassToForwardIndicator: (className) => {
				if (this._forward) this._rndr.addClass(this._forward._el.nativeElement, className);
			},
			removeClassFromForwardIndicator: (className) => {
				if (this._forward) this._rndr.removeClass(this._forward._el.nativeElement, className);
			},
			addClassToBackIndicator: (className) => {
				if (this._back) this._rndr.addClass(this._back._el.nativeElement, className);
			},
			removeClassFromBackIndicator: (className) => {
				if (this._back) this._rndr.removeClass(this._back._el.nativeElement, className);
			},
			isRTL: () => getComputedStyle(this._el.nativeElement).getPropertyValue("direction") === "rtl",
			registerBackIndicatorClickHandler: (handler) => {
				if (this._back) this.registry.listen(this._rndr, "click", handler, this._back._el);
			},
			deregisterBackIndicatorClickHandler: (handler) => {
				if (this._back) this.registry.unlisten("click", handler);
			},
			registerForwardIndicatorClickHandler: (handler) => {
				if (this._forward) this.registry.listen(this._rndr, "click", handler, this._forward._el);
			},
			deregisterForwardIndicatorClickHandler: (handler) => {
				if (this._forward) this.registry.unlisten("click", handler);
			},
			registerCapturedInteractionHandler: (evt, handler) => {
				this.registry.listen(this._rndr, evt, handler, this._el);
			},
			deregisterCapturedInteractionHandler: (evt, handler) => {
				this.registry.unlisten(evt, handler);
			},
			registerWindowResizeHandler: (handler) => window.addEventListener("resize", handler),
			deregisterWindowResizeHandler: (handler) => window.removeEventListener("resize", handler),
			getNumberOfTabs: () => {
				if (this._scrollFrame && this._scrollFrame._tabBar) return this._scrollFrame._tabBar._tabs.length;
				return 0;
			},
			getComputedWidthForTabAtIndex: (index) => this._tabAt(index)._foundation.getComputedWidth(),
			getComputedLeftForTabAtIndex: (index) => this._tabAt(index)._foundation.getComputedLeft(),
			getOffsetWidthForScrollFrame: () => {
				if (this._scrollFrame) return this._scrollFrame._el.nativeElement.offsetWidth;
				return 0;
			},
			getScrollLeftForScrollFrame: () => {
				if (this._scrollFrame) return this._scrollFrame._el.nativeElement.scrollLeft;
				return 0;
			},
			setScrollLeftForScrollFrame: (scrollLeftAmount) => {
				if (this._scrollFrame) this._rndr.setProperty(this._scrollFrame._el.nativeElement, "scrollLeft", scrollLeftAmount);
			},
			getOffsetWidthForTabBar: () => {
				if (this._scrollFrame && this._scrollFrame._tabBar) return this._scrollFrame._tabBar._el.nativeElement.offsetWidth;
				return 0;
			},
			setTransformStyleForTabBar: (value) => {
				if (this._scrollFrame && this._scrollFrame._tabBar) this._rndr.setStyle(this._scrollFrame._tabBar._el.nativeElement, getCorrectPropertyName(window, "transform"), value);
			},
			getOffsetLeftForEventTarget: (target) => target.offsetLeft,
			getOffsetWidthForEventTarget: (target) => target.offsetWidth
		};
		this._foundation = new MDCTabBarScrollerFoundation(this._adapter);
	}
	ngAfterContentInit() {
		this._foundation.init();
	}
	ngOnDestroy() {
		this._foundation.destroy();
	}
	_tabAt(index) {
		if (this._scrollFrame) return this._scrollFrame._tabAt(index);
		return null;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcTabBarScrollerDirective,
			deps: [
				{ token: i0.Renderer2 },
				{ token: i0.ElementRef },
				{ token: MdcEventRegistry }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcTabBarScrollerDirective,
			isStandalone: false,
			selector: "[mdcTabBarScroller]",
			host: { properties: { "class.mdc-tab-bar-scroller": "this._hostClass" } },
			queries: [
				{
					propertyName: "_back",
					first: true,
					predicate: MdcTabBarScrollerBackDirective,
					descendants: true
				},
				{
					propertyName: "_forward",
					first: true,
					predicate: MdcTabBarScrollerForwardDirective,
					descendants: true
				},
				{
					propertyName: "_scrollFrame",
					first: true,
					predicate: MdcTabBarScrollerFrameDirective,
					descendants: true
				}
			],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcTabBarScrollerDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcTabBarScroller]"
		}]
	}],
	ctorParameters: () => [
		{ type: i0.Renderer2 },
		{ type: i0.ElementRef },
		{ type: MdcEventRegistry }
	],
	propDecorators: {
		_hostClass: [{
			type: HostBinding,
			args: ["class.mdc-tab-bar-scroller"]
		}],
		_back: [{
			type: ContentChild,
			args: [MdcTabBarScrollerBackDirective]
		}],
		_forward: [{
			type: ContentChild,
			args: [MdcTabBarScrollerForwardDirective]
		}],
		_scrollFrame: [{
			type: ContentChild,
			args: [MdcTabBarScrollerFrameDirective]
		}]
	}
});
const CLASS_LINE_RIPPLE = "mdc-line-ripple";
let nextId = 1;
var MdcTextFieldInputDirective = class MdcTextFieldInputDirective extends AbstractMdcInput {
	constructor(_elm, renderer, _cntr) {
		super();
		this._elm = _elm;
		this.renderer = renderer;
		this._cntr = _cntr;
		this._onChange = (value) => {};
		this._type = "text";
		this._disabled = false;
		this._required = false;
		this._focused = false;
		this._hostClass = true;
	}
	ngOnInit() {
		this.id = this.id;
		if (this._cntr) this._cntr.valueChanges.subscribe((value) => {
			this._onChange(value);
		});
	}
	get id() {
		return this._id;
	}
	set id(value) {
		this._id = value || this._newId();
	}
	get disabled() {
		return this._cntr ? this._cntr.disabled : this._disabled;
	}
	set disabled(value) {
		this._disabled = asBoolean(value);
	}
	get type() {
		return this._type;
	}
	set type(value) {
		this._type = value || "text";
		if (!this._isTextarea()) try {
			this.renderer.setProperty(this._elm.nativeElement, "type", this._type);
		} catch (e) {
			this.renderer.setElementProperty(this._elm.nativeElement, "type", this._type);
		}
	}
	get value() {
		return this._elm.nativeElement.value;
	}
	set value(value) {
		this._elm.nativeElement.value = value;
		this._onChange(value);
	}
	focus() {
		this._elm.nativeElement.focus();
	}
	_onFocus() {
		this._focused = true;
	}
	_onBlur() {
		this._focused = false;
	}
	_onInput() {}
	get valid() {
		return this._cntr ? this._cntr.valid : this._elm.nativeElement.validity.valid;
	}
	_isBadInput() {
		return this._elm.nativeElement.validity.badInput;
	}
	_isTextarea() {
		return this._elm.nativeElement.nodeName.toLowerCase() === "textarea";
	}
	_newId() {
		this.cachedId = this.cachedId || `mdc-input-${nextId++}`;
		return this.cachedId;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcTextFieldInputDirective,
			deps: [
				{ token: i0.ElementRef },
				{ token: i0.Renderer2 },
				{
					token: i1.NgControl,
					optional: true,
					self: true
				}
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcTextFieldInputDirective,
			isStandalone: false,
			selector: "input[mdcTextFieldInput], textarea[mdcTextFieldInput]",
			inputs: {
				id: "id",
				disabled: "disabled",
				type: "type"
			},
			host: {
				listeners: {
					"focus": "_onFocus()",
					"blur": "_onBlur()",
					"input": "_onInput()"
				},
				properties: {
					"class.mdc-text-field__input": "this._hostClass",
					"id": "this.id",
					"disabled": "this.disabled"
				}
			},
			providers: [{
				provide: AbstractMdcInput,
				useExisting: forwardRef(() => MdcTextFieldInputDirective)
			}],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcTextFieldInputDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "input[mdcTextFieldInput], textarea[mdcTextFieldInput]",
			providers: [{
				provide: AbstractMdcInput,
				useExisting: forwardRef(() => MdcTextFieldInputDirective)
			}]
		}]
	}],
	ctorParameters: () => [
		{ type: i0.ElementRef },
		{ type: i0.Renderer2 },
		{
			type: i1.NgControl,
			decorators: [{ type: Optional }, { type: Self }]
		}
	],
	propDecorators: {
		_hostClass: [{
			type: HostBinding,
			args: ["class.mdc-text-field__input"]
		}],
		id: [{ type: HostBinding }, { type: Input }],
		disabled: [{ type: HostBinding }, { type: Input }],
		type: [{ type: Input }],
		_onFocus: [{
			type: HostListener,
			args: ["focus"]
		}],
		_onBlur: [{
			type: HostListener,
			args: ["blur"]
		}],
		_onInput: [{
			type: HostListener,
			args: ["input"]
		}]
	}
});
var MdcTextFieldIconDirective = class MdcTextFieldIconDirective {
	constructor(_rndr, _el, _reg) {
		this._rndr = _rndr;
		this._el = _el;
		this._reg = _reg;
		this._cls = true;
		this._mdcAdapter = {
			getAttr: (name) => this._el.nativeElement.getAttribute(name),
			setAttr: (name, value) => this._rndr.setAttribute(this._el.nativeElement, name, value),
			removeAttr: (name) => this._rndr.removeAttribute(this._el.nativeElement, name),
			setContent: (content) => this._el.nativeElement.textContent = content,
			registerInteractionHandler: (evtType, handler) => {
				this._reg.listen(this._rndr, evtType, handler, this._el);
			},
			deregisterInteractionHandler: (evtType, handler) => {
				this._reg.unlisten(evtType, handler);
			},
			notifyIconAction: () => {}
		};
		this._foundation = new MDCTextFieldIconFoundation(this._mdcAdapter);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcTextFieldIconDirective,
			deps: [
				{ token: i0.Renderer2 },
				{ token: i0.ElementRef },
				{ token: MdcEventRegistry }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcTextFieldIconDirective,
			isStandalone: false,
			selector: "[mdcTextFieldIcon]",
			host: { properties: { "class.mdc-text-field__icon": "this._cls" } },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcTextFieldIconDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcTextFieldIcon]"
		}]
	}],
	ctorParameters: () => [
		{ type: i0.Renderer2 },
		{ type: i0.ElementRef },
		{ type: MdcEventRegistry }
	],
	propDecorators: { _cls: [{
		type: HostBinding,
		args: ["class.mdc-text-field__icon"]
	}] }
});
var MdcTextFieldHelperTextDirective = class MdcTextFieldHelperTextDirective {
	constructor(_rndr, _elm) {
		this._rndr = _rndr;
		this._elm = _elm;
		this._cls = true;
		this._validation = false;
		this._persistent = false;
		this._mdcAdapter = {
			addClass: (className) => this._rndr.addClass(this._elm.nativeElement, className),
			removeClass: (className) => this._rndr.removeClass(this._elm.nativeElement, className),
			hasClass: (className) => this._elm.nativeElement.classList.contains(className),
			setAttr: (name, value) => this._rndr.setAttribute(this._elm.nativeElement, name, value),
			removeAttr: (name) => this._rndr.removeAttribute(this._elm.nativeElement, name),
			setContent: (content) => {
				throw new Error("MdcTextFieldHelperTextAdapter.setContent not supported");
			}
		};
		this._foundation = new MDCTextFieldHelperTextFoundation(this._mdcAdapter);
	}
	set validation(value) {
		this._validation = asBoolean(value);
	}
	set persistent(value) {
		this._persistent = asBoolean(value);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcTextFieldHelperTextDirective,
			deps: [{ token: i0.Renderer2 }, { token: i0.ElementRef }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcTextFieldHelperTextDirective,
			isStandalone: false,
			selector: "[mdcTextFieldHelperText]",
			inputs: {
				validation: "validation",
				persistent: "persistent"
			},
			host: { properties: {
				"class.mdc-text-field-helper-text": "this._cls",
				"class.mdc-text-field-helper-text--validation-msg": "this._validation",
				"class.mdc-text-field-helper-text--persistent": "this._persistent"
			} },
			exportAs: ["mdcHelperText"],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcTextFieldHelperTextDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcTextFieldHelperText]",
			exportAs: "mdcHelperText"
		}]
	}],
	ctorParameters: () => [{ type: i0.Renderer2 }, { type: i0.ElementRef }],
	propDecorators: {
		_cls: [{
			type: HostBinding,
			args: ["class.mdc-text-field-helper-text"]
		}],
		_validation: [{
			type: HostBinding,
			args: ["class.mdc-text-field-helper-text--validation-msg"]
		}],
		_persistent: [{
			type: HostBinding,
			args: ["class.mdc-text-field-helper-text--persistent"]
		}],
		validation: [{ type: Input }],
		persistent: [{ type: Input }]
	}
});
var MdcTextFieldDirective = class MdcTextFieldDirective extends AbstractMdcRipple {
	constructor(renderer, root, registry) {
		super(root, renderer, registry);
		this.renderer = renderer;
		this.root = root;
		this.registry = registry;
		this._cls = true;
		this._initialized = false;
		this._box = false;
		this._outlined = false;
		this._dense = false;
		this._bottomLineElm = null;
		this._valid = null;
		this.mdcLineRippleAdapter = {
			addClass: (className) => this.renderer.addClass(this._bottomLineElm, className),
			removeClass: (className) => this.renderer.removeClass(this._bottomLineElm, className),
			hasClass: (className) => this._bottomLineElm.classList.contains(className),
			setStyle: (name, value) => this.renderer.setStyle(this._bottomLineElm, name, value),
			registerEventHandler: (evtType, handler) => this.registry.listenElm(this.renderer, evtType, handler, this._bottomLineElm),
			deregisterEventHandler: (evtType, handler) => this.registry.unlisten(evtType, handler)
		};
		this.mdcAdapter = {
			addClass: (className) => {
				this.renderer.addClass(this.root.nativeElement, className);
			},
			removeClass: (className) => {
				this.renderer.removeClass(this.root.nativeElement, className);
			},
			hasClass: (className) => {
				if (className === "mdc-text-field--dense") return this._dense;
				return this.root.nativeElement.classList.contains(className);
			},
			registerTextFieldInteractionHandler: (evtType, handler) => {
				this.registry.listen(this.renderer, evtType, handler, this.root);
			},
			deregisterTextFieldInteractionHandler: (evtType, handler) => {
				this.registry.unlisten(evtType, handler);
			},
			registerInputInteractionHandler: (evtType, handler) => {
				if (this._input) this.registry.listen(this.renderer, evtType, handler, this._input._elm);
			},
			deregisterInputInteractionHandler: (evtType, handler) => {
				this.registry.unlisten(evtType, handler);
			},
			registerValidationAttributeChangeHandler: (handler) => {
				const getAttributesList = (mutationsList) => mutationsList.map((mutation) => mutation.attributeName);
				const observer = new MutationObserver((mutationsList) => handler(getAttributesList(mutationsList)));
				observer.observe(this._input._elm.nativeElement, { attributes: true });
				return observer;
			},
			deregisterValidationAttributeChangeHandler: (observer) => observer.disconnect(),
			getNativeInput: () => {
				return {
					value: this._input.value,
					disabled: this._input.disabled,
					validity: {
						valid: this._valid == null ? this._input.valid : !!this._valid,
						badInput: this._input._isBadInput()
					}
				};
			},
			isFocused: () => this._input && this._input._focused,
			isRtl: () => getComputedStyle(this.root.nativeElement).getPropertyValue("direction") === "rtl",
			activateLineRipple: () => {
				if (this._bottomLineElm) this.bottomLineFoundation.activate();
			},
			deactivateLineRipple: () => {
				if (this._bottomLineElm) this.bottomLineFoundation.deactivate();
			},
			setLineRippleTransformOrigin: (normalizedX) => {
				if (this._bottomLineElm) this.bottomLineFoundation.setRippleCenter(normalizedX);
			},
			shakeLabel: (shouldShake) => this._label._foundation.shake(shouldShake),
			floatLabel: (shouldFloat) => this._label._foundation.float(shouldFloat),
			hasLabel: () => !!this._label,
			getLabelWidth: () => this._label._foundation.getWidth(),
			hasOutline: () => this._outlined,
			notchOutline: (labelWidth, isRtl) => {
				this._outlineSupport.foundation.notch(labelWidth, isRtl);
			},
			closeOutline: () => {
				this._outlineSupport.foundation.closeNotch();
			}
		};
		this.bottomLineFoundation = new MDCLineRippleFoundation(this.mdcLineRippleAdapter);
		this._outlineSupport = new NotchedOutlineSupport(root, renderer);
	}
	ngAfterContentInit() {
		if (this._label && this._input && !this._label.for) this._label.for = this._input.id;
		if (this._label && !this._label._initialized) throw new Error("mdcFloatingLabel initialized after parent mdcTextField");
		this._initialized = true;
		this.initComponent();
		if (this._input) this._input._onChange = (value) => {
			if (this._input && this._label && !this._input._focused) {
				let shouldFloat = value != null && value.toString().length !== 0;
				this._label._foundation.float(shouldFloat);
				this.foundation.notchOutline(shouldFloat);
			}
		};
	}
	ngOnDestroy() {
		this.destroyComponent();
		this._input._onChange = (value) => {};
	}
	initComponent() {
		this.initLineRipple();
		this.initBox();
		this.initOutline();
		this.foundation = new MDCTextFieldFoundation(this.mdcAdapter, {
			lineRipple: this._outlined ? null : this.bottomLineFoundation,
			helperText: this.helperText ? this.helperText._foundation : void 0,
			icon: this._icon ? this._icon._foundation : void 0,
			label: this._label ? this._label._foundation : void 0
		});
		if (this._helperText) this._helperText._foundation.init();
		if (this._icon) this._icon._foundation.init();
		this.foundation.init();
	}
	destroyComponent() {
		this.destroyLineRipple();
		this.destroyBox();
		this.destroyOutline();
		if (this._helperText) this._helperText._foundation.destroy();
		if (this._helperText) this._helperText._foundation.destroy();
		if (this._icon) this._icon._foundation.destroy();
		this.foundation.destroy();
	}
	reconstructComponent() {
		if (this._initialized) {
			this.destroyComponent();
			this.initComponent();
			this.recomputeOutline();
		}
	}
	initLineRipple() {
		if (!this._outlined) {
			this._bottomLineElm = this.renderer.createElement("div");
			this.renderer.addClass(this._bottomLineElm, CLASS_LINE_RIPPLE);
			this.renderer.appendChild(this.root.nativeElement, this._bottomLineElm);
			this.bottomLineFoundation.init();
		}
	}
	destroyLineRipple() {
		if (this._bottomLineElm) {
			this.bottomLineFoundation.destroy();
			this.renderer.removeChild(this.root.nativeElement, this._bottomLineElm);
			this._bottomLineElm = null;
		}
	}
	initBox() {
		if (this._box) this.initRipple();
	}
	destroyBox() {
		this.destroyRipple();
	}
	initOutline() {
		if (this._outlined) this._outlineSupport.init();
	}
	destroyOutline() {
		this._outlineSupport.destroy();
	}
	recomputeOutline() {
		if (this._outlined) setTimeout(() => {
			this.foundation.notchOutline(this.foundation.shouldFloat);
		}, 0);
	}
	set valid(value) {
		if (value == null) {
			this._valid = null;
			this.foundation.useCustomValidityChecking_ = false;
			this.foundation.changeValidity_(this.mdcAdapter.getNativeInput().validity.valid);
		} else if (value !== this._valid) {
			this._valid = asBoolean(value);
			this.foundation.setValid(this._valid);
		}
	}
	get _textArea() {
		return this._input._isTextarea();
	}
	get box() {
		return this._box;
	}
	set box(val) {
		if (asBoolean(val) !== this._box) {
			this._box = asBoolean(val);
			this.reconstructComponent();
		}
	}
	get outlined() {
		return this._outlined;
	}
	set outlined(val) {
		if (asBoolean(val) !== this._outlined) {
			this._outlined = asBoolean(val);
			this.reconstructComponent();
		}
	}
	get _leadingIcon() {
		return this._icon && !this._icon._el.nativeElement.previousElementSibling;
	}
	get _trailingIcon() {
		return this._icon && this._icon._el.nativeElement.previousElementSibling;
	}
	get dense() {
		return this._dense;
	}
	set dense(val) {
		if (asBoolean(val) !== this._dense) {
			this._dense = asBoolean(val);
			this.recomputeOutline();
		}
	}
	get helperText() {
		return this._helperText;
	}
	set helperText(helperText) {
		if (this._initialized) throw new Error("Changing the helperText input of an mdcTextField after initialization is not allowed. Change the content of the mdcTextFieldHelperText instead.");
		this._helperText = helperText;
	}
	get _disabled() {
		return this._input ? this._input.disabled : false;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcTextFieldDirective,
			deps: [
				{ token: i0.Renderer2 },
				{ token: i0.ElementRef },
				{ token: MdcEventRegistry }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcTextFieldDirective,
			isStandalone: false,
			selector: "[mdcTextField]",
			inputs: {
				valid: "valid",
				box: "box",
				outlined: "outlined",
				dense: "dense",
				helperText: "helperText"
			},
			host: { properties: {
				"class.mdc-text-field": "this._cls",
				"class.mdc-text-field--textarea": "this._textArea",
				"class.mdc-text-field--box": "this.box",
				"class.mdc-text-field--outlined": "this.outlined",
				"class.mdc-text-field--with-leading-icon": "this._leadingIcon",
				"class.mdc-text-field--with-trailing-icon": "this._trailingIcon",
				"class.mdc-text-field--dense": "this.dense",
				"class.mdc-text-field--disabled": "this._disabled"
			} },
			providers: [{
				provide: AbstractMdcRipple,
				useExisting: forwardRef(() => MdcTextFieldDirective)
			}],
			queries: [
				{
					propertyName: "_icon",
					first: true,
					predicate: MdcTextFieldIconDirective,
					descendants: true
				},
				{
					propertyName: "_input",
					first: true,
					predicate: MdcTextFieldInputDirective,
					descendants: true
				},
				{
					propertyName: "_label",
					first: true,
					predicate: MdcFloatingLabelDirective,
					descendants: true
				},
				{
					propertyName: "_labels",
					predicate: ["label"],
					descendants: true,
					read: ElementRef
				}
			],
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcTextFieldDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcTextField]",
			providers: [{
				provide: AbstractMdcRipple,
				useExisting: forwardRef(() => MdcTextFieldDirective)
			}]
		}]
	}],
	ctorParameters: () => [
		{ type: i0.Renderer2 },
		{ type: i0.ElementRef },
		{ type: MdcEventRegistry }
	],
	propDecorators: {
		_cls: [{
			type: HostBinding,
			args: ["class.mdc-text-field"]
		}],
		_icon: [{
			type: ContentChild,
			args: [MdcTextFieldIconDirective]
		}],
		_input: [{
			type: ContentChild,
			args: [MdcTextFieldInputDirective]
		}],
		_label: [{
			type: ContentChild,
			args: [MdcFloatingLabelDirective]
		}],
		_labels: [{
			type: ContentChildren,
			args: ["label", {
				descendants: true,
				read: ElementRef
			}]
		}],
		valid: [{ type: Input }],
		_textArea: [{
			type: HostBinding,
			args: ["class.mdc-text-field--textarea"]
		}],
		box: [{
			type: HostBinding,
			args: ["class.mdc-text-field--box"]
		}, { type: Input }],
		outlined: [{
			type: HostBinding,
			args: ["class.mdc-text-field--outlined"]
		}, { type: Input }],
		_leadingIcon: [{
			type: HostBinding,
			args: ["class.mdc-text-field--with-leading-icon"]
		}],
		_trailingIcon: [{
			type: HostBinding,
			args: ["class.mdc-text-field--with-trailing-icon"]
		}],
		dense: [{
			type: HostBinding,
			args: ["class.mdc-text-field--dense"]
		}, { type: Input }],
		helperText: [{ type: Input }],
		_disabled: [{
			type: HostBinding,
			args: ["class.mdc-text-field--disabled"]
		}]
	}
});
var MdcToolbarRowDirective = class MdcToolbarRowDirective {
	constructor(_elm) {
		this._elm = _elm;
		this._hostClass = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcToolbarRowDirective,
			deps: [{ token: i0.ElementRef }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcToolbarRowDirective,
			isStandalone: false,
			selector: "[mdcToolbarRow]",
			host: { properties: { "class.mdc-toolbar__row": "this._hostClass" } },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcToolbarRowDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcToolbarRow]"
		}]
	}],
	ctorParameters: () => [{ type: i0.ElementRef }],
	propDecorators: { _hostClass: [{
		type: HostBinding,
		args: ["class.mdc-toolbar__row"]
	}] }
});
var MdcToolbarSectionDirective = class MdcToolbarSectionDirective {
	constructor() {
		this._hostClass = true;
		this._alignEnd = false;
		this._alignStart = false;
		this._shrinkToFit = false;
	}
	get alignStart() {
		return this._alignStart;
	}
	set alignStart(val) {
		this._alignStart = asBoolean(val);
	}
	get alignEnd() {
		return this._alignEnd;
	}
	set alignEnd(val) {
		this._alignEnd = asBoolean(val);
	}
	get shrinkToFit() {
		return this._shrinkToFit;
	}
	set shrinkToFit(val) {
		this._shrinkToFit = asBoolean(val);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcToolbarSectionDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcToolbarSectionDirective,
			isStandalone: false,
			selector: "[mdcToolbarSection]",
			inputs: {
				alignStart: "alignStart",
				alignEnd: "alignEnd",
				shrinkToFit: "shrinkToFit"
			},
			host: { properties: {
				"class.mdc-toolbar__section": "this._hostClass",
				"class.mdc-toolbar__section--align-start": "this.alignStart",
				"class.mdc-toolbar__section--align-end": "this.alignEnd",
				"class.mdc-toolbar__section--shrink-to-fit": "this.shrinkToFit"
			} },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcToolbarSectionDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcToolbarSection]"
		}]
	}],
	propDecorators: {
		_hostClass: [{
			type: HostBinding,
			args: ["class.mdc-toolbar__section"]
		}],
		alignStart: [{ type: Input }, {
			type: HostBinding,
			args: ["class.mdc-toolbar__section--align-start"]
		}],
		alignEnd: [{ type: Input }, {
			type: HostBinding,
			args: ["class.mdc-toolbar__section--align-end"]
		}],
		shrinkToFit: [{ type: Input }, {
			type: HostBinding,
			args: ["class.mdc-toolbar__section--shrink-to-fit"]
		}]
	}
});
var MdcToolbarTitleDirective = class MdcToolbarTitleDirective {
	constructor(_elm) {
		this._elm = _elm;
		this._hostClass = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcToolbarTitleDirective,
			deps: [{ token: i0.ElementRef }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcToolbarTitleDirective,
			isStandalone: false,
			selector: "[mdcToolbarTitle]",
			host: { properties: { "class.mdc-toolbar__title": "this._hostClass" } },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcToolbarTitleDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcToolbarTitle]"
		}]
	}],
	ctorParameters: () => [{ type: i0.ElementRef }],
	propDecorators: { _hostClass: [{
		type: HostBinding,
		args: ["class.mdc-toolbar__title"]
	}] }
});
var MdcToolbarIcon = class MdcToolbarIcon {
	constructor(_elm) {
		this._elm = _elm;
		this._hostClass = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcToolbarIcon,
			deps: [{ token: i0.ElementRef }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcToolbarIcon,
			isStandalone: false,
			selector: "[mdcToolbarIcon]",
			host: { properties: { "class.mdc-toolbar__icon": "this._hostClass" } },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcToolbarIcon,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcToolbarIcon]"
		}]
	}],
	ctorParameters: () => [{ type: i0.ElementRef }],
	propDecorators: { _hostClass: [{
		type: HostBinding,
		args: ["class.mdc-toolbar__icon"]
	}] }
});
var MdcToolbarMenuIcon = class MdcToolbarMenuIcon {
	constructor(_elm) {
		this._elm = _elm;
		this._hostClass = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcToolbarMenuIcon,
			deps: [{ token: i0.ElementRef }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcToolbarMenuIcon,
			isStandalone: false,
			selector: "[mdcToolbarMenuIcon]",
			host: { properties: { "class.mdc-toolbar__menu-icon": "this._hostClass" } },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcToolbarMenuIcon,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcToolbarMenuIcon]"
		}]
	}],
	ctorParameters: () => [{ type: i0.ElementRef }],
	propDecorators: { _hostClass: [{
		type: HostBinding,
		args: ["class.mdc-toolbar__menu-icon"]
	}] }
});
var MdcToolbarFixedAdjustDirective = class MdcToolbarFixedAdjustDirective {
	constructor(_elm) {
		this._elm = _elm;
		this._hostClass = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcToolbarFixedAdjustDirective,
			deps: [{ token: i0.ElementRef }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcToolbarFixedAdjustDirective,
			isStandalone: false,
			selector: "[mdcToolbarFixedAdjust]",
			host: { properties: { "class.mdc-toolbar-fixed-adjust": "this._hostClass" } },
			exportAs: ["mdcFixedAdjust"],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcToolbarFixedAdjustDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcToolbarFixedAdjust]",
			exportAs: "mdcFixedAdjust"
		}]
	}],
	ctorParameters: () => [{ type: i0.ElementRef }],
	propDecorators: { _hostClass: [{
		type: HostBinding,
		args: ["class.mdc-toolbar-fixed-adjust"]
	}] }
});
var MdcToolbarDirective = class MdcToolbarDirective {
	constructor(renderer, root, registry, zone) {
		this.renderer = renderer;
		this.root = root;
		this.registry = registry;
		this.zone = zone;
		this._hostClass = true;
		this.expansionRatio = new EventEmitter();
		this._initialized = false;
		this._fixed = false;
		this._waterfall = false;
		this._fixedLastRowOnly = false;
		this._flexible = false;
		this._flexibleDefaultBehavior = false;
		this.mdcAdapter = {
			hasClass: (className) => {
				return this.root.nativeElement.classList.contains(className);
			},
			addClass: (className) => {
				this.renderer.addClass(this.root.nativeElement, className);
			},
			removeClass: (className) => {
				this.renderer.removeClass(this.root.nativeElement, className);
			},
			registerScrollHandler: (handler) => {
				if (this._viewport) this._viewport.addEventListener("scroll", handler);
				else window.addEventListener("scroll", handler);
			},
			deregisterScrollHandler: (handler) => {
				if (this._viewport) this._viewport.removeEventListener("scroll", handler);
				else window.removeEventListener("scroll", handler);
			},
			registerResizeHandler: (handler) => {
				window.addEventListener("resize", handler);
			},
			deregisterResizeHandler: (handler) => {
				window.removeEventListener("resize", handler);
			},
			getViewportWidth: () => this._viewport ? this._viewport.clientWidth : window.innerWidth,
			getViewportScrollY: () => this._viewport ? this._viewport.scrollTop : window.pageYOffset,
			getOffsetHeight: () => this.root.nativeElement.offsetHeight,
			getFirstRowElementOffsetHeight: () => this._firstRow._elm.nativeElement.offsetHeight,
			notifyChange: (evtData) => {
				this.expansionRatio.emit(evtData.flexibleExpansionRatio);
			},
			setStyle: (property, value) => {
				this.renderer.setStyle(this.root.nativeElement, property, value);
			},
			setStyleForTitleElement: (property, value) => {
				if (this._title) this.renderer.setStyle(this._title._elm.nativeElement, property, value);
			},
			setStyleForFlexibleRowElement: (property, value) => {
				this.renderer.setStyle(this._firstRow._elm.nativeElement, property, value);
			},
			setStyleForFixedAdjustElement: (property, value) => {
				if (this.fixedAdjust) this.renderer.setStyle(this.fixedAdjust._elm.nativeElement, property, value);
			}
		};
		this.foundation = new MDCToolbarFoundation(this.mdcAdapter);
		this._updateViewPort = () => {
			this.root.nativeElement.style.top = this._viewport.scrollTop + "px";
		};
	}
	ngAfterViewInit() {
		this._initialized = true;
		this.initFixedScroll();
		this.foundation.init();
	}
	ngOnDestroy() {
		this.destroyFixedScroll();
		this.foundation.destroy();
	}
	initFixedScroll() {
		if (this._viewport && this._fixed) {
			this.zone.runOutsideAngular(() => {
				this.root.nativeElement.style.position = "absolute";
				this._viewport.addEventListener("scroll", this._updateViewPort, util.applyPassive());
				this._viewport.addEventListener("touchmove", this._updateViewPort, util.applyPassive());
				window.addEventListener("resize", this._updateViewPort, util.applyPassive());
			});
			this._updateViewPort();
		}
	}
	destroyFixedScroll() {
		if (this._viewport && this._fixed) {
			this._viewport.removeEventListener("scroll", this._updateViewPort);
			this._viewport.removeEventListener("touchmove", this._updateViewPort);
			window.removeEventListener("resize", this._updateViewPort);
		}
	}
	get fixed() {
		return this._fixed;
	}
	set fixed(val) {
		let newValue = asBoolean(val);
		if (this._initialized && this._fixed !== newValue) throw new Error("fixed property should not be changed after the mdcToolbar is initialized");
		this._fixed = newValue;
	}
	get waterfall() {
		return this._waterfall;
	}
	set waterfall(val) {
		this._waterfall = asBoolean(val);
	}
	get fixedLastrowOnly() {
		return this._fixedLastRowOnly;
	}
	set fixedLastrowOnly(val) {
		let newValue = asBoolean(val);
		if (this._initialized && this._fixedLastRowOnly !== newValue) throw new Error("fixedLastrowOnly property should not be changed after the mdcToolbar is initialized");
		this._fixedLastRowOnly = newValue;
	}
	get flexible() {
		return this._flexible;
	}
	set flexible(val) {
		let newValue = asBoolean(val);
		if (this._initialized && this._flexible !== newValue) throw new Error("flexible property should not be changed after the mdcToolbar is initialized");
		this._flexible = newValue;
	}
	get flexibleDefaultBehavior() {
		return this._flexibleDefaultBehavior;
	}
	set flexibleDefaultBehavior(val) {
		let newValue = asBoolean(val);
		if (this._initialized && this._flexibleDefaultBehavior !== newValue) throw new Error("flexibleDefaultBehavior property should not be changed after the mdcToolbar is initialized");
		this._flexibleDefaultBehavior = newValue;
	}
	get viewport() {
		return this._viewport;
	}
	set viewport(elm) {
		if (this._initialized && elm !== this._viewport) throw new Error("viewport directive should not be changed after the mdcToolbar is initialized");
		this._viewport = elm;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcToolbarDirective,
			deps: [
				{ token: i0.Renderer2 },
				{ token: i0.ElementRef },
				{ token: MdcEventRegistry },
				{ token: i0.NgZone }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcToolbarDirective,
			isStandalone: false,
			selector: "[mdcToolbar]",
			inputs: {
				fixedAdjust: "fixedAdjust",
				fixed: "fixed",
				waterfall: "waterfall",
				fixedLastrowOnly: "fixedLastrowOnly",
				flexible: "flexible",
				flexibleDefaultBehavior: "flexibleDefaultBehavior",
				viewport: "viewport"
			},
			outputs: { expansionRatio: "expansionRatio" },
			host: { properties: {
				"class.mdc-toolbar": "this._hostClass",
				"class.mdc-toolbar--fixed": "this.fixed",
				"class.mdc-toolbar--waterfall": "this.waterfall",
				"class.mdc-toolbar--fixed-lastrow-only": "this.fixedLastrowOnly",
				"class.mdc-toolbar--flexible": "this.flexible",
				"class.mdc-toolbar--flexible-default-behavior": "this.flexibleDefaultBehavior"
			} },
			queries: [{
				propertyName: "_title",
				first: true,
				predicate: MdcToolbarTitleDirective,
				descendants: true
			}, {
				propertyName: "_firstRow",
				first: true,
				predicate: MdcToolbarRowDirective,
				descendants: true
			}],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcToolbarDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcToolbar]"
		}]
	}],
	ctorParameters: () => [
		{ type: i0.Renderer2 },
		{ type: i0.ElementRef },
		{ type: MdcEventRegistry },
		{ type: i0.NgZone }
	],
	propDecorators: {
		_hostClass: [{
			type: HostBinding,
			args: ["class.mdc-toolbar"]
		}],
		fixedAdjust: [{ type: Input }],
		expansionRatio: [{ type: Output }],
		_title: [{
			type: ContentChild,
			args: [MdcToolbarTitleDirective]
		}],
		_firstRow: [{
			type: ContentChild,
			args: [MdcToolbarRowDirective]
		}],
		fixed: [{ type: Input }, {
			type: HostBinding,
			args: ["class.mdc-toolbar--fixed"]
		}],
		waterfall: [{ type: Input }, {
			type: HostBinding,
			args: ["class.mdc-toolbar--waterfall"]
		}],
		fixedLastrowOnly: [{ type: Input }, {
			type: HostBinding,
			args: ["class.mdc-toolbar--fixed-lastrow-only"]
		}],
		flexible: [{ type: Input }, {
			type: HostBinding,
			args: ["class.mdc-toolbar--flexible"]
		}],
		flexibleDefaultBehavior: [{ type: Input }, {
			type: HostBinding,
			args: ["class.mdc-toolbar--flexible-default-behavior"]
		}],
		viewport: [{ type: Input }]
	}
});
var MdcTopAppBarRowDirective = class MdcTopAppBarRowDirective {
	constructor(_elm) {
		this._elm = _elm;
		this._hostClass = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcTopAppBarRowDirective,
			deps: [{ token: i0.ElementRef }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcTopAppBarRowDirective,
			isStandalone: false,
			selector: "[mdcTopAppBarRow]",
			host: { properties: { "class.mdc-top-app-bar__row": "this._hostClass" } },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcTopAppBarRowDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcTopAppBarRow]"
		}]
	}],
	ctorParameters: () => [{ type: i0.ElementRef }],
	propDecorators: { _hostClass: [{
		type: HostBinding,
		args: ["class.mdc-top-app-bar__row"]
	}] }
});
var MdcTopAppBarSectionDirective = class MdcTopAppBarSectionDirective {
	constructor() {
		this._hostClass = true;
		this._alignEnd = false;
		this._alignStart = false;
	}
	get alignStart() {
		return this._alignStart;
	}
	set alignStart(val) {
		this._alignStart = asBoolean(val);
	}
	get alignEnd() {
		return this._alignEnd;
	}
	set alignEnd(val) {
		this._alignEnd = asBoolean(val);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcTopAppBarSectionDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcTopAppBarSectionDirective,
			isStandalone: false,
			selector: "[mdcTopAppBarSection]",
			inputs: {
				alignStart: "alignStart",
				alignEnd: "alignEnd"
			},
			host: { properties: {
				"class.mdc-top-app-bar__section": "this._hostClass",
				"class.mdc-top-app-bar__section--align-start": "this.alignStart",
				"class.mdc-top-app-bar__section--align-end": "this.alignEnd"
			} },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcTopAppBarSectionDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcTopAppBarSection]"
		}]
	}],
	propDecorators: {
		_hostClass: [{
			type: HostBinding,
			args: ["class.mdc-top-app-bar__section"]
		}],
		alignStart: [{ type: Input }, {
			type: HostBinding,
			args: ["class.mdc-top-app-bar__section--align-start"]
		}],
		alignEnd: [{ type: Input }, {
			type: HostBinding,
			args: ["class.mdc-top-app-bar__section--align-end"]
		}]
	}
});
var MdcTopAppBarTitleDirective = class MdcTopAppBarTitleDirective {
	constructor(_elm) {
		this._elm = _elm;
		this._hostClass = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcTopAppBarTitleDirective,
			deps: [{ token: i0.ElementRef }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcTopAppBarTitleDirective,
			isStandalone: false,
			selector: "[mdcTopAppBarTitle]",
			host: { properties: { "class.mdc-top-app-bar__title": "this._hostClass" } },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcTopAppBarTitleDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcTopAppBarTitle]"
		}]
	}],
	ctorParameters: () => [{ type: i0.ElementRef }],
	propDecorators: { _hostClass: [{
		type: HostBinding,
		args: ["class.mdc-top-app-bar__title"]
	}] }
});
var MdcTopAppBarNavIconDirective = class MdcTopAppBarNavIconDirective {
	constructor(_elm) {
		this._elm = _elm;
		this._hostClass = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcTopAppBarNavIconDirective,
			deps: [{ token: i0.ElementRef }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcTopAppBarNavIconDirective,
			isStandalone: false,
			selector: "[mdcTopAppBarNavIcon]",
			host: { properties: { "class.mdc-top-app-bar__navigation-icon": "this._hostClass" } },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcTopAppBarNavIconDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcTopAppBarNavIcon]"
		}]
	}],
	ctorParameters: () => [{ type: i0.ElementRef }],
	propDecorators: { _hostClass: [{
		type: HostBinding,
		args: ["class.mdc-top-app-bar__navigation-icon"]
	}] }
});
var MdcTopAppBarActionDirective = class MdcTopAppBarActionDirective {
	constructor(_elm) {
		this._elm = _elm;
		this._hostClass = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcTopAppBarActionDirective,
			deps: [{ token: i0.ElementRef }],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcTopAppBarActionDirective,
			isStandalone: false,
			selector: "[mdcTopAppBarAction]",
			inputs: { label: "label" },
			host: { properties: {
				"class.mdc-top-app-bar__action-item": "this._hostClass",
				"attr.aria-label": "this.label",
				"attr.alt": "this.label"
			} },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcTopAppBarActionDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcTopAppBarAction]"
		}]
	}],
	ctorParameters: () => [{ type: i0.ElementRef }],
	propDecorators: {
		_hostClass: [{
			type: HostBinding,
			args: ["class.mdc-top-app-bar__action-item"]
		}],
		label: [
			{ type: Input },
			{
				type: HostBinding,
				args: ["attr.aria-label"]
			},
			{
				type: HostBinding,
				args: ["attr.alt"]
			}
		]
	}
});
var MdcTopAppBarDirective = class MdcTopAppBarDirective {
	constructor(_rndr, _elm, _registry, zone) {
		this._rndr = _rndr;
		this._elm = _elm;
		this._registry = _registry;
		this.zone = zone;
		this._hostClass = true;
		this._initialized = false;
		this._type = "default";
		this._prominent = false;
		this._dense = false;
		this.mdcAdapter = {
			hasClass: (className) => {
				if (className === "mdc-top-app-bar--short-collapsed") return false;
				return this._elm.nativeElement.classList.contains(className);
			},
			addClass: (className) => {
				if (className === "mdc-top-app-bar--short-collapsed") this._collapsedState = true;
				else if (className !== "mdc-top-app-bar--short-has-action-item") this._rndr.addClass(this._elm.nativeElement, className);
			},
			removeClass: (className) => {
				if (className === "mdc-top-app-bar--short-collapsed") this._collapsedState = false;
				else this._rndr.removeClass(this._elm.nativeElement, className);
			},
			registerNavigationIconInteractionHandler: (type, handler) => {},
			deregisterNavigationIconInteractionHandler: (type, handler) => {},
			notifyNavigationIconClicked: () => {},
			registerScrollHandler: (handler) => {
				if (this._viewport) this._registry.listenElm(this._rndr, "scroll", handler, this._viewport);
				else this._registry.listenElm(this._rndr, "scroll", handler, window);
			},
			deregisterScrollHandler: (handler) => {
				this._registry.unlisten("scroll", handler);
			},
			getViewportScrollY: () => this._viewport ? this._viewport.scrollTop : window.pageYOffset,
			getTotalActionItems: () => this._actionItems.length
		};
		this._updateViewPort = () => {
			this._elm.nativeElement.style.top = this._viewport.scrollTop + "px";
		};
	}
	ngAfterContentInit() {
		if (this._viewport) this._elm.nativeElement.style.position = "absolute";
		this._initialized = true;
		this.foundationReInit();
	}
	ngOnDestroy() {
		this.removeScrollListeners();
		this.foundation.destroy();
		this.foundation = null;
		this._initialized = false;
	}
	foundationReInit() {
		if (this._initialized) {
			if (this.foundation) this.foundation.destroy();
			this.removeScrollListeners();
			this._elm.nativeElement.style.top = null;
			this._rndr.removeClass(this._elm.nativeElement, "mdc-top-app-bar--fixed-scrolled");
			this.initFixedAdjust();
			if (this._type === "short") this.foundation = new MDCShortTopAppBarFoundation(this.mdcAdapter);
			else if (this._type === "fixed") this.foundation = new MDCFixedTopAppBarFoundation(this.mdcAdapter);
			else this.foundation = new MDCTopAppBarFoundation(this.mdcAdapter);
			if (this.viewport && (this._type === "short" || this._type === "fixed")) {
				this.zone.runOutsideAngular(() => {
					this._viewport.addEventListener("scroll", this._updateViewPort, util.applyPassive());
					this._viewport.addEventListener("touchmove", this._updateViewPort, util.applyPassive());
					window.addEventListener("resize", this._updateViewPort, util.applyPassive());
				});
				this._updateViewPort();
			}
			this.foundation.init();
		}
	}
	initFixedAdjust() {
		if (this._initialized && this._fixedAdjust) {
			this._rndr.removeClass(this._fixedAdjust, "mdc-top-app-bar--fixed-adjust");
			this._rndr.removeClass(this._fixedAdjust, "mdc-top-app-bar--dense-fixed-adjust");
			this._rndr.removeClass(this._fixedAdjust, "mdc-top-app-bar--short-fixed-adjust");
			this._rndr.removeClass(this._fixedAdjust, "mdc-top-app-bar--prominent-fixed-adjust");
			this._rndr.removeClass(this._fixedAdjust, "mdc-top-app-bar--dense-prominent-fixed-adjust");
			if (this.prominent && this.dense) this._rndr.addClass(this._fixedAdjust, "mdc-top-app-bar--dense-prominent-fixed-adjust");
			else if (this._prominent) this._rndr.addClass(this._fixedAdjust, "mdc-top-app-bar--prominent-fixed-adjust");
			else if (this._type === "short") this._rndr.addClass(this._fixedAdjust, "mdc-top-app-bar--short-fixed-adjust");
			else if (this._dense) this._rndr.addClass(this._fixedAdjust, "mdc-top-app-bar--dense-fixed-adjust");
			else this._rndr.addClass(this._fixedAdjust, "mdc-top-app-bar--fixed-adjust");
		}
	}
	removeScrollListeners() {
		if (this._viewport) {
			this._viewport.removeEventListener("scroll", this._updateViewPort);
			this._viewport.removeEventListener("touchmove", this._updateViewPort);
			window.removeEventListener("resize", this._updateViewPort);
		}
	}
	get mdcTopAppBar() {
		return this._type;
	}
	set mdcTopAppBar(val) {
		const type = val === "short" || val === "fixed" ? val : "default";
		if (type !== this._type) {
			this._type = type;
			this.foundationReInit();
		}
	}
	get prominent() {
		return this._prominent;
	}
	set prominent(val) {
		if (asBoolean(val) !== this._prominent) {
			this._prominent = asBoolean(val);
			this.initFixedAdjust();
		}
	}
	get dense() {
		return this._dense;
	}
	set dense(val) {
		if (asBoolean(val) !== this._dense) {
			this._dense = asBoolean(val);
			this.initFixedAdjust();
		}
	}
	get collapsed() {
		if (this._type !== "short") return false;
		return this._collapsedOverride == null ? !!this._collapsedState : this._collapsedOverride;
	}
	set collapsed(val) {
		this._collapsedOverride = asBooleanOrNull(val);
	}
	get fixedAdjust() {
		return this._fixedAdjust;
	}
	set fixedAdjust(el) {
		if (this._fixedAdjust !== el) {
			this._fixedAdjust = el;
			this.initFixedAdjust();
		}
	}
	get viewport() {
		return this._viewport;
	}
	set viewport(elm) {
		if (this._initialized && elm !== this._viewport) throw new Error("viewport directive should not be changed after the mdcToolbar is initialized");
		this._viewport = elm;
	}
	get _hasActionItems() {
		return this._type === "short" && this._actionItems.length > 0;
	}
	get _fixed() {
		return this._type === "fixed";
	}
	get _short() {
		return this._type === "short";
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcTopAppBarDirective,
			deps: [
				{ token: i0.Renderer2 },
				{ token: i0.ElementRef },
				{ token: MdcEventRegistry },
				{ token: i0.NgZone }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcTopAppBarDirective,
			isStandalone: false,
			selector: "[mdcTopAppBar]",
			inputs: {
				mdcTopAppBar: "mdcTopAppBar",
				prominent: "prominent",
				dense: "dense",
				collapsed: "collapsed",
				fixedAdjust: "fixedAdjust",
				viewport: "viewport"
			},
			host: { properties: {
				"class.mdc-top-app-bar": "this._hostClass",
				"class.mdc-top-app-bar--prominent": "this.prominent",
				"class.mdc-top-app-bar--dense": "this.dense",
				"class.mdc-top-app-bar--short-collapsed": "this.collapsed",
				"class.mdc-top-app-bar--short-has-action-item": "this._hasActionItems",
				"class.mdc-top-app-bar--fixed": "this._fixed",
				"class.mdc-top-app-bar--short": "this._short"
			} },
			queries: [{
				propertyName: "_actionItems",
				predicate: MdcTopAppBarActionDirective,
				descendants: true
			}],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcTopAppBarDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcTopAppBar]"
		}]
	}],
	ctorParameters: () => [
		{ type: i0.Renderer2 },
		{ type: i0.ElementRef },
		{ type: MdcEventRegistry },
		{ type: i0.NgZone }
	],
	propDecorators: {
		_hostClass: [{
			type: HostBinding,
			args: ["class.mdc-top-app-bar"]
		}],
		_actionItems: [{
			type: ContentChildren,
			args: [MdcTopAppBarActionDirective, { descendants: true }]
		}],
		mdcTopAppBar: [{ type: Input }],
		prominent: [{ type: Input }, {
			type: HostBinding,
			args: ["class.mdc-top-app-bar--prominent"]
		}],
		dense: [{ type: Input }, {
			type: HostBinding,
			args: ["class.mdc-top-app-bar--dense"]
		}],
		collapsed: [{ type: Input }, {
			type: HostBinding,
			args: ["class.mdc-top-app-bar--short-collapsed"]
		}],
		fixedAdjust: [{ type: Input }],
		viewport: [{ type: Input }],
		_hasActionItems: [{
			type: HostBinding,
			args: ["class.mdc-top-app-bar--short-has-action-item"]
		}],
		_fixed: [{
			type: HostBinding,
			args: ["class.mdc-top-app-bar--fixed"]
		}],
		_short: [{
			type: HostBinding,
			args: ["class.mdc-top-app-bar--short"]
		}]
	}
});
const TOP_APP_BAR_DIRECTIVES = [
	MdcTopAppBarRowDirective,
	MdcTopAppBarSectionDirective,
	MdcTopAppBarTitleDirective,
	MdcTopAppBarNavIconDirective,
	MdcTopAppBarActionDirective,
	MdcTopAppBarDirective
];
let scrollbarResizeListenerId;
let scrollbarResizeDirectives = 0;
function initScrollbarResizeListener() {
	if (scrollbarResizeListenerId) return;
	let iframe = document.createElement("iframe");
	iframe.id = scrollbarResizeListenerId = "scrollbarResizeListener_" + Math.random().toString(36).substr(2, 10);
	iframe.style.cssText = "position:absolute;margin:0;padding:0;border-width:0;overflow:hidden;height:0;width:100%;background-color:transparent;";
	iframe.onload = function() {
		iframe.contentWindow.addEventListener("resize", function() {
			try {
				var evt = document.createEvent("UIEvents");
				evt.initUIEvent("resize", true, false, window, 0);
				window.dispatchEvent(evt);
			} catch (e) {}
		});
	};
	document.body.appendChild(iframe);
}
function destroyScrollbarResizeListener() {
	if (scrollbarResizeListenerId != null) {
		let iframe = document.getElementById(scrollbarResizeListenerId);
		if (iframe) iframe.parentElement.removeChild(iframe);
		scrollbarResizeListenerId = null;
	}
}
var MdcScrollbarResizeDirective = class MdcScrollbarResizeDirective {
	constructor() {
		this._scrollbarResize = false;
	}
	ngOnDestroy() {
		if (this._scrollbarResize) {
			this._scrollbarResize = false;
			--scrollbarResizeDirectives;
			if (scrollbarResizeDirectives <= 0) destroyScrollbarResizeListener();
		}
	}
	get mdcScrollbarResize() {
		return this._scrollbarResize;
	}
	set mdcScrollbarResize(val) {
		let newValue = asBoolean(val);
		if (newValue !== this._scrollbarResize) {
			this._scrollbarResize = newValue;
			if (newValue) {
				++scrollbarResizeDirectives;
				initScrollbarResizeListener();
			} else {
				--scrollbarResizeDirectives;
				if (scrollbarResizeDirectives <= 0) destroyScrollbarResizeListener();
			}
		}
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcScrollbarResizeDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MdcScrollbarResizeDirective,
			isStandalone: false,
			selector: "[mdcScrollbarResize]",
			inputs: { mdcScrollbarResize: "mdcScrollbarResize" },
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcScrollbarResizeDirective,
	decorators: [{
		type: Directive,
		args: [{
			standalone: false,
			selector: "[mdcScrollbarResize]"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { mdcScrollbarResize: [{ type: Input }] }
});
const CLASS_ALIGN_START = "mdc-snackbar--align-start";
var MdcSnackbarRef = class {
	constructor(_action, _show, _hide) {
		this._action = _action;
		this._show = _show;
		this._hide = _hide;
	}
	action() {
		return this._action.asObservable();
	}
	afterShow() {
		return this._show.asObservable();
	}
	afterHide() {
		return this._hide.asObservable();
	}
};
var MdcSnackbarService = class MdcSnackbarService {
	constructor() {
		this.snackbar = null;
		this.root = null;
		this.isActive = false;
		this.postedMessages = 0;
		this.lastActivated = -1;
		this.lastDismissed = -1;
		this.openMessage = new Subject();
		this.closeMessage = new Subject();
	}
	initHtml() {
		if (!this.snackbar) {
			this.root = document.createElement("div");
			this.root.classList.add("mdc-snackbar");
			this.root.setAttribute("aria-live", "assertive");
			this.root.setAttribute("aria-atomic", "true");
			this.root.setAttribute("aria-hidden", "true");
			let snackbarText = document.createElement("div");
			snackbarText.classList.add("mdc-snackbar__text");
			this.root.appendChild(snackbarText);
			let snackbarAction = document.createElement("div");
			snackbarAction.classList.add("mdc-snackbar__action-wrapper");
			this.root.appendChild(snackbarAction);
			let snackbarActionButton = document.createElement("button");
			snackbarActionButton.classList.add("mdc-snackbar__action-button");
			snackbarActionButton.setAttribute("type", "button");
			snackbarAction.appendChild(snackbarActionButton);
			document.body.appendChild(this.root);
			this.snackbar = new MDCSnackbar(this.root, this.getFoundation(this.root));
		}
	}
	getFoundation(root) {
		const textEl = root.querySelector(".mdc-snackbar__text");
		const buttonEl = root.querySelector(".mdc-snackbar__action-button");
		return new MDCSnackbarFoundation({
			addClass: (className) => {
				root.classList.add(className);
			},
			removeClass: (className) => {
				root.classList.remove(className);
			},
			setAriaHidden: () => root.setAttribute("aria-hidden", "true"),
			unsetAriaHidden: () => root.removeAttribute("aria-hidden"),
			setActionAriaHidden: () => buttonEl.setAttribute("aria-hidden", "true"),
			unsetActionAriaHidden: () => buttonEl.removeAttribute("aria-hidden"),
			setActionText: (text) => {
				buttonEl.textContent = text;
			},
			setMessageText: (text) => {
				textEl.textContent = text;
			},
			setFocus: () => buttonEl.focus(),
			visibilityIsHidden: () => document.hidden,
			registerCapturedBlurHandler: (handler) => buttonEl.addEventListener("blur", handler, true),
			deregisterCapturedBlurHandler: (handler) => buttonEl.removeEventListener("blur", handler, true),
			registerVisibilityChangeHandler: (handler) => document.addEventListener("visibilitychange", handler),
			deregisterVisibilityChangeHandler: (handler) => document.removeEventListener("visibilitychange", handler),
			registerCapturedInteractionHandler: (evt, handler) => document.body.addEventListener(evt, handler, true),
			deregisterCapturedInteractionHandler: (evt, handler) => document.body.removeEventListener(evt, handler, true),
			registerActionClickHandler: (handler) => buttonEl.addEventListener("click", handler),
			deregisterActionClickHandler: (handler) => buttonEl.removeEventListener("click", handler),
			registerTransitionEndHandler: (handler) => root.addEventListener(getCorrectEventName(window, "transitionend"), handler),
			deregisterTransitionEndHandler: (handler) => root.removeEventListener(getCorrectEventName(window, "transitionend"), handler),
			notifyShow: () => {
				this.activateNext();
			},
			notifyHide: () => {
				this.deactivateLast();
			}
		});
	}
	activateNext() {
		while (this.lastDismissed < this.lastActivated) this.closeMessage.next(++this.lastDismissed);
		this.openMessage.next(++this.lastActivated);
		this.isActive = true;
	}
	deactivateLast() {
		if (this.isActive) {
			++this.lastDismissed;
			this.isActive = false;
			this.closeMessage.next(this.lastDismissed);
		}
	}
	show(message) {
		if (!message) throw new Error("snackbar message called with no data");
		if (!message.message) throw new Error("snackbar message is missing the actual message text");
		this.initHtml();
		let messageNr = this.postedMessages++;
		let data = {
			message: message.message,
			actionText: message.actionText,
			multiline: message.multiline,
			actionOnBottom: message.actionOnBottom,
			timeout: message.timeout
		};
		let action = new Subject();
		let show = new Subject();
		let hide = new Subject();
		if (message.actionText) data.actionHandler = function() {
			action.next();
		};
		this.openMessage.asObservable().pipe(filter((nr) => nr === messageNr), take(1)).subscribe((nr) => {
			show.next();
		});
		this.closeMessage.asObservable().pipe(filter((nr) => nr === messageNr), take(1)).subscribe((nr) => {
			hide.next();
			show.complete();
			hide.complete();
			action.complete();
		});
		setTimeout(() => {
			this.snackbar.show(data);
		});
		return new MdcSnackbarRef(action, show, hide);
	}
	get startAligned() {
		return this.snackbar ? this.root.classList.contains(CLASS_ALIGN_START) : false;
	}
	set startAligned(value) {
		this.initHtml();
		if (value) this.root.classList.add(CLASS_ALIGN_START);
		else this.root.classList.remove(CLASS_ALIGN_START);
	}
	get dismissesOnAction() {
		return this.snackbar ? this.snackbar.dismissesOnAction : true;
	}
	set dismissesOnAction(value) {
		this.initHtml();
		this.snackbar.dismissesOnAction = value;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcSnackbarService,
			deps: [],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MdcSnackbarService,
			providedIn: "root"
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MdcSnackbarService,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}],
	ctorParameters: () => []
});
var MaterialModule = class MaterialModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MaterialModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MaterialModule,
			declarations: [
				MdcButtonDirective,
				MdcButtonIconDirective,
				MdcCardDirective,
				MdcCardMediaDirective,
				MdcCardMediaContentDirective,
				MdcCardActionButtonsDirective,
				MdcCardActionIconsDirective,
				MdcCardActionsDirective,
				MdcCardPrimaryActionDirective,
				MdcCheckboxDirective,
				MdcCheckboxInputDirective,
				MdcChipIconDirective,
				MdcChipTextDirective,
				MdcChipDirective,
				MdcChipSetDirective,
				MdcDialogDirective,
				MdcDialogHeaderTitleDirective,
				MdcDialogHeaderDirective,
				MdcDialogBodyDirective,
				MdcDialogFooterDirective,
				MdcDialogAcceptDirective,
				MdcDialogCancelDirective,
				MdcDialogBackdropDirective,
				MdcDialogSurfaceDirective,
				MdcDrawerDirective,
				MdcDrawerContainerDirective,
				MdcDrawerToolbarSpacerDirective,
				MdcDrawerHeaderDirective,
				MdcDrawerHeaderContentDirective,
				MdcDrawerContentDirective,
				MdcElevationDirective,
				MdcFabDirective,
				MdcFabIconDirective,
				MdcFloatingLabelDirective,
				MdcFocusInitialDirective,
				MdcFocusTrapDirective,
				MdcFormFieldDirective,
				MdcFormFieldInputDirective,
				MdcFormFieldLabelDirective,
				MdcIconButtonIconDirective,
				MdcIconButtonDirective,
				MdcIconButtonToggleDirective,
				MdcFormsIconButtonDirective,
				MdcIconToggleDirective,
				MdcIconToggleIconDirective,
				MdcFormsIconToggleDirective,
				MdcLinearProgressDirective,
				MdcListDividerDirective,
				MdcListItemDirective,
				MdcListItemTextDirective,
				MdcListItemSecondaryTextDirective,
				MdcListItemGraphicDirective,
				MdcListItemMetaDirective,
				MdcListDirective,
				MdcListGroupSubHeaderDirective,
				MdcListGroupDirective,
				MdcMenuAnchorDirective,
				MdcMenuDirective,
				MdcRadioDirective,
				MdcRadioInputDirective,
				MdcRippleDirective,
				MdcSelectDirective,
				MdcSelectControlDirective,
				MdcSliderDirective,
				MdcFormsSliderDirective,
				MdcSwitchInputDirective,
				MdcSwitchDirective,
				MdcTabDirective,
				MdcTabIconDirective,
				MdcTabIconTextDirective,
				MdcTabRouterDirective,
				MdcTabBarDirective,
				MdcTabBarScrollerDirective,
				MdcTabBarScrollerInnerDirective,
				MdcTabBarScrollerBackDirective,
				MdcTabBarScrollerForwardDirective,
				MdcTabBarScrollerFrameDirective,
				MdcTextFieldDirective,
				MdcTextFieldInputDirective,
				MdcTextFieldIconDirective,
				MdcTextFieldHelperTextDirective,
				MdcToolbarDirective,
				MdcToolbarRowDirective,
				MdcToolbarSectionDirective,
				MdcToolbarTitleDirective,
				MdcToolbarIcon,
				MdcToolbarMenuIcon,
				MdcToolbarFixedAdjustDirective,
				MdcTopAppBarRowDirective,
				MdcTopAppBarSectionDirective,
				MdcTopAppBarTitleDirective,
				MdcTopAppBarNavIconDirective,
				MdcTopAppBarActionDirective,
				MdcTopAppBarDirective,
				MdcScrollbarResizeDirective
			],
			imports: [CommonModule],
			exports: [
				MdcButtonDirective,
				MdcButtonIconDirective,
				MdcCardDirective,
				MdcCardMediaDirective,
				MdcCardMediaContentDirective,
				MdcCardActionButtonsDirective,
				MdcCardActionIconsDirective,
				MdcCardActionsDirective,
				MdcCardPrimaryActionDirective,
				MdcCheckboxDirective,
				MdcCheckboxInputDirective,
				MdcChipIconDirective,
				MdcChipTextDirective,
				MdcChipDirective,
				MdcChipSetDirective,
				MdcDialogDirective,
				MdcDialogHeaderTitleDirective,
				MdcDialogHeaderDirective,
				MdcDialogBodyDirective,
				MdcDialogFooterDirective,
				MdcDialogAcceptDirective,
				MdcDialogCancelDirective,
				MdcDialogBackdropDirective,
				MdcDialogSurfaceDirective,
				MdcDrawerDirective,
				MdcDrawerContainerDirective,
				MdcDrawerToolbarSpacerDirective,
				MdcDrawerHeaderDirective,
				MdcDrawerHeaderContentDirective,
				MdcDrawerContentDirective,
				MdcElevationDirective,
				MdcFabDirective,
				MdcFabIconDirective,
				MdcFloatingLabelDirective,
				MdcFocusInitialDirective,
				MdcFocusTrapDirective,
				MdcFormFieldDirective,
				MdcFormFieldInputDirective,
				MdcFormFieldLabelDirective,
				MdcIconButtonIconDirective,
				MdcIconButtonDirective,
				MdcIconButtonToggleDirective,
				MdcFormsIconButtonDirective,
				MdcIconToggleDirective,
				MdcIconToggleIconDirective,
				MdcFormsIconToggleDirective,
				MdcLinearProgressDirective,
				MdcListDividerDirective,
				MdcListItemDirective,
				MdcListItemTextDirective,
				MdcListItemSecondaryTextDirective,
				MdcListItemGraphicDirective,
				MdcListItemMetaDirective,
				MdcListDirective,
				MdcListGroupSubHeaderDirective,
				MdcListGroupDirective,
				MdcMenuAnchorDirective,
				MdcMenuDirective,
				MdcRadioDirective,
				MdcRadioInputDirective,
				MdcRippleDirective,
				MdcSelectDirective,
				MdcSelectControlDirective,
				MdcSliderDirective,
				MdcFormsSliderDirective,
				MdcSwitchInputDirective,
				MdcSwitchDirective,
				MdcTabDirective,
				MdcTabIconDirective,
				MdcTabIconTextDirective,
				MdcTabRouterDirective,
				MdcTabBarDirective,
				MdcTabBarScrollerDirective,
				MdcTabBarScrollerInnerDirective,
				MdcTabBarScrollerBackDirective,
				MdcTabBarScrollerForwardDirective,
				MdcTabBarScrollerFrameDirective,
				MdcTextFieldDirective,
				MdcTextFieldInputDirective,
				MdcTextFieldIconDirective,
				MdcTextFieldHelperTextDirective,
				MdcToolbarDirective,
				MdcToolbarRowDirective,
				MdcToolbarSectionDirective,
				MdcToolbarTitleDirective,
				MdcToolbarIcon,
				MdcToolbarMenuIcon,
				MdcToolbarFixedAdjustDirective,
				MdcTopAppBarRowDirective,
				MdcTopAppBarSectionDirective,
				MdcTopAppBarTitleDirective,
				MdcTopAppBarNavIconDirective,
				MdcTopAppBarActionDirective,
				MdcTopAppBarDirective,
				MdcScrollbarResizeDirective
			]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MaterialModule,
			imports: [CommonModule]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MaterialModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [CommonModule],
			declarations: [
				MdcButtonDirective,
				MdcButtonIconDirective,
				MdcCardDirective,
				MdcCardMediaDirective,
				MdcCardMediaContentDirective,
				MdcCardActionButtonsDirective,
				MdcCardActionIconsDirective,
				MdcCardActionsDirective,
				MdcCardPrimaryActionDirective,
				MdcCheckboxDirective,
				MdcCheckboxInputDirective,
				...CHIP_DIRECTIVES,
				...DIALOG_DIRECTIVES,
				MdcDrawerDirective,
				MdcDrawerContainerDirective,
				MdcDrawerToolbarSpacerDirective,
				MdcDrawerHeaderDirective,
				MdcDrawerHeaderContentDirective,
				MdcDrawerContentDirective,
				MdcElevationDirective,
				MdcFabDirective,
				MdcFabIconDirective,
				MdcFloatingLabelDirective,
				...FOCUS_TRAP_DIRECTIVES,
				MdcFormFieldDirective,
				MdcFormFieldInputDirective,
				MdcFormFieldLabelDirective,
				...ICON_BUTTON_DIRECTIVES,
				MdcIconToggleDirective,
				MdcIconToggleIconDirective,
				MdcFormsIconToggleDirective,
				MdcLinearProgressDirective,
				MdcListDividerDirective,
				MdcListItemDirective,
				MdcListItemTextDirective,
				MdcListItemSecondaryTextDirective,
				MdcListItemGraphicDirective,
				MdcListItemMetaDirective,
				MdcListDirective,
				MdcListGroupSubHeaderDirective,
				MdcListGroupDirective,
				MdcMenuAnchorDirective,
				MdcMenuDirective,
				MdcRadioDirective,
				MdcRadioInputDirective,
				MdcRippleDirective,
				MdcSelectDirective,
				MdcSelectControlDirective,
				MdcSliderDirective,
				MdcFormsSliderDirective,
				MdcSwitchInputDirective,
				MdcSwitchDirective,
				MdcTabDirective,
				MdcTabIconDirective,
				MdcTabIconTextDirective,
				MdcTabRouterDirective,
				MdcTabBarDirective,
				MdcTabBarScrollerDirective,
				MdcTabBarScrollerInnerDirective,
				MdcTabBarScrollerBackDirective,
				MdcTabBarScrollerForwardDirective,
				MdcTabBarScrollerFrameDirective,
				MdcTextFieldDirective,
				MdcTextFieldInputDirective,
				MdcTextFieldIconDirective,
				MdcTextFieldHelperTextDirective,
				MdcToolbarDirective,
				MdcToolbarRowDirective,
				MdcToolbarSectionDirective,
				MdcToolbarTitleDirective,
				MdcToolbarIcon,
				MdcToolbarMenuIcon,
				MdcToolbarFixedAdjustDirective,
				TOP_APP_BAR_DIRECTIVES,
				MdcScrollbarResizeDirective
			],
			exports: [
				MdcButtonDirective,
				MdcButtonIconDirective,
				MdcCardDirective,
				MdcCardMediaDirective,
				MdcCardMediaContentDirective,
				MdcCardActionButtonsDirective,
				MdcCardActionIconsDirective,
				MdcCardActionsDirective,
				MdcCardPrimaryActionDirective,
				MdcCheckboxDirective,
				MdcCheckboxInputDirective,
				...CHIP_DIRECTIVES,
				...DIALOG_DIRECTIVES,
				MdcDrawerDirective,
				MdcDrawerContainerDirective,
				MdcDrawerToolbarSpacerDirective,
				MdcDrawerHeaderDirective,
				MdcDrawerHeaderContentDirective,
				MdcDrawerContentDirective,
				MdcElevationDirective,
				MdcFabDirective,
				MdcFabIconDirective,
				MdcFloatingLabelDirective,
				...FOCUS_TRAP_DIRECTIVES,
				MdcFormFieldDirective,
				MdcFormFieldInputDirective,
				MdcFormFieldLabelDirective,
				...ICON_BUTTON_DIRECTIVES,
				MdcIconToggleDirective,
				MdcIconToggleIconDirective,
				MdcFormsIconToggleDirective,
				MdcLinearProgressDirective,
				MdcListDividerDirective,
				MdcListItemDirective,
				MdcListItemTextDirective,
				MdcListItemSecondaryTextDirective,
				MdcListItemGraphicDirective,
				MdcListItemMetaDirective,
				MdcListDirective,
				MdcListGroupSubHeaderDirective,
				MdcListGroupDirective,
				MdcMenuAnchorDirective,
				MdcMenuDirective,
				MdcRadioDirective,
				MdcRadioInputDirective,
				MdcRippleDirective,
				MdcSelectDirective,
				MdcSelectControlDirective,
				MdcSliderDirective,
				MdcFormsSliderDirective,
				MdcSwitchInputDirective,
				MdcSwitchDirective,
				MdcTabDirective,
				MdcTabIconDirective,
				MdcTabIconTextDirective,
				MdcTabRouterDirective,
				MdcTabBarDirective,
				MdcTabBarScrollerDirective,
				MdcTabBarScrollerInnerDirective,
				MdcTabBarScrollerBackDirective,
				MdcTabBarScrollerForwardDirective,
				MdcTabBarScrollerFrameDirective,
				MdcTextFieldDirective,
				MdcTextFieldInputDirective,
				MdcTextFieldIconDirective,
				MdcTextFieldHelperTextDirective,
				MdcToolbarDirective,
				MdcToolbarRowDirective,
				MdcToolbarSectionDirective,
				MdcToolbarTitleDirective,
				MdcToolbarIcon,
				MdcToolbarMenuIcon,
				MdcToolbarFixedAdjustDirective,
				TOP_APP_BAR_DIRECTIVES,
				MdcScrollbarResizeDirective
			]
		}]
	}]
});
export { AbstractMdcFocusInitial, AbstractMdcFocusTrap, AbstractMdcRipple, AbstractMdcTabDirective, CHIP_DIRECTIVES, DIALOG_DIRECTIVES, FOCUS_TRAP_DIRECTIVES, ICON_BUTTON_DIRECTIVES, MaterialModule, MdcButtonDirective, MdcButtonIconDirective, MdcCardActionButtonsDirective, MdcCardActionIconsDirective, MdcCardActionsDirective, MdcCardDirective, MdcCardMediaContentDirective, MdcCardMediaDirective, MdcCardPrimaryActionDirective, MdcCheckboxDirective, MdcCheckboxInputDirective, MdcChipDirective, MdcChipIconDirective, MdcChipSetDirective, MdcChipTextDirective, MdcDialogAcceptDirective, MdcDialogBackdropDirective, MdcDialogBodyDirective, MdcDialogCancelDirective, MdcDialogDirective, MdcDialogFooterDirective, MdcDialogHeaderDirective, MdcDialogHeaderTitleDirective, MdcDialogSurfaceDirective, MdcDrawerContainerDirective, MdcDrawerContentDirective, MdcDrawerDirective, MdcDrawerHeaderContentDirective, MdcDrawerHeaderDirective, MdcDrawerToolbarSpacerDirective, MdcElevationDirective, MdcEventRegistry, MdcFabDirective, MdcFabIconDirective, MdcFloatingLabelDirective, MdcFocusInitialDirective, MdcFocusTrapDirective, MdcFormFieldDirective, MdcFormFieldInputDirective, MdcFormFieldLabelDirective, MdcFormsIconButtonDirective, MdcFormsIconToggleDirective, MdcFormsSliderDirective, MdcIconButtonDirective, MdcIconButtonIconDirective, MdcIconButtonToggleDirective, MdcIconToggleDirective, MdcIconToggleIconDirective, MdcLinearProgressDirective, MdcListDirective, MdcListDividerDirective, MdcListGroupDirective, MdcListGroupSubHeaderDirective, MdcListItemDirective, MdcListItemGraphicDirective, MdcListItemMetaDirective, MdcListItemSecondaryTextDirective, MdcListItemTextDirective, MdcMenuAnchorDirective, MdcMenuDirective, MdcRadioDirective, MdcRadioInputDirective, MdcRippleDirective, MdcScrollbarResizeDirective, MdcSelectControlDirective, MdcSelectDirective, MdcSliderDirective, MdcSnackbarService, MdcSwitchDirective, MdcSwitchInputDirective, MdcTabBarDirective, MdcTabBarScrollerBackDirective, MdcTabBarScrollerDirective, MdcTabBarScrollerForwardDirective, MdcTabBarScrollerFrameDirective, MdcTabBarScrollerInnerDirective, MdcTabDirective, MdcTabIconDirective, MdcTabIconTextDirective, MdcTabRouterDirective, MdcTextFieldDirective, MdcTextFieldHelperTextDirective, MdcTextFieldIconDirective, MdcTextFieldInputDirective, MdcToolbarDirective, MdcToolbarFixedAdjustDirective, MdcToolbarIcon, MdcToolbarMenuIcon, MdcToolbarRowDirective, MdcToolbarSectionDirective, MdcToolbarTitleDirective, MdcTopAppBarActionDirective, MdcTopAppBarDirective, MdcTopAppBarNavIconDirective, MdcTopAppBarRowDirective, MdcTopAppBarSectionDirective, MdcTopAppBarTitleDirective, TOP_APP_BAR_DIRECTIVES };

//# sourceMappingURL=blox-material.mjs.map